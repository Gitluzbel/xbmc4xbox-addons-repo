# -*- coding: utf-8 -*-
'''
script.lyrics.lyricsovh
========================

Boton "Letra" del OSD de musica (MusicOSD.xml ya lo llama solo con
RunScript(Skin.String(LyricScript_Path)) - no hace falta tocar el skin,
solo que el addon sea del tipo xbmc.python.lyrics para que el selector
nativo de Skin.SetAddon(LyricScript_Path, xbmc.python.lyrics) lo
encuentre).

Lee artista/titulo de la cancion en curso UNA SOLA VEZ y termina - a
proposito, nada de hilos en segundo plano sondeando nada. El cuelgue de
JellyCon que investigamos (docs/games-back-hang-investigation.md) vino
de un hilo de Python leyendo getInfoLabel de forma continua mientras la
ventana principal reconstruia una lista; un script bajo demanda como
este, que se lanza, hace una lectura puntual y termina, no tiene ese
problema.

Pide la letra a la API gratuita lyrics.ovh (sin clave, sin registro) y
la muestra con el visor de texto nativo de esta build.
'''

import json
import urllib
import urllib2

import xbmc
import xbmcgui

API_BASE = "https://api.lyrics.ovh/v1"
USER_AGENT = "XboxOgLyrics/1.0"


def log(msg):
	xbmc.log(("[script.lyrics.lyricsovh] %s" % msg).encode('utf-8'), level=xbmc.LOGDEBUG)


def notify(message):
	xbmcgui.Dialog().notification("Letras", message, xbmcgui.NOTIFICATION_INFO, 4000)


def _utf8(value):
	if isinstance(value, unicode):
		return value.encode('utf-8')
	return value


def fetch_lyrics(artist, title):
	url = "%s/%s/%s" % (
		API_BASE,
		urllib.quote(_utf8(artist)),
		urllib.quote(_utf8(title)),
	)
	req = urllib2.Request(url, headers={"User-Agent": USER_AGENT})
	response = urllib2.urlopen(req, timeout=15)
	body = response.read()
	data = json.loads(body)
	return data.get("lyrics")


def main():
	player = xbmc.Player()
	is_audio = player.isPlayingAudio()
	is_video = player.isPlayingVideo()
	artist = xbmc.getInfoLabel("MusicPlayer.Artist")
	title = xbmc.getInfoLabel("MusicPlayer.Title")
	log(
		"CHECKPOINT diagnostico - isPlayingAudio=%s isPlayingVideo=%s "
		"MusicPlayer.Artist='%s' MusicPlayer.Title='%s'"
		% (is_audio, is_video, artist, title)
	)

	if not is_audio:
		notify("No hay ninguna cancion reproduciendose")
		return

	# Las radios de Internet (ej. plugin.audio.fmstream) no siempre rellenan
	# MusicPlayer.Artist por separado - suelen meter "Artista - Cancion"
	# entero en MusicPlayer.Title y dejar Artist vacio. Confirmado en
	# produccion (08/09/2026): Artist='' Title='GRATEFUL DEAD - TRUCKIN'.
	# Si pasa eso, se reparte el titulo a mano en vez de darse por vencido.
	if not artist and title and " - " in title:
		artist, title = [part.strip() for part in title.split(" - ", 1)]
		log("CHECKPOINT titulo repartido a mano -> artista='%s' cancion='%s'" % (artist, title))

	if not artist or not title:
		notify("No se ha podido identificar la cancion actual")
		return

	log("CHECKPOINT buscando letra de '%s' - '%s'" % (artist, title))

	try:
		lyrics = fetch_lyrics(artist, title)
	except urllib2.HTTPError as e:
		if e.code == 404:
			notify("No se ha encontrado letra para esta cancion")
		else:
			log("HTTP error %s buscando letra de '%s' - '%s': %s" % (e.code, artist, title, e))
			notify("Fallo al buscar la letra (error del servidor)")
		return
	except Exception as e:
		log("fallo buscando letra de '%s' - '%s': %s" % (artist, title, e))
		notify("No se ha podido conectar para buscar la letra")
		return

	if not lyrics or not lyrics.strip():
		notify("No se ha encontrado letra para esta cancion")
		return

	heading = "%s - %s" % (_utf8(artist), _utf8(title))
	xbmcgui.Dialog().textviewer(heading, _utf8(lyrics))


if __name__ == "__main__":
	main()
