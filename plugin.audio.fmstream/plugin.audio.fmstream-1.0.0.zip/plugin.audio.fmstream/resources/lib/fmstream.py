import time
import requests
import xbmc

# BUG REAL ENCONTRADO EN PRODUCCION (11/09/2026): make_request() llamaba
# a requests.get() sin ningun timeout - en la practica, "sin timeout"
# para la libreria requests significa esperar indefinidamente a que el
# servidor responda. Sobre el hardware de red tan limitado de esta Xbox
# (con un puerto de Python muy antiguo, ver
# video-radio-freeze-investigation.md, Causa 3: _socket.pyd no suelta
# bien el GIL durante E/S bloqueante), esta peticion se dispara en CADA
# navegacion dentro del addon (categoria -> emisora -> stream) y se ha
# confirmado en consola real que coincide en tiempo, casi milisegundo a
# milisegundo, con bloqueos de 11-14 segundos de "todo el mando"
# congelado - mientras esta llamada sin timeout retiene el GIL, ningun
# otro script Python (ni siquiera codigo C++ que necesite esperar a que
# el interprete quede libre) puede avanzar. Un timeout no arregla que la
# API de fmstream.org pueda tardar en responder, pero pone un techo
# real al tiempo que este addon puede tener el sistema entero
# bloqueado, en vez de dejarlo sin limite.
REQUEST_TIMEOUT_SECONDS = 10


def gen_api_key():
    keya = "0xb554"
    keyb = "0x0f99"
    key = int(keya, 16) * int(time.time()) + int(keyb, 16)
    api_key = format(key, "x")
    return api_key


class FMStreamAPI:
    def __init__(self, hq):
        self.hq = int(hq)

        self.api = "https://fmstream.org/index.php"

    def make_request(self, url, params=None, headers=None):
        if not headers:
            headers = {"accept": "application/json", "user-agent": "xbox-fmstream"}

        try:
            response = requests.get(
                url, params=params, headers=headers, timeout=REQUEST_TIMEOUT_SECONDS
            )
            if response.status_code != 200:
                xbmc.log(
                    "FMStream.org API returned error: {}".format(response.status_code),
                    level=xbmc.LOGERROR,
                )
                return None
            return response.json()
        except Exception as e:
            xbmc.log(
                "FMStream.org API request failed: {}".format(e), level=xbmc.LOGERROR
            )
        return None

    def get_countries(self):
        return self.make_request("https://fmstream.org/itu.php")

    def get_languages(self):
        return self.make_request("https://fmstream.org/la.php")

    def fetch(self, c=None, l=None, n=None, o=None, s=None, style=None):
        """
        Input:
            Check https://fmstream.org/api.htm to learn what each letter represents
        Output:
            None: if error was encountered
            Dictionary: that represents response from FMStream API
        """

        params = {"key": gen_api_key()}
        params["hq"] = str(self.hq)

        if c:
            params["c"] = str(c)
        if l:
            params["l"] = str(l)
        if n:
            params["n"] = str(n)
        if o:
            params["o"] = str(o)
        if s:
            params["s"] = str(s)
        if style:
            params["style"] = str(style)

        return self.make_request(self.api, params)
