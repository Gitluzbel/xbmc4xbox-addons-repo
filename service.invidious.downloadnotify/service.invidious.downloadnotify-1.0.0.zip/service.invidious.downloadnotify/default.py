# -*- coding: utf-8 -*-
"""
service.invidious.downloadnotify
=================================

El boton "Descargar" del addon de Invidious lanza el trabajo en
invidious-download (el mini PC) y no espera a que termine - la Xbox
queda libre al momento, en vez de mantener un dialogo de progreso
bloqueado durante las horas que puede tardar un video grande. Pero eso
significa que, sin esto, no habria forma de saber si la descarga va
bien, se ha atascado o ha fallado sin ir a mirar el log del mini PC a
mano.

La via obvia (que el mini PC empuje un aviso a la Xbox via su API HTTP)
no funciona en esta build: confirmado a mano que /xbmcCmds/xbmcHttp
responde "<html></html>" vacio a CUALQUIER comando, incluso a Help -
es un stub, no una implementacion real. JSON-RPC tampoco existe (404).
Por eso este servicio hace lo contrario: sondea periodicamente
http://<instancia>:3002/status.json (el propio invidious-download) y
lanza xbmcgui.Dialog().notification() el mismo, en la propia Xbox,
cuando detecta un cambio real de etapa o un salto de 10% en la
descarga.

Al arrancar (boot o reinicio del servicio) no se avisa de nada de lo
que ya estuviera en marcha o terminado - solo se recuerda en que punto
estaba cada trabajo, para no avisar en bucle de trabajos viejos cada
vez que la Xbox se reinicia mientras la lista de invidious-download
todavia los recuerda.

SOLO SONDEA LA RED MIENTRAS HAY UNA DESCARGA ACTIVA DE VERDAD (anadido
10/09/2026, ver video-radio-freeze-investigation.md, "Causa 3" y
mitigacion aplicada a weather.openmeteo): antes, este bucle hacia una
peticion de red (urllib2.urlopen, hasta 5s de timeout) cada 5 segundos,
sin parar, desde que arrancaba la Xbox, aunque no hubiera absolutamente
nada descargandose - una fuente constante de colisiones con el GIL de
Python (candado global compartido por TODOS los addons del sistema:
mientras una peticion de red esta en marcha, ningun otro script Python
puede ni arrancar). Ahora el bucle principal (ver main()) solo hace esa
peticion de red mientras existe MARKER_PATH, un archivo local (sin red,
practicamente gratis de comprobar) que escribe
plugin.video.invidious/resources/lib/router.py justo despues de arrancar
un trabajo de descarga con exito (_mark_download_active() ahi). Este
mismo servicio borra esa marca en cuanto ve, en un sondeo con exito, que
ya no queda ningun trabajo en curso (_clear_marker(), abajo) - momento en
el que vuelve al modo de reposo, sin tocar la red para nada, hasta la
proxima descarga. Si se cambia esta ruta aqui, cambiarla tambien alli.

BUG REAL ENCONTRADO Y ARREGLADO EN PRODUCCION (10/09/2026, no relacionado
con el sondeo bajo demanda de arriba): sin "unicode_literals", los textos
de STAGE_MESSAGES son bytes ASCII, no unicode - en cuanto un titulo de
video real (no el ID) trae una tilde u otro caracter no-ASCII,
"template.format(title=title)" lanza UnicodeEncodeError. La excepcion no
estaba capturada en ningun sitio de la cadena poll() -> _process_job(),
asi que se propagaba hasta main() y mataba el script del servicio entero
a mitad de una descarga real - confirmado en el log de una prueba real,
con el marcador de descarga activa ya escrito y sin nadie vivo para
volver a borrarlo. Arreglado con "unicode_literals" (abajo) y con un
try/except alrededor de cada _process_job() individual en poll() (ver
mas abajo) para que, si alguna vez vuelve a fallar el formateo de UN
trabajo por cualquier motivo, no se lleve por delante la vigilancia de
los demas ni el servicio completo.
"""
from __future__ import unicode_literals

import json
import os
import socket

import xbmc
import xbmcgui

from nbnsresolve import resolve_netbios_name

# Nombre NetBIOS del mini PC (configurado en /etc/samba/smb.conf con
# "netbios name = MINIPC_NETBIOS_NAME") - resuelto por nbnsresolve
# (NBNS puro Python, sin DNS ni mDNS, ver ese modulo) en vez de una IP
# fija hardcodeada. Si la resolucion falla (mini PC apagado, red rara
# en ese instante...) cae al ultimo valor fijo conocido como respaldo.
MINIPC_NETBIOS_NAME = "XBOXMINIPC"
_FALLBACK_MINIPC_IP = "192.168.1.134"


def _status_url():
    ip = resolve_netbios_name(MINIPC_NETBIOS_NAME) or _FALLBACK_MINIPC_IP
    return "http://{}:3002/status.json".format(ip)


# BUG REAL ENCONTRADO EN PRODUCCION (13/09/2026): urllib2 tiene exactamente
# el mismo problema que xbmcvfs (ver la nota de arriba sobre MARKER_PATH) -
# importarlo carga httplib, y httplib.py hace "try: import ssl" a nivel de
# modulo de forma INCONDICIONAL, aunque _status_url() solo construya URLs
# http:// y esta funcion nunca use HTTPS de verdad. Confirmado con logging
# de diagnostico en CPythonInvoker::onExecutionDone() (PythonInvoker.cpp)
# que el crash cae dentro de la propia llamada a Py_EndInterpreter() para
# este servicio en concreto - el modulo ssl (con su backend TLS, wolfssl
# en este fork) no parece llevarse bien con tener varios sub-interpretes
# de Python distintos cerrandose casi a la vez, aunque nunca se abra
# ninguna conexion HTTPS de verdad. Se sustituye urllib2.urlopen() por un
# GET HTTP/1.0 minimo a mano con socket crudo (ya se usa socket de todas
# formas via nbnsresolve) para no cargar ssl en absoluto en este
# interprete.
def _http_get(url, timeout):
    if not url.startswith("http://"):
        raise ValueError("_http_get solo soporta http://: {}".format(url))
    host_port, _, path = url[len("http://"):].partition("/")
    path = "/" + path
    if ":" in host_port:
        host, port_str = host_port.split(":", 1)
        port = int(port_str)
    else:
        host, port = host_port, 80

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect((host, port))
        request = "GET {} HTTP/1.0\r\nHost: {}\r\nConnection: close\r\n\r\n".format(path, host)
        sock.sendall(request.encode("ascii"))
        chunks = []
        while True:
            chunk = sock.recv(4096)
            if not chunk:
                break
            chunks.append(chunk)
    finally:
        sock.close()

    response = b"".join(chunks)
    header_end = response.find(b"\r\n\r\n")
    if header_end == -1:
        raise IOError("respuesta HTTP de {} sin cabeceras completas".format(url))
    return response[header_end + 4:]

POLL_INTERVAL_SECONDS = 5  # sondeo de RED, caro - solo mientras hay marca
IDLE_CHECK_SECONDS = 3     # comprobacion LOCAL del archivo, barata - siempre

# BUG REAL ENCONTRADO EN PRODUCCION (10/09/2026): con timeout=5, TODOS los
# sondeos durante una descarga real fallaron durante ~7 minutos seguidos
# con "urlopen error timed out" (confirmado en log real) - ni un solo
# aviso de progreso llego al usuario en toda la descarga. Comprobado a la
# vez que status.json responde en ~70ms sin carga, asi que el servidor no
# es el cuello de botella: 5s no le basta a la Xbox (hardware de red muy
# limitado) para completar ni una sola peticion HTTP saliente mientras hay
# contencion real de red/CPU en la propia consola (coincide con la etapa
# "subiendo", una subida FTP grande del video terminado ENTRANDO a la
# Xbox al mismo tiempo). Subido a 15s: sigue siendo barato en el caso
# normal (la respuesta real tarda milisegundos) y da mucho mas margen
# para sobrevivir a esos picos sin perder la ventana de aviso.
POLL_TIMEOUT_SECONDS = 15

# Debe apuntar al mismo archivo que DOWNLOAD_MARKER_DIR/PATH en
# plugin.video.invidious/resources/lib/router.py (esa parte SI sigue
# usando xbmcvfs para escribir el marcador - solo se quita de aqui, ver
# nota de abajo).
MARKER_DIR = "special://profile/addon_data/service.invidious.downloadnotify/"

# BUG REAL ENCONTRADO EN PRODUCCION (12/09/2026) - CORREGIDO 13/09/2026:
# se penso en su momento que el problema era xbmcvfs por ser un modulo
# nativo C++, frente a json (Python puro de verdad). Luego se descubrio
# que urllib2 (que en ese momento tambien se usaba aqui, ver el bug de
# mas abajo sobre _http_get) TAMBIEN provocaba exactamente el mismo
# crash pese a "parecer" Python puro - en realidad carga ssl/wolfssl por
# debajo via httplib. La leccion real no es "nativo C++ malo, Python
# puro bueno", sino "cualquier modulo con estado global en C (nativo de
# XBMC o de una libreria C enlazada como wolfssl) puede no ser seguro de
# cargar/descargar en un sub-interprete que se destruye durante el
# apagado en cascada de varios servicios a la vez". xbmcvfs provocaba un
# EXCEPTION_BREAKPOINT (0x80000003) real al cerrar el interprete de este
# servicio en concreto - confirmado en xbmc.old.log, justo despues de
# "onExecutionDone" para este script, sin la linea final "Thread
# LanguageInvoker N terminating" que si aparecia en los otros dos
# servicios persistentes (service.invidious.lcd, service.xbox.remotecontrol)
# que NO importan xbmcvfs. Ese cuelgue en CApplication::Stop() bloqueaba
# tambien RunXBE() (lanzar otro .xbe) y el propio menu de apagado, porque
# ambos necesitan el mismo cierre completo de la app. Se sustituye por
# os.path.exists/os.remove de Python puro sobre la ruta ya traducida con
# xbmc.translatePath() (misma ruta real de siempre, sin pasar por
# xbmcvfs) - esta comprobacion es solo leer/borrar un archivo marcador
# pequeno, no hace falta el modulo nativo para eso.
MARKER_PATH = xbmc.translatePath(MARKER_DIR + "active_download")

# Las unicas dos etapas "terminales" de STAGE_MESSAGES (ver abajo) - si
# TODOS los trabajos que devuelve el mini PC estan en una de estas dos
# (o no hay ningun trabajo en absoluto), ya no queda nada activo de
# verdad y se puede borrar la marca y volver al reposo.
TERMINAL_STAGES = ("completado", "fallo")


def _download_active():
    return os.path.exists(MARKER_PATH)


def _clear_marker():
    if os.path.exists(MARKER_PATH):
        os.remove(MARKER_PATH)

STAGE_MESSAGES = {
    "empezando": "Empezando: {title}",
    "descargando_video": None,  # los % se avisan aparte, ver abajo
    "descargando_audio": None,  # depende de resolution, ver _descargando_audio_message()
    # OJO: nunca usar "completa"/"completado" aqui - solo el mensaje de
    # la etapa "completado" de verdad lo esta. Confirmado en produccion
    # que "Descarga completa, remezclando" confundia al dar a entender
    # que ya habia terminado del todo, cuando en realidad faltaban aun
    # el remux Y la subida por FTP (la etapa que mas tarda de las
    # cuatro). Para 720p/1080p ahora se recodifica a Xvid de verdad
    # (minutos, no segundos) - ver _recodificando_message() mas abajo,
    # que usa un texto distinto para 480p (donde sigue siendo un remux
    # rapido, sin recodificar).
    "recodificando": None,  # se resuelve en _recodificando_message()
    "subiendo": "Subiendo a la Xbox: {title}",
    "completado": "Descarga completada: {title}",
    "fallo": "Descarga fallida: {title}",
}


# Resoluciones que invidious_download.py recodifica de verdad a Xvid
# (ver TRANSCODE_RESOLUTIONS en ese script) - en 480p e inferiores sigue
# siendo un remux rapido sin recodificar, asi que el aviso no debe decir
# "puede tardar varios minutos" ahi, seria enganoso.
TRANSCODE_RESOLUTIONS = ("720p", "1080p")


def _descargando_audio_message(job, title):
    # "solo audio" (13/09/2026): en ese job NO hay descarga de vídeo
    # previa - descargando_audio es la unica etapa de descarga que
    # existe, asi que el mensaje de los jobs normales ("Vídeo
    # descargado, bajando audio") seria falso aqui.
    if job.get("resolution") == "audio":
        return "Descargando audio: {}".format(title)
    return "Vídeo descargado, bajando audio: {}".format(title)


def _recodificando_message(job, title):
    if job.get("resolution") == "audio":
        return "Audio descargado, convirtiendo a MP3: {}".format(title)
    if job.get("resolution") in TRANSCODE_RESOLUTIONS:
        return "Vídeo y audio descargados, recodificando a Xvid (puede tardar varios minutos): {}".format(title)
    return "Vídeo y audio descargados, preparando el archivo: {}".format(title)


def notify(message):
    xbmcgui.Dialog().notification(
        "Invidious - Descargas", message, xbmcgui.NOTIFICATION_INFO, 6000
    )


class DownloadNotifier(object):
    def __init__(self):
        # job_id -> {"stage": ultima_etapa_vista, "bucket": ultimo_10%_avisado}
        self.seen = {}
        self.first_poll = True

    def poll(self):
        try:
            data = json.loads(_http_get(_status_url(), POLL_TIMEOUT_SECONDS))
        except Exception as e:
            xbmc.log(
                "service.invidious.downloadnotify: poll failed: {}".format(e),
                xbmc.LOGDEBUG,
            )
            # No se borra la marca aqui a proposito - un fallo puntual de
            # red (el mismo motivo por el que este sondeo existe) no debe
            # hacer que se deje de vigilar una descarga que sigue activa
            # de verdad en el mini PC. Solo se borra tras un sondeo con
            # EXITO que confirme que ya no queda nada en curso.
            return

        jobs = data.get("jobs", [])
        for job in jobs:
            try:
                self._process_job(job)
            except Exception as e:
                # Un fallo al procesar UN trabajo (formato de texto,
                # campo inesperado, lo que sea) no debe tirar el
                # servicio entero - eso ya paso una vez en produccion
                # (UnicodeEncodeError con un titulo con tildes, ver nota
                # al principio del fichero) y dejo de vigilarse una
                # descarga real a mitad de camino, sin nadie vivo para
                # borrar el marcador ni avisar de que termino.
                xbmc.log(
                    "service.invidious.downloadnotify: fallo procesando "
                    "job {}: {}".format(job.get("job_id"), e),
                    xbmc.LOGERROR,
                )

        # Tras la primera pasada ya se ha "sellado" el estado de todo lo
        # que hubiera en marcha o terminado antes de que este servicio
        # arrancara - a partir de aqui si se avisa de verdad.
        self.first_poll = False

        # Ya no queda ningun trabajo activo de verdad (o la lista viene
        # vacia) - se vuelve al reposo sin tocar la red hasta la proxima
        # descarga. all() sobre una lista vacia da True, que es justo lo
        # que queremos aqui tambien.
        if all(job.get("stage") in TERMINAL_STAGES for job in jobs):
            _clear_marker()

    def _process_job(self, job):
        job_id = job.get("job_id")
        if not job_id:
            return

        stage = job.get("stage")
        percent = job.get("percent") or 0
        title = job.get("title") or job.get("video_id") or "vídeo"

        state = self.seen.get(job_id)
        if state is None:
            state = {"stage": None, "bucket": -1}
            self.seen[job_id] = state

        if self.first_poll:
            # No avisar de nada retroactivo - solo recordar donde
            # estaba cada trabajo que ya existiera al arrancar.
            state["stage"] = stage
            state["bucket"] = percent // 10
            return

        if stage != state["stage"]:
            if stage == "recodificando":
                message = _recodificando_message(job, title)
            elif stage == "descargando_audio":
                message = _descargando_audio_message(job, title)
            else:
                template = STAGE_MESSAGES.get(stage)
                message = template.format(title=title) if template else None
            if message:
                if stage == "fallo" and job.get("error"):
                    message += ": {}".format(job["error"])
                notify(message)
            state["stage"] = stage
            state["bucket"] = percent // 10

        if stage in ("descargando_video", "recodificando"):
            bucket = percent // 10
            if bucket > state["bucket"]:
                verb = "Recodificando" if stage == "recodificando" else "Descargando"
                notify("{} {}: {}%".format(verb, title, percent))
                state["bucket"] = bucket


def main():
    notifier = DownloadNotifier()
    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        if _download_active():
            notifier.poll()
            wait = POLL_INTERVAL_SECONDS
        else:
            # Reposo: ni una sola peticion de red mientras no haya
            # marca de descarga activa - solo esta comprobacion local.
            wait = IDLE_CHECK_SECONDS
        if monitor.waitForAbort(wait):
            break


if __name__ == "__main__":
    main()
