# -*- coding: utf-8 -*-
"""
insignia_api
============

Logica compartida de peticion a insigniastats.live y cruce con la
biblioteca local, extraida de default.py (13/09/2026) para que la use
tanto el plugin (default.py, lista dentro de la ventana nativa de
Programas) como el script nuevo que rellena propiedades de ventana
para la ventana WINDOW_INSIGNIA/WINDOW_INSIGNIA_EVENTS (ver
show_window.py) - un solo sitio con el fetch real, dos formas de
mostrarlo.
"""

import json
import socket
import sqlite3
import threading

import xbmc
import urllib2

GAMES_URL = "https://insigniastats.live/api/online-users"
EVENTS_URL = "https://insigniastats.live/api/events"
LOCAL_DB_PATH = xbmc.translatePath("special://profile/database/MyPrograms1.db")

# Dos capas de limite de tiempo, no una sola - confirmado a mano que
# el "timeout=" de urllib2.urlopen NO basta en este interprete tan
# viejo: se colgo la Xbox entera (bloqueo total, sin responder ni al
# mando) probando esto en real, con ese parametro puesto. La consulta
# de verdad va en un hilo aparte con socket.setdefaulttimeout() como
# primera red de seguridad, y ademas se le hace join() con su propio
# limite - si ni con eso responde a tiempo, se abandona el hilo en
# segundo plano (daemon, no bloquea el cierre del script) y se avisa
# ya mismo en vez de arriesgarse otra vez a colgar XBMC entero.
SOCKET_TIMEOUT = 8
JOIN_TIMEOUT = 10


def _fetch_url(url):
    result = {}

    def worker():
        try:
            socket.setdefaulttimeout(SOCKET_TIMEOUT)
            req = urllib2.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            result["data"] = urllib2.urlopen(req).read()
        except Exception as e:
            result["error"] = str(e)

    t = threading.Thread(target=worker)
    t.setDaemon(True)
    t.start()
    t.join(JOIN_TIMEOUT)

    if t.isAlive():
        raise Exception("{} no respondio a tiempo".format(url))
    if "error" in result:
        raise Exception(result["error"])
    return result["data"]


# --- Biblioteca local (caratula/fanart/ruta de lanzamiento) ---------------

def _open_local_db():
    try:
        conn = sqlite3.connect(LOCAL_DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        xbmc.log("[insignia] no se pudo abrir MyPrograms1.db: %s" % e, xbmc.LOGERROR)
        return None


def _lookup_local_game(conn, title_id):
    if not conn or not title_id:
        return None
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT c00 AS xbe, c03 AS title, c20 AS poster, c21 AS fanart "
            "FROM program WHERE UPPER(c01) = UPPER(?)",
            (title_id,),
        )
        row = cur.fetchone()
        return dict(row) if row else None
    except sqlite3.Error as e:
        xbmc.log("[insignia] error consultando biblioteca local: %s" % e, xbmc.LOGERROR)
        return None


# --- Partidas activas -------------------------------------------------

def fetch_active_games_entries():
    """Devuelve una lista de dicts: name, title_id, online, lobby_players,
    lobbies, xbl_online, label, icon, fanart, xbe - ya cruzados con la
    biblioteca local y ordenados por online descendente."""
    raw = _fetch_url(GAMES_URL)
    data = json.loads(raw)

    games = []
    for game in data.values():
        try:
            online = int(game.get("online") or 0)
        except (TypeError, ValueError):
            online = 0
        if online <= 0:
            continue
        games.append({
            "name": game.get("name") or "?",
            "title_id": game.get("titleId") or "",
            "online": online,
            "lobby_players": int(game.get("activeLobbyPlayers") or 0),
            "lobbies": int(game.get("activeLobbies") or 0),
            # xblOnline: la sesion es Xbox Live real, no solo Insignia
            # (unico campo de "estado" que la API SI da de verdad - los
            # antiguos has_live_aware/matchmaking/leaderboards/ugc del
            # CInsignia original nunca vinieron poblados, ver
            # confluence-patches/README.txt).
            "xbl_online": bool(game.get("xblOnline")),
        })
    games.sort(key=lambda g: g["online"], reverse=True)

    conn = _open_local_db()
    entries = []
    for game in games:
        local = _lookup_local_game(conn, game["title_id"])
        entries.append({
            "name": game["name"],
            "title_id": game["title_id"],
            "online": game["online"],
            "lobby_players": game["lobby_players"],
            "lobbies": game["lobbies"],
            "xbl_online": game["xbl_online"],
            "label": local["title"] if local else game["name"],
            "icon": local["poster"] if local else "",
            "fanart": local["fanart"] if local else "",
            "xbe": local["xbe"] if local else "",
        })
    if conn:
        conn.close()
    return entries


# --- Eventos programados -----------------------------------------------

def fetch_events_entries():
    """Devuelve una lista de dicts: label, description, event_date,
    start_time, end_time, community_host, event_tag, dlc_required,
    is_leaderboard, modded_content_required, icon, fanart, xbe - ya
    cruzados con la biblioteca local."""
    raw = _fetch_url(EVENTS_URL)
    events = json.loads(raw)

    conn = _open_local_db()
    entries = []
    for event in events:
        title_id = event.get("title_id") or ""
        local = _lookup_local_game(conn, title_id)

        entries.append({
            "label": local["title"] if local else (event.get("game_name") or "?"),
            "description": event.get("description") or "",
            "event_date": event.get("event_date") or "",
            "start_time": event.get("start_time") or "",
            "end_time": event.get("end_time") or "",
            "community_host": event.get("community_host") or event.get("created_by") or "?",
            "event_tag": event.get("event_tag") or "",
            "dlc_required": bool(event.get("dlc_required")),
            "is_leaderboard": bool(event.get("is_leaderboard")),
            "modded_content_required": bool(event.get("modded_content_required")),
            "icon": local["poster"] if local else (event.get("game_image") or ""),
            "fanart": local["fanart"] if local else "",
            "xbe": local["xbe"] if local else "",
        })
    if conn:
        conn.close()
    return entries
