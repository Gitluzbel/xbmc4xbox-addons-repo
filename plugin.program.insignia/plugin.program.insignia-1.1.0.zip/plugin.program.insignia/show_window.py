# -*- coding: utf-8 -*-
"""
show_window
===========

Rellena las propiedades numeradas de la ventana Home (10000) a partir
de insigniastats.live y activa la ventana nativa correspondiente
(WINDOW_INSIGNIA=12700 o WINDOW_INSIGNIA_EVENTS=12750). Unico punto de
entrada del addon (extension xbmc.python.script, ver addon.xml) desde
que se quito el antiguo plugin.python.pluginsource - esto no "navega"
a ningun lado: corre una vez, deja las propiedades listas, y activa la
ventana. Mismo patron que usa Rocky5 en XBMC4Gamers (execfile()
sincrono seguido de ActivateWindow()) para su propio script de
Insignia, adaptado a este proyecto.

Investigacion completa de por que esto NO es un servicio persistente ni
una xbmcgui.WindowXMLDialog propia en
docs/investigaciones/runxbe-shutdown-crash-investigation.md: un script
de un solo uso que corre y termina es la via segura conocida en este
proyecto para tocar red real desde Python (evita anadir otro
interprete mas a la cascada de apagado), y WindowXMLDialog ya se probo
y descarto en este mismo proyecto por no coger el foco de verdad en
esta build.

Las ventanas Insignia.xml/InsigniaEvents.xml del skin deben definir
exactamente MAX_GAMES/MAX_EVENTS <item id="N"> leyendo estas mismas
propiedades - ver confluence-patches/README.txt.
"""
import sys

import xbmc
import xbmcgui

from resources.lib.insignia_api import fetch_active_games_entries, fetch_events_entries

WINDOW_INSIGNIA = 12700
WINDOW_INSIGNIA_EVENTS = 12750

# Techo de items - mismo espiritu que los 40 fijos de XBMC4Gamers, aqui
# de sobra para lo que realmente se ve en la practica (Insignia no
# suele tener mas de un puñado de juegos/eventos activos a la vez).
MAX_GAMES = 20
MAX_EVENTS = 20

HOME = xbmcgui.Window(10000)

_GAME_SUFFIXES = ("Title", "Icon", "Fanart", "Online", "LobbyPlayers", "Lobbies",
                  "TitleID", "XblOnline", "Installed", "XBEPath")
_EVENT_SUFFIXES = ("Title", "Icon", "Fanart", "Description", "EventDate", "StartTime",
                   "EndTime", "Host", "Tag", "DlcRequired", "IsLeaderboard",
                   "ModdedContentRequired", "Installed", "XBEPath")


def _clear_prefix(prefix, max_count, suffixes):
    for i in range(1, max_count + 1):
        for suffix in suffixes:
            HOME.clearProperty("{}.{}.{}".format(prefix, i, suffix))


def _populate_games():
    _clear_prefix("InsigniaGame", MAX_GAMES, _GAME_SUFFIXES)
    progress = xbmcgui.DialogProgress()
    progress.create("Insignia", "Consultando partidas activas...")
    try:
        games = fetch_active_games_entries()
    except Exception as e:
        xbmc.log("[insignia] fallo pidiendo partidas activas: {}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Insignia", "No se pudo conectar con insigniastats.live")
        return
    finally:
        progress.close()

    for index, game in enumerate(games[:MAX_GAMES], start=1):
        prefix = "InsigniaGame.{}".format(index)
        HOME.setProperty("{}.Title".format(prefix), game["label"])
        HOME.setProperty("{}.Icon".format(prefix), game["icon"])
        HOME.setProperty("{}.Fanart".format(prefix), game["fanart"])
        HOME.setProperty("{}.Online".format(prefix), str(game["online"]))
        HOME.setProperty("{}.LobbyPlayers".format(prefix), str(game["lobby_players"]))
        HOME.setProperty("{}.Lobbies".format(prefix), str(game["lobbies"]))
        HOME.setProperty("{}.TitleID".format(prefix), game["title_id"])
        if game["xbl_online"]:
            HOME.setProperty("{}.XblOnline".format(prefix), "true")
        if game["xbe"]:
            HOME.setProperty("{}.Installed".format(prefix), "true")
            HOME.setProperty("{}.XBEPath".format(prefix), "RunXBE({})".format(game["xbe"]))


def _populate_events():
    _clear_prefix("InsigniaEvent", MAX_EVENTS, _EVENT_SUFFIXES)
    progress = xbmcgui.DialogProgress()
    progress.create("Insignia", "Consultando eventos programados...")
    try:
        events = fetch_events_entries()
    except Exception as e:
        xbmc.log("[insignia] fallo pidiendo eventos: {}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Insignia", "No se pudo conectar con insigniastats.live")
        return
    finally:
        progress.close()

    for index, event in enumerate(events[:MAX_EVENTS], start=1):
        prefix = "InsigniaEvent.{}".format(index)
        HOME.setProperty("{}.Title".format(prefix), event["label"])
        HOME.setProperty("{}.Icon".format(prefix), event["icon"])
        HOME.setProperty("{}.Fanart".format(prefix), event["fanart"])
        HOME.setProperty("{}.Description".format(prefix), event["description"])
        HOME.setProperty("{}.EventDate".format(prefix), event["event_date"])
        HOME.setProperty("{}.StartTime".format(prefix), event["start_time"])
        HOME.setProperty("{}.EndTime".format(prefix), event["end_time"])
        HOME.setProperty("{}.Host".format(prefix), event["community_host"])
        HOME.setProperty("{}.Tag".format(prefix), event["event_tag"])
        if event["dlc_required"]:
            HOME.setProperty("{}.DlcRequired".format(prefix), "true")
        if event["is_leaderboard"]:
            HOME.setProperty("{}.IsLeaderboard".format(prefix), "true")
        if event["modded_content_required"]:
            HOME.setProperty("{}.ModdedContentRequired".format(prefix), "true")
        if event["xbe"]:
            HOME.setProperty("{}.Installed".format(prefix), "true")
            HOME.setProperty("{}.XBEPath".format(prefix), "RunXBE({})".format(event["xbe"]))


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "games"
    if mode == "events":
        _populate_events()
        xbmc.executebuiltin("ActivateWindow({})".format(WINDOW_INSIGNIA_EVENTS))
    else:
        _populate_games()
        xbmc.executebuiltin("ActivateWindow({})".format(WINDOW_INSIGNIA))
