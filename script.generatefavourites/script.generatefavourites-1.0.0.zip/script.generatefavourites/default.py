# -*- coding: utf-8 -*-
'''
	Script original de Rocky5 (XBMC4Gamers), adaptado para xbmc4xbox-redux.
	Genera favourites.xml escaneando directamente las carpetas de juegos
	(E:\Games\, F:\Games\, G:\Games\), sin depender de MyPrograms6.db.
'''
import glob
import os
import struct
import xbmc
import xbmcgui
import xml.etree.ElementTree as ET
from xml.dom import minidom

GAME_DIRECTORIES = ["E:\\Games\\", "F:\\Games\\", "G:\\Games\\"]


def xbe_title(file_name):
	try:
		with open(file_name, 'rb') as xbe:
			xbe.seek(0x104)
			load_addr = struct.unpack('L', xbe.read(4))
			xbe.seek(0x118)
			cert_loc = struct.unpack('L', xbe.read(4))
			cert_base = cert_loc[0] - load_addr[0] + 8
			xbe.seek(cert_base)
			xbe.read(4)
			title = ''.join([unichr(dta) for dta in struct.unpack('40H', xbe.read(0x0050)) if dta != 0])
		return str(title)
	except Exception as e:
		print('[Generate Favourites] Error leyendo XBE {}: {}'.format(file_name, e))
		return ''


def create_favourites_xml():
	favourites_xml = xbmc.translatePath('special://profile/favourites.xml')
	profile_dir = xbmc.translatePath('special://profile/')
	dialog = xbmcgui.Dialog()
	progress = xbmcgui.DialogProgress()

	game_dirs = [d for d in GAME_DIRECTORIES if os.path.isdir(d)]
	if not game_dirs:
		dialog.ok('Generar Favoritos', '', 'No se encontro ninguna carpeta de juegos',
				   '(E:\\Games, F:\\Games o G:\\Games).')
		return

	total_games = sum(len(os.listdir(d)) for d in game_dirs)
	if total_games == 0:
		dialog.ok('Generar Favoritos', '', 'Las carpetas de juegos estan vacias.')
		return

	root = ET.Element('favourites')
	count = 0
	processed = 0

	progress.create('Generando Favoritos', '', 'Buscando juegos...')

	for game_dir in game_dirs:
		for item in sorted(os.listdir(game_dir)):
			game_path = os.path.join(game_dir, item)
			if not os.path.isdir(game_path):
				continue

			for xbe_path in glob.glob(os.path.join(game_path, 'default.xbe')):
				if progress.iscanceled():
					progress.close()
					return

				processed += 1
				progress.update((processed * 100) // total_games, 'Escaneando juegos', item)

				title = xbe_title(xbe_path)
				thumb_cache = xbmc.getCacheThumbName(xbe_path)
				xbe_path_escaped = xbe_path.replace('\\', '\\\\')

				favourite = ET.SubElement(root, 'favourite')
				favourite.set('name', title if title else item)
				favourite.set('thumb', profile_dir + 'Thumbnails\\Programs\\' + thumb_cache[0] + '\\' + thumb_cache)
				favourite.text = 'RunXBE("{}")'.format(xbe_path_escaped)
				count += 1

	tree_str = ET.tostring(root)
	pretty_xml = minidom.parseString(tree_str).toprettyxml(indent='  ')

	with open(favourites_xml, 'w') as f:
		f.write(pretty_xml.encode('ascii', 'ignore'))

	progress.close()
	dialog.ok('Generar Favoritos', '', '{} juegos anadidos a favoritos.'.format(count))


if __name__ == '__main__':
	xbmc.executebuiltin('Dialog.Close(1100,false)')
	create_favourites_xml()
