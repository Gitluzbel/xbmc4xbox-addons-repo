# -*- coding: utf-8 -*-
from os.path import join
from xbmc import executebuiltin
from xbmcaddon import Addon
import sys

WINDOWID = 10020
ADDON = Addon('Game Save Resigner')
__scriptname__ = ADDON.getAddonInfo('name')
__version__ = ADDON.getAddonInfo('version')
__path__ = ADDON.getAddonInfo('path')

print '[SCRIPT][%s] version %s initialized!' % (__scriptname__, __version__)

if __name__ == '__main__':
	if len(sys.argv) < 2:
		executebuiltin('ActivateWindow(1100)')
	sys.path.insert(0, join(__path__, 'resources', 'lib'))

	import saveresigner
	saveresigner.main()
