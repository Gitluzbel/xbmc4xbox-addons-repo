# -*- coding: utf-8 -*-
'''
	Game Save Resigner
	Script by Rocky5

	Resigns supported Xbox game saves to this console's HDD key/MAC.
	Also resigns PSO quest DLC files in TDATA.

	Requires:
		latest XBMC4Gamers or my XBMC4Xbox 3.6 version.
		My script.module.savesigner module.
'''
from os import listdir
from os.path import isdir, isfile, join
from xbmc import sleep, executebuiltin, Keyboard
from xbmcgui import DialogProgress, Dialog, Window
from xbmcaddon import Addon
import sys, traceback, savesigner

WINDOW = Window(10020)

ADDON_ID = 'Game Save Resigner'
ADDON = Addon(ADDON_ID)
ROOT_DIR = ADDON.getAddonInfo('path')
SYSINFO_PATH = 'Q:\\system\\SystemInfo\\EEPROMBackup.cfg'
CERBIOS_INI = 'E:\\Cerbios\\cerbios.ini'
UDATA_PART_MAP = {1: 'E', 6: 'F', 7: 'G'}
DOAU_TITLE_ID = '54430006'
PSO_TITLE_ID = '4D53004A'
SIGNERS_CACHE = None


# Logging
def log(message):
	try:
		if isinstance(message, unicode):
			message = message.encode('ascii', errors = 'replace').decode('ascii')
		print '[{}] {}'.format(ADDON_ID, message)
	except Exception:
		pass


# Dialogs
def dialog_ok(heading, line1, line2 = '', line3 = ''):
	Dialog().ok(heading, line1, line2, line3)


def dialog_yesno(heading, line1, line2 = '', line3 = '', nolabel = '', yeslabel = ''):
	return Dialog().yesno(heading, line1, line2, line3, nolabel, yeslabel)


def notify(message):
	try:
		executebuiltin('Notification({}, {}, 4000, {}\\icon.png)'.format(ADDON_ID, safe(message), ROOT_DIR))
	except Exception:
		pass


def safe(text):
	try:
		if isinstance(text, unicode):
			return text.encode('ascii', 'replace')
		return str(text)
	except Exception:
		return ''


# UDATA path
def get_utdata_path():
	if isfile(CERBIOS_INI) and Window(12999).getProperty('Cerbios.Detected'):
		try:
			ini_data = {}
			section = ''
			for line in open(CERBIOS_INI).readlines():
				line = line.strip()
				if line.startswith('[') and line.endswith(']'):
					section = line[1:-1].strip()
					continue
				if '=' in line and not line.startswith(';'):
					key, value = line.split('=', 1)
					ini_data[(section, key.strip().lower())] = value.strip()
			redir = ini_data.get(('', 'tudataredir')) or ini_data.get(('CERBIOS CONFIG EDITOR', 'tudataredir'), 'false')
			if redir.strip().lower() == 'true':
				part_str = ini_data.get(('', 'tudataredirpart')) or ini_data.get(('CERBIOS CONFIG EDITOR', 'tudataredirpart'), '1')
				drive = UDATA_PART_MAP.get(int(part_str.strip()), 'E')
				log('Cerbios UDATA redirect -> {}:\\UDATA'.format(drive))
				return '{}:\\UDATA'.format(drive), '{}:\\TDATA'.format(drive)
		except Exception as error:
			log('get_utdata_path failed: {}'.format(error))
	return 'E:\\UDATA', 'E:\\TDATA'


# Sysinfo
def parse_sysinfo():
	info = {'serial': '', 'hdd_key': '', 'online_key': '', 'xboxmac': ''}
	try:
		for line in open(SYSINFO_PATH).readlines():
			line = line.strip()
			if line.startswith('#') or '=' not in line:
				continue
			key, value = line.split('=', 1)
			key = key.strip()
			value = value.strip().strip('"')
			if key == 'XBOXSerial':
				info['serial'] = value
			elif key == 'HDDKey':
				info['hdd_key'] = value
			elif key == 'OnlineKey':
				info['online_key'] = value
			elif key == 'XBOXMAC':
				info['xboxmac'] = value
	except Exception:
		pass
	return info


def read_sysinfo(dialog = None):
	if dialog:
		dialog.update(25, 'Reading hardware info...')
	if isfile(SYSINFO_PATH):
		try:
			from os import remove
			remove(SYSINFO_PATH)
		except Exception:
			pass
	executebuiltin('BackupSystemInfo')
	while True:
		if isfile(SYSINFO_PATH):
			try:
				from os import stat
				if stat(SYSINFO_PATH).st_size > 0:
					break
			except Exception:
				pass
		sleep(100)
	return parse_sysinfo()


# Signers
def get_signers():
	global SIGNERS_CACHE
	if SIGNERS_CACHE is None:
		try:
			SIGNERS_CACHE = savesigner.load_signers()
			log('get_signers: loaded {} signer(s)'.format(len(SIGNERS_CACHE)))
		except Exception as error:
			log('get_signers: failed: {}'.format(error))
			SIGNERS_CACHE = {}
	return SIGNERS_CACHE


# Game name from titlemeta.xbx
def read_title_name(title_path):
	try:
		meta_path = join(title_path, 'titlemeta.xbx')
		print meta_path
		if isfile(meta_path):
			name = open(meta_path, 'r').read().strip()
			try:
				cleaned = name.decode('utf-16le').strip()
			except UnicodeDecodeError:
				cleaned = name.replace(b'\x00', b'').decode('utf-8', errors='ignore').strip()
			return cleaned.encode('latin-1', 'ignore')[10:]
	except Exception:
		pass
	return ''


# Build list of supported titles that have saves present
def build_game_list(udata_path, tdata_path, signers):
	games = []
	for title_id_int, module in signers.items():
		title_id_str = '{:08X}'.format(title_id_int)
		title_path = join(udata_path, title_id_str)
		if not isdir(title_path):
			continue
		try:
			sub_folders = [f for f in listdir(title_path) if isdir(join(title_path, f))]
		except Exception:
			continue
		if not sub_folders:
			continue
		info = module.get_info()
		signer_name = info.get('title_name', title_id_str)
		# display_name = read_title_name(title_path) or signer_name
		if title_id_str.lower() != PSO_TITLE_ID.lower():
			games.append({
				'title_id': title_id_str,
				'title_path': title_path,
				'display_name': signer_name,
				'pso': False,
			})
		else:
			# Check for PSO quest files in TDATA
			pso_found = False
			try:
				pso_tdata_path = join(tdata_path, PSO_TITLE_ID, '$c')
				for pso_folder in listdir(pso_tdata_path):
					pso_path = join(pso_tdata_path, pso_folder)
					if not isdir(pso_path):
						continue
					for filename in listdir(pso_path):
						if filename.lower().startswith('quest') and filename.lower().endswith('.dat'):
							pso_found = True
							games.append({
								'title_id': PSO_TITLE_ID,
								'title_path': pso_tdata_path,
								'display_name': signer_name,
								'pso': True,
							})
							break
					if pso_found:
						break
			except Exception:
				pass

	games.sort(key = lambda g: g['display_name'].lower())

	return games


# DOAU MAC entry and decode check
def get_doau_src_mac():
	kb = Keyboard('', 'Enter Source Console MAC Address')
	kb.doModal()
	if not kb.isConfirmed():
		return 'cancelled'
	raw = kb.getText().strip()
	normalised = raw.replace(':', '').replace('-', '').upper()
	if len(normalised) != 12:
		return ''
	try:
		normalised.decode('hex')
	except Exception:
		return ''
	return normalised


def verify_doau_decode(title_path, src_mac_hex):
	import os, imp
	signers_folder = None
	for folder in savesigner.SIGNERS_FOLDERS:
		candidate = os.path.join(folder, 'doa_ultimate.py')
		if os.path.isfile(candidate):
			signers_folder = folder
			break
	if signers_folder is None:
		log('verify_doau_decode: doa_ultimate.py not found')
		return False

	module_path = os.path.join(signers_folder, 'doa_ultimate.py')
	sys.path.insert(0, os.path.join(signers_folder, 'crypto'))
	try:
		doau = imp.load_source('doa_ultimate_verify', module_path)
	except Exception as error:
		log('verify_doau_decode: import failed: {}'.format(error))
		return False

	src_mac = src_mac_hex.decode('hex')
	try:
		sub_folders = [f for f in listdir(title_path) if isdir(join(title_path, f))]
	except Exception:
		return False

	for save_folder in sub_folders:
		ups_path = join(title_path, save_folder, 'ups.dat')
		if not isfile(ups_path):
			continue
		try:
			plaintext = doau.decode_ups(ups_path, src_mac)
			if plaintext[:16] == b'\x00' * 16:
				log('verify_doau_decode: decode OK on {}'.format(ups_path))
				return True
			else:
				log('verify_doau_decode: first 16 bytes not zero, wrong MAC')
				return False
		except Exception as error:
			log('verify_doau_decode: error on {}: {}'.format(ups_path, error))
			return False

	log('verify_doau_decode: no ups.dat found in {}'.format(title_path))
	return False


# Resign
def resign_game(game, hdd_key_hex, src_mac_hex = None, dst_mac_hex = None):
	signers = get_signers()
	ok, msg = savesigner.resign_title(
		game['title_id'],
		game['title_path'],
		hdd_key_hex,
		signers,
		src_mac_hex = src_mac_hex,
		dst_mac_hex = dst_mac_hex,
	)
	log('resign_game {}: {}'.format(game['title_id'], msg))
	return ok, msg


# DOAU flow
def handle_doau(game, hdd_key_hex, dst_mac_hex):
	dialog_ok(
		ADDON_ID,
		'[CR]Source MAC address is required to decode DOAU saves.[CR]Enter the MAC address of the console the save came from.',
	)
	src_mac_hex = get_doau_src_mac()
	if src_mac_hex == 'cancelled':
		return
	if not src_mac_hex:
		dialog_ok(
			ADDON_ID,
			'[CR]Source MAC address is required to decode DOAU saves.[CR]Enter the MAC address of the console the save came from.',
		)
		return

	dialog = DialogProgress()
	dialog.create(ADDON_ID, '[CR]Verifying source MAC address...')
	dialog.update(30)
	try:
		valid = verify_doau_decode(game['title_path'], src_mac_hex)
	except Exception as error:
		log('handle_doau: verify error: {}'.format(error))
		valid = False
	dialog.close()

	if not valid:
		dialog_ok(
			ADDON_ID,
			'[CR]The source MAC address did not decode the save correctly.[CR]Check the MAC address and try again.',
			'',
			'The save has not been modified.',
		)
		return

	dialog = DialogProgress()
	dialog.create(ADDON_ID, '[CR]Resigning {} save...'.format(game['display_name']))
	dialog.update(60)
	try:
		ok, msg = resign_game(game, hdd_key_hex, src_mac_hex = src_mac_hex, dst_mac_hex = dst_mac_hex)
	except Exception as error:
		ok = False
		msg = str(error)
	dialog.close()

	if ok:
		notify('{} resigned successfully.'.format(game['display_name']))
	else:
		dialog_ok(ADDON_ID, '[CR]Resign failed: {}'.format(safe(msg)))


# PSO quest flow
def handle_pso(game):
	dialog = DialogProgress()
	dialog.create(ADDON_ID, '[CR]Resigning {}...'.format(game['display_name']))
	dialog.update(30)
	try:
		ok, signed, errors = savesigner.manual_resign_title(game['title_path'], 'pso_quests')
	except Exception as error:
		ok = False
		signed = 0
		errors = 1
		log('handle_pso: {}'.format(error))
	dialog.close()

	if ok:
		notify('{} - {} quest(s) resigned.'.format(game['display_name'].replace(' Quests', ''), signed))
		if errors:
			dialog_ok(ADDON_ID, '[CR]{} quest(s) resigned.[CR]{} quest(s) failed.'.format(signed, errors))
	else:
		dialog_ok(ADDON_ID, '[CR]No PSO quest files found or resign failed.')


# Standard resign saves
def handle_standard(game, hdd_key_hex):
	dialog = DialogProgress()
	dialog.create(ADDON_ID, '[CR]Resigning {} save...'.format(game['display_name']))
	dialog.update(50)
	try:
		ok, msg = resign_game(game, hdd_key_hex)
	except Exception as error:
		ok = False
		msg = str(error)
	dialog.close()

	if ok:
		notify('{} resigned successfully.'.format(game['display_name']))
	else:
		dialog_ok(ADDON_ID, '[CR]Resign failed: {}'.format(safe(msg)))


# Menu
def show_menu():
	udata_path, tdata_path = get_utdata_path()
	signers = get_signers()

	if not signers:
		dialog_ok(ADDON_ID, '[CR]No signers loaded.[CR]Check that script.module.savesigner is installed.')
		return

	dialog = DialogProgress()
	dialog.create(ADDON_ID, '[CR]Reading hardware info...')
	dialog.update(10)
	sysinfo = read_sysinfo(dialog)
	hdd_key_hex = sysinfo['hdd_key'].replace(':', '').replace(' ', '').upper()
	dst_mac_hex = sysinfo.get('xboxmac', '').replace(':', '').replace('-', '').upper()
	dialog.update(50, 'Scanning saves...')

	if not hdd_key_hex or len(hdd_key_hex) != 32:
		dialog.close()
		dialog_ok(ADDON_ID, '[CR]Could not read HDD key from system info.[CR]Make sure XBMC4Gamers has written the EEPROM backup.')
		return

	games = build_game_list(udata_path, tdata_path, signers)
	dialog.close()

	if not games:
		dialog_ok(ADDON_ID, '[CR]No supported saves found.[CR]No saves were found for any supported title.')
		return

	while True:
		executebuiltin('Dialog.Close(1100,true)')
		executebuiltin('Dialog.Close(1112,true)')

		labels = [g['display_name'] for g in games]
		choice = Dialog().select(ADDON_ID, labels)
		if choice < 0:
			break

		game = games[choice]

		if game['pso']:
			if dialog_yesno(
				ADDON_ID,
				'[CR]Resign {} quest files?[CR]This will resign all installed quests for this console.'.format(game['display_name'].replace(' Quests', '')),
				'',
				'',
				'Cancel', 'Resign',
			):
				handle_pso(game)
		elif game['title_id'].upper() == DOAU_TITLE_ID:
			handle_doau(game, hdd_key_hex, dst_mac_hex)
		else:
			if dialog_yesno(
				ADDON_ID,
				'[CR]Resign {} save?[CR]This will overwrite the save with a version signed for this console.'.format(game['display_name']),
				'',
				'',
				'Cancel', 'Resign',
			):
				handle_standard(game, hdd_key_hex)


def main():
	try:
		show_menu()
	except Exception:
		error_message = traceback.format_exc()
		log('FATAL: {}'.format(error_message))
		try:
			dialog_ok('{} Error'.format(ADDON_ID), error_message[:200])
		except Exception:
			pass
