# -*- coding: utf-8 -*-
import xbmc
import gui

from . import tdtxbox


def list_index():
    channels = tdtxbox.get_channels()
    groups = tdtxbox.get_groups(channels)

    gui.add_item("Todos los canales", "tv.png", url_params={"route": "channels"})
    for g in groups:
        gui.add_item(g, "tv.png", url_params={"route": "channels", "group": g})
    gui.add_item(
        "Actualizar lista de canales", "refresh.png", url_params={"route": "refresh"}
    )
    gui.end_listing()


def list_channels(url_params):
    group = url_params.get("group")
    channels = tdtxbox.get_channels()
    if group:
        channels = [c for c in channels if c["group"] == group]

    for ch in channels:
        primary_url = ch["urls"][0]
        gui.add_item(
            ch["name"],
            "tv.png",
            thumb=ch.get("logo") or None,
            url_params={"route": "play", "src": primary_url, "name": ch["name"]},
            video_infotag={"title": ch["name"]},
            is_folder=False,
        )
    gui.end_listing()


def refresh():
    channels = tdtxbox.get_channels(force_refresh=True)
    gui.notification("TDTXBOX", "Lista actualizada: {} canales".format(len(channels)))
    # Un plugin.video tiene que devolver SIEMPRE un listado (aunque sea
    # vacio) cuando la navegacion cae en el, o Kodi lo trata como un
    # fallo de navegacion.
    gui.end_listing()


def play(url_params):
    """Mismo envoltorio que plugin.video.invidious: si _play_impl() no
    resuelve nada, hay que decirselo explicitamente a Kodi o el
    dialogo de "cargando" se queda girando para siempre."""
    resolved = False
    try:
        resolved = _play_impl(url_params)
    finally:
        if not resolved:
            gui.cancel_resolve()


def _play_impl(url_params):
    src = url_params.get("src")
    if not src:
        xbmc.log("plugin.video.tdtxbox play: called without src", xbmc.LOGWARNING)
        return False

    name = url_params.get("name") or "TDTXBOX"
    relay_url = tdtxbox.build_relay_url(src)
    xbmc.log(
        "plugin.video.tdtxbox play: {} ({}) -> {}".format(name, src, relay_url),
        xbmc.LOGNOTICE,
    )
    gui.play(relay_url, title=name, video_infotag={"title": name})
    return True
