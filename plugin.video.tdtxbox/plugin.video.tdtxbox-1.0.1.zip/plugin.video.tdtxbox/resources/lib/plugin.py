import sys
import urlparse
import xbmc

import resources.lib.router as router


class Dictionary(dict):
    def as_bool(self, key, default=None):
        value = self.get(key, None)
        if value is not None:
            return value.lower() == "true"
        if default is not None:
            return default
        raise ValueError("invalid key: '{}'".format(key))


def run():
    url_params = Dictionary(urlparse.parse_qsl(sys.argv[2][1:]))

    route = "index"
    if url_params:
        route = url_params.pop("route", None)

    if route == "index":
        router.list_index()
    elif route == "channels":
        router.list_channels(url_params)
    elif route == "refresh":
        router.refresh()
    elif route == "play":
        router.play(url_params)
    else:
        xbmc.log("plugin.video.tdtxbox: wrong route: '{}'".format(route), xbmc.LOGNOTICE)
