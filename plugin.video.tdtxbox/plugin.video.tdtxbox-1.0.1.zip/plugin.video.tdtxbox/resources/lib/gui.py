import os
import sys
import urllib
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

ADDON_HANDLE = int(sys.argv[1])
ADDON_VFS_PATH = sys.argv[0]

addon = xbmcaddon.Addon()


def add_item(
    title,
    icon=None,
    thumb=None,
    url=None,
    url_params=None,
    video_infotag=None,
    is_folder=True,
    total_items=0,
):
    item = xbmcgui.ListItem(title)

    art = {}
    if icon:
        art["icon"] = os.path.join(
            addon.getAddonInfo("path"), "resources", "media", icon
        )
    if thumb:
        art["thumb"] = thumb
    item.setArt(art)

    if not url:
        url = "{}?{}".format(ADDON_VFS_PATH, urllib.urlencode(url_params))

    if video_infotag is not None:
        item.setInfo("video", video_infotag)
    if not is_folder:
        item.setProperty("IsPlayable", "True")

    return xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, item, is_folder, total_items)


def end_listing():
    return xbmcplugin.endOfDirectory(ADDON_HANDLE)


def cancel_resolve():
    """Mismo motivo que en plugin.video.invidious: sin esto, si play()
    decide no reproducir nada, el dialogo de "cargando" de Kodi se
    queda girando para siempre."""
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())


def play(url, title=None, video_infotag=None):
    item = xbmcgui.ListItem(title, path=url)
    if video_infotag is not None:
        item.setInfo("video", video_infotag)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, item)


def notification(heading, message, time=5000):
    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_INFO, time)
