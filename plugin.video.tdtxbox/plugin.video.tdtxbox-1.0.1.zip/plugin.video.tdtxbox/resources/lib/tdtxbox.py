# -*- coding: utf-8 -*-
"""
Descarga y parsea la lista de canales de tdtchannels.com
(https://github.com/laquay/tdtchannels), y construye las URLs hacia
tdt-relay (ver mini-pc/tdt-relay/), el companion en el mini PC/VM que
transcodifica cada canal a MPEG4/Xvid en tiempo real - esta Xbox no
puede descodificar el H.264 original con fluidez (mismo motivo, y
misma solucion, que plugin.video.invidious/invidious-download).
"""
import re
import time
import urllib
import urllib2

import xbmc

from .gui import addon
from .storage import load_storage, sync_storage

DEFAULT_M3U_URL = "https://www.tdtchannels.com/lists/tv.m3u8"
REQUEST_TIMEOUT = 15

# tdtchannels.com devuelve 403 Forbidden al User-Agent por defecto de
# urllib2 de Python ("Python-urllib/2.7") - confirmado el 19/09/2026
# comparando con curl (200 con su UA por defecto o con uno de
# navegador, 403 solo con el de Python). No hace falta imitar un
# navegador real, basta con no ser identificable como el UA de
# libreria por defecto.
REQUEST_USER_AGENT = "Mozilla/5.0 (compatible; TDTXBOX/1.0)"

# La lista de tdtchannels.com no cambia con frecuencia (son canales de
# TV, no un catalogo dinamico) - una cache de varias horas evita
# descargarla y parsearla en cada apertura del addon sin arriesgarse a
# quedarse con una lista muy desactualizada.
CACHE_SECONDS = 6 * 60 * 60

_MINIPC_NETBIOS_NAME = "XBOXMINIPC"
# Mismo valor de respaldo que usa plugin.video.invidious si la
# resolucion NBNS falla (mini PC/VM apagado, timing raro al arrancar).
_RELAY_FALLBACK_IP = "192.168.1.134"
RELAY_PORT = 3003

_EXTINF_RE = re.compile(r'#EXTINF:-?\d+(?:\.\d+)?\s*(.*?),(.*)$')
_ATTR_RE = re.compile(r'([\w-]+)="([^"]*)"')


def _relay_host():
    try:
        from nbnsresolve import resolve_netbios_name
        ip = resolve_netbios_name(_MINIPC_NETBIOS_NAME)
    except Exception as e:
        xbmc.log(
            "plugin.video.tdtxbox: fallo resolviendo {} por NBNS: {}".format(
                _MINIPC_NETBIOS_NAME, e
            ),
            xbmc.LOGDEBUG,
        )
        ip = None
    if ip:
        xbmc.log(
            "plugin.video.tdtxbox: {} resuelto por NBNS a {}".format(_MINIPC_NETBIOS_NAME, ip),
            xbmc.LOGDEBUG,
        )
    else:
        xbmc.log(
            "plugin.video.tdtxbox: NBNS no respondio, usando IP de respaldo {}".format(
                _RELAY_FALLBACK_IP
            ),
            xbmc.LOGDEBUG,
        )
    return ip or _RELAY_FALLBACK_IP


def build_relay_url(source_url):
    host = _relay_host()
    return "http://{}:{}/tdt?url={}".format(
        host, RELAY_PORT, urllib.quote(source_url, safe="")
    )


def _parse_m3u(text):
    """
    Cada canal en la lista de tdtchannels.com es un par de lineas
    #EXTINF (metadatos: group-title, tvg-logo...) + URL, y un mismo
    canal puede repetirse varias veces seguidas con distintas URLs
    (mirrors/respaldos, ej. La 1 tiene una URL de RTVE y otra de
    Ottera). Se agrupan bajo el mismo canal (nombre+categoria); solo la
    primera URL se usa por ahora (ver TODO en list_channels de
    router.py sobre probar las alternativas si la principal falla).
    """
    channels = []
    by_key = {}
    pending = None

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("#EXTINF"):
            m = _EXTINF_RE.match(line)
            if not m:
                pending = None
                continue
            attrs = dict(_ATTR_RE.findall(m.group(1)))
            name = m.group(2).strip()
            # "text" (el .m3u8 completo) se decodifico a unicode antes
            # de llegar aqui - un valor unicode con acentos (nombres de
            # categoria como "País Vasco") rompe mas adelante con
            # UnicodeEncodeError en cuanto pasa por urllib.urlencode()
            # (confirmado en la Xbox real, 19/09/2026): Python 2 hace
            # str(valor) por dentro, que solo sabe ASCII. Se codifica a
            # UTF-8 aqui, en el borde del parseo, para que nada unicode
            # se cuele en el resto del addon.
            pending = {
                "name": name.encode("utf-8"),
                "group": (attrs.get("group-title") or "Otros").encode("utf-8"),
                "logo": (attrs.get("tvg-logo") or "").encode("utf-8"),
            }
        elif line.startswith("#"):
            continue
        else:
            if pending is None:
                continue
            key = (pending["name"], pending["group"])
            if key in by_key:
                by_key[key]["urls"].append(line.encode("utf-8"))
            else:
                entry = dict(pending)
                entry["urls"] = [line.encode("utf-8")]
                by_key[key] = entry
                channels.append(entry)
            pending = None

    return channels


def _cache_key(m3u_url):
    return "channels_{}".format(abs(hash(m3u_url)))


def _channel_field_to_str(value):
    """El propio modulo json de Python 2 siempre devuelve unicode al
    leer un string (JSON no distingue "str" de "unicode" como tipos
    distintos) - asi que codificar a UTF-8 solo en _parse_m3u() (ver
    mas abajo) no basta: eso deja bien el resultado de la PRIMERA
    llamada (parseo en caliente), pero json.load() en cualquier
    llamada posterior que acierte la cache (load_storage() mas abajo)
    vuelve a devolver unicode para esos mismos campos, reintroduciendo
    el mismo UnicodeEncodeError de antes (confirmado en la Xbox real,
    19/09/2026: list_index funcionaba - primera llamada, sin cache -
    pero list_channels reventaba justo despues - cache ya escrita)."""
    if isinstance(value, unicode):
        return value.encode("utf-8")
    return value


def _channels_to_str(channels):
    result = []
    for ch in channels:
        result.append({
            "name": _channel_field_to_str(ch.get("name", "")),
            "group": _channel_field_to_str(ch.get("group", "")),
            "logo": _channel_field_to_str(ch.get("logo", "")),
            "urls": [_channel_field_to_str(u) for u in ch.get("urls", [])],
        })
    return result


def get_channels(force_refresh=False):
    m3u_url = addon.getSetting("m3u_url") or DEFAULT_M3U_URL
    storage_name = _cache_key(m3u_url)

    if not force_refresh:
        cached = load_storage(storage_name)
        if cached and (time.time() - cached.get("fetched_at", 0)) < CACHE_SECONDS:
            return _channels_to_str(cached.get("channels", []))

    try:
        request = urllib2.Request(m3u_url, headers={"User-Agent": REQUEST_USER_AGENT})
        resp = urllib2.urlopen(request, timeout=REQUEST_TIMEOUT)
        text = resp.read()
        if isinstance(text, bytes):
            text = text.decode("utf-8", "replace")
    except Exception as e:
        xbmc.log(
            "plugin.video.tdtxbox: fallo descargando {}: {}".format(m3u_url, e),
            xbmc.LOGWARNING,
        )
        # Si la descarga falla, se prefiere devolver una lista vieja
        # (aunque este caducada) antes que dejar el addon vacio.
        cached = load_storage(storage_name)
        if cached:
            return _channels_to_str(cached.get("channels", []))
        return []

    channels = _parse_m3u(text)
    sync_storage(storage_name, {"fetched_at": time.time(), "channels": channels})
    return channels


def get_groups(channels):
    groups = []
    seen = set()
    for ch in channels:
        g = ch["group"]
        if g not in seen:
            seen.add(g)
            groups.append(g)
    return groups
