import os
import imp

# Title info
TITLE_ID = 0x4C410019
TITLE_NAME = 'Star Wars: Republic Commando (NTSC-J)'
REGION = 'NTSC-J'

_module = imp.load_source(
	'star_wars_republic_commando_primary',
	os.path.join(os.path.dirname(os.path.abspath(__file__)), 'star_wars_republic_commando.py'),
)


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	return _module.sign(xbox_hd_key, file_path, sig_path)
