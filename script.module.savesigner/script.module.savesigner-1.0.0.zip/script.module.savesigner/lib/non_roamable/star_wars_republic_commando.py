import hmac
import hashlib
import os
import struct

# Title info
TITLE_ID = 0x4C410013
TITLE_NAME = 'Star Wars: Republic Commando'
REGION = 'NTSC-U / PAL'

# Title IDs
TITLE_ID_NTSC = 0x4C410013
TITLE_ID_JP = 0x4C410019

# Keys
TITLE_SIGNATURE_KEY_NTSC = '88C3BC25F5BB1DE11F1F6FCE21BF7F74'
TITLE_SIGNATURE_KEY_JP = '54731ABF22F0EA8687AAA6478F4BAAEA'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
CTS_FILE_SIZE = 0xEFFF0


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	filename = os.path.basename(file_path).lower()
	file_size = os.path.getsize(file_path)

	if file_size <= SIGNATURE_SIZE + 4:
		return (False, 'File too small: {0}'.format(file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	# Get region from folder title ID
	parts = file_path.replace('\\', '/').split('/')
	title_id_str = ''
	for part in parts:
		if len(part) == 8:
			try:
				int(part, 16)
				title_id_str = part.upper()
			except ValueError:
				pass

	if title_id_str == '{:08X}'.format(TITLE_ID_JP):
		title_sig_key_hex = TITLE_SIGNATURE_KEY_JP
	else:
		title_sig_key_hex = TITLE_SIGNATURE_KEY_NTSC

	if file_size != CTS_FILE_SIZE:
		null_dword = struct.unpack_from('<I', data, file_size - SIGNATURE_SIZE - 4)[0]
		first_byte = data[0:1]
		if null_dword != 0 and first_byte != b'[':
			return (False, 'Skipped (unknown file type): {0}'.format(file_path))

	sig_area_size = file_size - SIGNATURE_SIZE - 4
	sig_offset = file_size - SIGNATURE_SIZE

	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = title_sig_key_hex.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	roamable = hmac.new(auth_key, data[:sig_area_size], hashlib.sha1).digest()
	final_sig = hmac.new(xbox_hd_key, roamable, hashlib.sha1).digest()

	patched = data[:sig_offset] + final_sig
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
