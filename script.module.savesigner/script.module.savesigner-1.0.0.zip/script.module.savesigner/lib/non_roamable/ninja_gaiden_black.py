import hmac
import hashlib
import os

# Title info
TITLE_ID = 0x5443000D
TITLE_NAME = 'Ninja Gaiden Black'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
TITLE_SIGNATURE_KEY = ('FC3376488B3E5F00F65A6BDA9209CFE8')
XBOX_CERT_KEY = ('5C0733AE0401F7E8BA7993FDCD2F1FE0')

# Constants
VALID_FILE_SIZES = {
	0x174A8: 'save',
	0x550: 'settings',
}

SIGNATURE_SIZE = 20
KEY_SIZE = 16


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size not in VALID_FILE_SIZES:
		return (False, 'Unknown file size 0x{0:X} for: {1}'.format(file_size, file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	auth_key = hmac.new(XBOX_CERT_KEY.decode('hex'), TITLE_SIGNATURE_KEY.decode('hex'), hashlib.sha1).digest()[:KEY_SIZE]
	roamable = hmac.new(auth_key, data[SIGNATURE_SIZE:], hashlib.sha1).digest()
	final_sig = hmac.new(xbox_hd_key, roamable, hashlib.sha1).digest()

	patched = final_sig + data[SIGNATURE_SIZE:]
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
