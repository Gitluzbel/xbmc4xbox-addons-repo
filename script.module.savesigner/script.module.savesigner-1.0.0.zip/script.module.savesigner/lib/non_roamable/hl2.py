import hmac
import hashlib
import struct
import os

# Title info
TITLE_ID = 0x45410091
TITLE_NAME = 'Half-Life 2'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
TITLE_SIGNATURE_KEY = ('CCB0F5720B1478A0B2C518AB429E7DEA')
XBOX_CERT_KEY = ('5C0733AE0401F7E8BA7993FDCD2F1FE0')

# Constants
JSAV_MAGIC = 0x5641534A
SIGNATURE_SIZE = 20
KEY_SIZE = 16
ALLOWED_EXTS = ('.hl1', '.hl2', '.hl3')
SKIP_FILES = ('savemeta.xbx', 'saveimage.xbx', 'datelinfo.xbx')
ALLOWED_NAMES = ('continue.cfg', 'xboxuser.cfg', '_transition', 'autosave')


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


# File helpers
def allowed_file(name):
	low = name.lower()
	if low in SKIP_FILES:
		return False
	if low in ALLOWED_NAMES:
		return True
	if low.startswith('save'):
		return True
	for ext in ALLOWED_EXTS:
		if low.endswith(ext):
			return True
	return False


# Crypto helpers
def make_auth_key():
	return hmac.new(XBOX_CERT_KEY.decode('hex'), TITLE_SIGNATURE_KEY.decode('hex'), hashlib.sha1).digest()[:KEY_SIZE]


def sign_block(auth_key, xbox_hd_key, data_block):
	roamable = hmac.new(auth_key, data_block, hashlib.sha1).digest()
	return hmac.new(xbox_hd_key, roamable, hashlib.sha1).digest()


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	name = os.path.basename(file_path)
	if not allowed_file(name):
		return (False, 'Skipped: {0}'.format(file_path))

	with open(file_path, 'rb') as fh:
		data = bytearray(fh.read())

	file_size = len(data)
	auth_key = make_auth_key()

	if file_size < 4:
		return (False, 'File too small: {0}'.format(file_path))

	magic = struct.unpack_from('<I', data, 0)[0]

	if magic == JSAV_MAGIC:
		block_size = 0x108F + struct.unpack_from('<I', data, 8)[0]
		block_offset = 0
		total_size = block_size
		blocks_signed = 0

		while True:
			sig_area = block_size - SIGNATURE_SIZE
			sig = sign_block(auth_key, xbox_hd_key, bytes(data[block_offset:block_offset + sig_area]))
			data[block_offset + sig_area:block_offset + sig_area + SIGNATURE_SIZE] = sig
			blocks_signed += 1

			if total_size == file_size:
				break

			block_offset += block_size + 0x108
			block_size = struct.unpack_from('<I', data, block_offset - 4)[0]
			total_size += 0x108 + block_size

		with open(file_path, 'wb') as fh:
			fh.write(bytes(data))

		return (True, 'Signed {0} JSAV block(s) -> {1}'.format(blocks_signed, file_path))

	else:
		sig_offset = file_size - SIGNATURE_SIZE
		sig = sign_block(auth_key, xbox_hd_key, bytes(data[:sig_offset]))
		data[sig_offset:] = sig

		with open(file_path, 'wb') as f:
			f.write(bytes(data))

		return (True, 'Signed -> {0}'.format(file_path))
