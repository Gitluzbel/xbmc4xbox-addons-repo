import hmac
import hashlib
import os

# Title info
TITLE_ID = 0x5553005E
TITLE_NAME = 'Splinter Cell: Double Agent'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
TITLE_SIGNATURE_KEY = '61676F08B31D71DCF8E02903CB5164BB'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16

VALID_FILE_SIZES = frozenset([
	0x2625A0, # save game
	0x8094, # save image
	0x264C, # profile
])

SKIP_FILE_SIZE = 0x8080


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)

	if file_size == SKIP_FILE_SIZE:
		return (False, 'Skipped (image not initialized): {0}'.format(file_path))

	if file_size not in VALID_FILE_SIZES:
		return (False, 'Skipped (unknown size 0x{0:X}): {1}'.format(file_size, file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	sig_offset = file_size - SIGNATURE_SIZE
	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	roamable = hmac.new(auth_key, data[:sig_offset], hashlib.sha1).digest()
	final_sig = hmac.new(xbox_hd_key, roamable, hashlib.sha1).digest()

	patched = data[:sig_offset] + final_sig
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
