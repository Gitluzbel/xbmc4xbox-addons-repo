import hmac
import hashlib
import os

# Title info
TITLE_ID = 0x4D53006E
TITLE_NAME = 'Forza Motorsport'
REGION = 'NTSC-U'

# Keys
# Credit to kreet (roofus) for ForzaSign.
# Hardcoded key from ForzaSign.exe 
# UPX packed "upx -d ForzaSign.exe" (https://github.com/upx/upx/releases/tag/v5.2.0)
# .data section 0x403000 or 0x3000 in the binary.
# This key is used as key1 in the two pass HMAC chain.
TITLE_KEY = ('909260B0E496746D5A1DC067A694F830')

# Constants
# XPR car icon files signed individually. Sigs stored in CarIcons.sig
XPR_FILES = ('CarIcons1.xpr',
	'CarIcons2.xpr',
	'CarIcons3.xpr',
	'CarIcons4.xpr',
	'CarIcons5.xpr',
)

# Files signed with sig at the last 20 bytes
STANDARD_FILES = ('UserProfile.xml',
	'Garage.dat',
	'Garage.bin',
	'Replays',
	'Ghosts',
)

SKIP_FILES = ('savemeta.xbx',
	'saveimage.xbx',
)

SIG_FILE = 'CarIcons.sig'

SIGNATURE_SIZE = 20
KEY_SIZE = 16


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


# File helpers
def allowed_file(name):
	low = name.lower()
	if low in SKIP_FILES:
		return False
	if name in STANDARD_FILES:
		return True
	if name in XPR_FILES:
		return True
	if name == SIG_FILE:
		return True
	if name.startswith('Leaderboard'):
		return True
	return False


# Crypto helpers
def sign_block(xbox_hd_key, data_block):
	pass1 = hmac.new(TITLE_KEY.decode('hex'), data_block, hashlib.sha1).digest()
	return hmac.new(xbox_hd_key, pass1, hashlib.sha1).digest()


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	name = os.path.basename(file_path)
	folder = os.path.dirname(file_path)

	if not allowed_file(name):
		return (False, 'Skipped: {0}'.format(file_path))

	# XPR file or CarIcons.sig, rebuild CarIcons.sig from all XPR files
	if name in XPR_FILES or name == SIG_FILE:
		xpr_sigs = []
		for fname in XPR_FILES:
			path = os.path.join(folder, fname)
			if not os.path.isfile(path):
				xpr_sigs.append('\x00' * SIGNATURE_SIZE)
				continue
			data = open(path, 'rb').read()
			xpr_sigs.append(sign_block(xbox_hd_key, data))

		first5 = ''.join(xpr_sigs)
		master_sig = sign_block(xbox_hd_key, first5)
		sig_full = os.path.join(folder, SIG_FILE)
		open(sig_full, 'wb').write(first5 + master_sig)
		return (True, 'Signed -> {0}'.format(sig_full))

	# Standard file, Leaderboard*, Replays, Ghosts, overwrite last 20 bytes
	data = bytearray(open(file_path, 'rb').read())
	if len(data) < SIGNATURE_SIZE:
		return (False, 'File too small: {0}'.format(file_path))

	sig = sign_block(xbox_hd_key, bytes(data[:-SIGNATURE_SIZE]))
	data[-SIGNATURE_SIZE:] = sig
	open(file_path, 'wb').write(bytes(data))
	return (True, 'Signed -> {0}'.format(file_path))
