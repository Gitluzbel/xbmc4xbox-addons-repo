import os
import imp

# Title info
TITLE_ID = 0x4D530059
TITLE_NAME = 'Fatal Frame (PAL)'
REGION = 'PAL'

_module = imp.load_source(
	'fatal_frame_primary',
	os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fatal_frame.py'),
)


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	return _module.sign(xbox_hd_key, file_path, sig_path)
