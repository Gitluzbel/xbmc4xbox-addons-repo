import struct

MT_N = 624
MT_M = 397
MT_MATRIX_A = 0x9908b0df


def mt_init_genrand(seed):
	mt = [0] * MT_N
	mt[0] = seed & 0xffffffff
	for i in xrange(1, MT_N):
		mt[i] = (0x6c078965 * (mt[i - 1] ^ (mt[i - 1] >> 30)) + i) & 0xffffffff
	return mt


def mt_init_by_array(key):
	mt = mt_init_genrand(0x012bd6aa)
	kl = len(key)
	k = max(MT_N, kl)
	i = 1
	j = 0
	for _ in xrange(k):
		mt[i] = ((mt[i] ^ ((mt[i - 1] ^ (mt[i - 1] >> 30)) * 0x19660d)) + key[j] + j) & 0xffffffff
		i += 1
		j += 1
		if i >= MT_N:
			mt[0] = mt[MT_N - 1]
			i = 1
		if j >= kl:
			j = 0
	for _ in xrange(MT_N - 1):
		mt[i] = ((mt[i] ^ ((mt[i - 1] ^ (mt[i - 1] >> 30)) * 0x5d588b65)) - i) & 0xffffffff
		i += 1
		if i >= MT_N:
			mt[0] = mt[MT_N - 1]
			i = 1
	mt[0] = 0x80000000
	return mt


def mt_generate(mt):
	new_mt = mt[:]
	for i in xrange(MT_N - MT_M):
		y = (new_mt[i] & 0x80000000) | (new_mt[i + 1] & 0x7fffffff)
		new_mt[i] = new_mt[i + MT_M] ^ (y >> 1) ^ (MT_MATRIX_A if (y & 1) else 0)
	for i in xrange(MT_N - MT_M, MT_N - 1):
		y = (new_mt[i] & 0x80000000) | (new_mt[i + 1] & 0x7fffffff)
		new_mt[i] = new_mt[i + MT_M - MT_N] ^ (y >> 1) ^ (MT_MATRIX_A if (y & 1) else 0)
	y = (new_mt[MT_N - 1] & 0x80000000) | (new_mt[0] & 0x7fffffff)
	new_mt[MT_N - 1] = new_mt[MT_M - 1] ^ (y >> 1) ^ (MT_MATRIX_A if (y & 1) else 0)
	return new_mt


def mt_temper(y):
	y ^= y >> 11
	y ^= ((y & 0xff3a58ad) << 7) & 0xffffffff
	y ^= ((y & 0xffffdf8c) << 15) & 0xffffffff
	y ^= y >> 18
	return y & 0xffffffff