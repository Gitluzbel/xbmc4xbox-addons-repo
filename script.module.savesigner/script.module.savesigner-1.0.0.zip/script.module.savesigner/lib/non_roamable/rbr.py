import hmac
import hashlib
import os

# Title info
TITLE_ID = 0x53430005
TITLE_NAME = 'Richard Burns Rally'
REGION = 'PAL'

# Keys
TITLE_SIGNATURE_KEY = ('BFD9EF83979291CEE2FBB44E03EAD982')
XBOX_CERT_KEY = ('5C0733AE0401F7E8BA7993FDCD2F1FE0')

# Constants
VALID_FILE_SIZES = {
	0x26000: 'profile',
	0xF000: 'replay',
	0x4000: 'race result',
}

SIGNATURE_FILE = 'signa.tur'
SIGNATURE_SIZE = 20
KEY_SIZE = 16


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size not in VALID_FILE_SIZES:
		return (False, 'Unknown file size 0x{0:X} for: {1}'.format(file_size, file_path))

	with open(file_path, 'rb') as fh:
		file_data = fh.read()

	if sig_path is None:
		sig_path = os.path.join(os.path.dirname(file_path), SIGNATURE_FILE)

	auth_key = hmac.new(XBOX_CERT_KEY.decode('hex'), TITLE_SIGNATURE_KEY.decode('hex'), hashlib.sha1).digest()[:KEY_SIZE]
	roamable_sig = hmac.new(auth_key, file_data, hashlib.sha1).digest()
	final_sig = hmac.new(xbox_hd_key, roamable_sig, hashlib.sha1).digest()

	with open(sig_path, 'wb') as fh:
		fh.write(final_sig)

	return (True, 'Signed OK -> {0}'.format(sig_path))
