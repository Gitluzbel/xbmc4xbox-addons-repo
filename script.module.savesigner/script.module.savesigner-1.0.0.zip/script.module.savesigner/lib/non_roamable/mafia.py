import hmac
import hashlib
import os

# Title info
TITLE_ID = 0x54540009
TITLE_NAME = 'Mafia'
REGION = 'NTSC-U / PAL'

# Keys
TITLE_SIGNATURE_KEY = '7F2BFB0822D125B958DAA8E9C640B83D'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16

KNOWN_FILENAMES = frozenset([
	'mafia.000', 'mafia.005', 'mafia.010', 'mafia.015', 'mafia.020', 'mafia.025',
	'mafia.030', 'mafia.040', 'mafia.045', 'mafia.050', 'mafia.055', 'mafia.060',
	'mafia.065', 'mafia.070', 'mafia.075', 'mafia.080', 'mafia.085', 'mafia.090',
	'mafia.095', 'mafia.100', 'mafia.105', 'mafia.110', 'mafia.115', 'mafia.130',
	'mafia.131', 'mafia.135', 'mafia.140', 'mafia.145', 'mafia.146', 'mafia.150',
	'mafia.155', 'mafia.160', 'mafia.165', 'mafia.170', 'mafia.185', 'mafia.190',
	'mafia.195', 'mafia.197', 'mafia.200', 'mafia.205', 'mafia.220', 'mafia.223',
	'mafia.225', 'mafia.230', 'mafia.235', 'mafia.240', 'mafia.243', 'mafia.245',
	'mafia.260', 'mafia.263', 'mafia.265', 'mafia.270', 'mafia.275', 'mafia.277',
	'mafia.280', 'mafia.290', 'mafia.295', 'mafia.310', 'mafia.315', 'mafia.320',
	'mafia.325', 'mafia.330', 'mafia.335', 'mafia.340', 'mafia.345', 'mafia.350',
	'mafia.355', 'mafia.360', 'mafia.370', 'mafia.372', 'mafia.375', 'mafia.380',
	'mafia.385', 'mafia.390', 'mafia.405', 'mafia.407', 'mafia.410', 'mafia.415',
	'mafia.425', 'mafia.430', 'mafia.435', 'mafia.440', 'mafia.452', 'mafia.455',
	'mafia.460', 'mafia.465', 'mafia.466', 'mafia.470', 'mafia.475', 'mafia.487',
	'mafia.490', 'mafia.495', 'mafia.497', 'mafia.500', 'mafia.505', 'mafia.520',
	'mafia.525', 'mafia.530', 'mafia.532', 'mafia.535', 'mafia.540', 'mafia.550',
	'mafia.552', 'mafia.555', 'mafia.557', 'mafia.560', 'mafia.561', 'mafia.570',
	'mafia.sav', 'mr.sav',
])


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	if os.path.basename(file_path).lower() not in KNOWN_FILENAMES:
		return (False, 'Skipped: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size <= SIGNATURE_SIZE:
		return (False, 'File too small: {0}'.format(file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	sig_offset = file_size - SIGNATURE_SIZE
	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	roamable = hmac.new(auth_key, data[:sig_offset], hashlib.sha1).digest()
	final_sig = hmac.new(xbox_hd_key, roamable, hashlib.sha1).digest()

	patched = data[:sig_offset] + final_sig
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
