import hmac
import hashlib
import os
import struct

# Title info
TITLE_ID = 0x5443000A
TITLE_NAME = 'Fatal Frame 2'
REGION = 'NTSC-U / PAL'

# Keys
TITLE_SIGNATURE_KEY = 'FEE1A3D52ABAD9171B19E91F7B771535'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
GAME_FILE_SIZE = 0x258A3AA
HEADER_FILE_SIZE = 0x34
FIRST_BLOCK_SIZE = 0x9BC6
SECONDARY_BLOCK_SIZE = 0x60000
SECONDARY_BLOCK_COUNT = 0x64


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def _sign_block(xbox_hd_key, block_data):
	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	roamable = hmac.new(auth_key, block_data, hashlib.sha1).digest()
	return hmac.new(xbox_hd_key, roamable, hashlib.sha1).digest()


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size != GAME_FILE_SIZE and file_size != HEADER_FILE_SIZE:
		return (False, 'Skipped (wrong size 0x{0:X}): {1}'.format(file_size, file_path))

	with open(file_path, 'rb') as fh:
		buf = bytearray(fh.read())

	if file_size == GAME_FILE_SIZE:
		offset = 0

		# First block
		block_data = bytes(buf[offset : offset + FIRST_BLOCK_SIZE])
		sig = _sign_block(xbox_hd_key, block_data)
		buf[offset + FIRST_BLOCK_SIZE : offset + FIRST_BLOCK_SIZE + SIGNATURE_SIZE] = sig
		offset += FIRST_BLOCK_SIZE + SIGNATURE_SIZE

		# Secondary blocks
		for _ in range(SECONDARY_BLOCK_COUNT):
			block_data = bytes(buf[offset : offset + SECONDARY_BLOCK_SIZE])
			sig = _sign_block(xbox_hd_key, block_data)
			buf[offset + SECONDARY_BLOCK_SIZE : offset + SECONDARY_BLOCK_SIZE + SIGNATURE_SIZE] = sig
			offset += SECONDARY_BLOCK_SIZE + SIGNATURE_SIZE

		blocks_signed = SECONDARY_BLOCK_COUNT + 1

	else:
		# Header file: single block, data is everything before the sig
		block_size = HEADER_FILE_SIZE - SIGNATURE_SIZE
		block_data = bytes(buf[0 : block_size])
		sig = _sign_block(xbox_hd_key, block_data)
		buf[block_size : block_size + SIGNATURE_SIZE] = sig
		blocks_signed = 1

	with open(file_path, 'wb') as fh:
		fh.write(bytes(buf))

	return (True, 'Signed OK ({0} blocks) -> {1}'.format(blocks_signed, file_path))
