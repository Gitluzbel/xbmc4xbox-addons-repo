import hmac
import hashlib
import os
import struct

# Title info
TITLE_ID = 0x4D53004A
TITLE_NAME = 'Phantasy Star Online Quests'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
TITLE_SIGNATURE_KEY = 'E1F49B7D45AFEAA21D5718709828A8B8'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
MIN_FILE_SIZE = 0x4000
BLOCK_HEADER_SIZE = 0x2048
CRC_OFFSET = 0x2044


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


# CRC32
def _crc32(data):
	table = [0] * 256
	for i in range(256):
		c = i
		for _ in range(8):
			if c & 1:
				c = 0xEDB88320 ^ (c >> 1)
			else:
				c >>= 1
		table[i] = c
	crc = 0xFFFFFFFF
	for byte in (ord(b) if isinstance(b, str) else b for b in data):
		crc = table[(crc ^ byte) & 0xFF] ^ (crc >> 8)
	return crc ^ 0xFFFFFFFF


# Validation
def validate(file_path):
	try:
		with open(file_path, 'rb') as fh:
			raw = fh.read()
		file_size = len(raw)
		if file_size < MIN_FILE_SIZE:
			return False, 0, 'file too small'
		block_size = struct.unpack_from('<I', raw, 0x14)[0]
		if (block_size + MIN_FILE_SIZE) != file_size or block_size <= BLOCK_HEADER_SIZE:
			return False, 0, 'bad block size'
		block = bytearray(raw[MIN_FILE_SIZE : MIN_FILE_SIZE + BLOCK_HEADER_SIZE])
		stored_crc = struct.unpack_from('<I', block, CRC_OFFSET)[0]
		struct.pack_into('<I', block, CRC_OFFSET, 0)
		if _crc32(bytes(block)) != stored_crc:
			return False, 0, 'CRC mismatch'
		return True, block_size, 'OK'
	except Exception as error:
		return False, 0, str(error)


# Sign
def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	if not file_path.lower().endswith('.dat'):
		return (False, 'Skipped: {0}'.format(file_path))

	valid, block_size, msg = validate(file_path)
	if not valid:
		return (False, 'Skipped ({0}): {1}'.format(msg, file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	data_length = 0x3FEC + block_size
	quest_data = data[0x14 : 0x14 + data_length]

	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	content_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	roamable = hmac.new(content_key, quest_data, hashlib.sha1).digest()
	final_sig = hmac.new(xbox_hd_key, roamable, hashlib.sha1).digest()

	patched = final_sig + data[SIGNATURE_SIZE:]
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
