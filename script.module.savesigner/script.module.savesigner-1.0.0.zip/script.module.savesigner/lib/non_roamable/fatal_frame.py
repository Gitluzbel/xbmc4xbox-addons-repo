import hmac
import hashlib
import os
import struct

# Title info
TITLE_ID = 0x54430004
TITLE_NAME = 'Fatal Frame'
REGION = 'NTSC-U / PAL'

# Title IDs
TITLE_ID_NTSC = 0x54430004
TITLE_ID_PAL = 0x4D530059

# Keys
TITLE_SIGNATURE_KEY_NTSC = 'BD1E1C7B4DB4BA8D49E37EA24F80F14E'
TITLE_SIGNATURE_KEY_PAL = '0D07E43488A315BF1BDC3B47E0B46B24'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
SAVE_FILE_SIZE = 0x2945CC0
FIRST_BLOCK_SIZE = 0x5414
SECONDARY_BLOCK_SIZE = 0x60000
SECONDARY_BLOCK_COUNT = 0x6E


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def _sign_block(xbox_hd_key, title_sig_key_hex, data, sig_offset):
	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = title_sig_key_hex.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	roamable = hmac.new(auth_key, data, hashlib.sha1).digest()
	return hmac.new(xbox_hd_key, roamable, hashlib.sha1).digest()


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size != SAVE_FILE_SIZE:
		return (False, 'Skipped (wrong size 0x{0:X}): {1}'.format(file_size, file_path))

	# Determine region from parent folder title ID
	parts = file_path.replace('\\', '/').split('/')
	title_id_str = ''
	for part in parts:
		if len(part) == 8:
			try:
				int(part, 16)
				title_id_str = part.upper()
			except ValueError:
				pass

	if title_id_str == '{:08X}'.format(TITLE_ID_PAL):
		title_sig_key_hex = TITLE_SIGNATURE_KEY_PAL
	else:
		title_sig_key_hex = TITLE_SIGNATURE_KEY_NTSC

	with open(file_path, 'rb') as fh:
		buf = bytearray(fh.read())

	offset = 0

	# First block
	block_data = bytes(buf[offset : offset + FIRST_BLOCK_SIZE])
	sig = _sign_block(xbox_hd_key, title_sig_key_hex, block_data, offset)
	buf[offset + FIRST_BLOCK_SIZE : offset + FIRST_BLOCK_SIZE + SIGNATURE_SIZE] = sig
	offset += FIRST_BLOCK_SIZE + SIGNATURE_SIZE

	# Secondary blocks
	for _ in range(SECONDARY_BLOCK_COUNT):
		block_data = bytes(buf[offset : offset + SECONDARY_BLOCK_SIZE])
		sig = _sign_block(xbox_hd_key, title_sig_key_hex, block_data, offset)
		buf[offset + SECONDARY_BLOCK_SIZE : offset + SECONDARY_BLOCK_SIZE + SIGNATURE_SIZE] = sig
		offset += SECONDARY_BLOCK_SIZE + SIGNATURE_SIZE

	with open(file_path, 'wb') as fh:
		fh.write(bytes(buf))

	return (True, 'Signed OK ({0} blocks) -> {1}'.format(SECONDARY_BLOCK_COUNT + 1, file_path))
