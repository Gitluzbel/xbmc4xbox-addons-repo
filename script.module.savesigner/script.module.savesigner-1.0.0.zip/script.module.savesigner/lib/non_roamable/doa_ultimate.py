import doaucrypto
import hashlib
import hmac
import os
import random
import struct
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'crypto'))
from mt19937 import mt_init_by_array, mt_generate, mt_temper

# Title info
TITLE_ID = 0x54430006
TITLE_NAME = 'Dead or Alive 1/2 Ultimate'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'
TITLE_SIG_KEY = '42CBF532BF1FD14739D0F7F66DF8B7B1'
AUTH_KEY = hmac.new(XBOX_CERT_KEY.decode('hex'), TITLE_SIG_KEY.decode('hex'), hashlib.sha1).digest()[:16]

# Constants
UPS_FILE_SIZE = 0x12148
UPS_BODY_ENC_SIZE = 0x12130
SIGNATURE_SIZE = 0x14
SEED_SIZE = 4

SKIP_FILES = (
	'savemeta.xbx',
	'saveimage.xbx',
)

ALLOWED_EXTS = (
	'.dat',
)


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def allowed_file(name):
	low = name.lower()
	if low in SKIP_FILES:
		return False
	for ext in ALLOWED_EXTS:
		if low.endswith(ext):
			return True
	return False


def mac_to_seed_parts(mac_bytes):
	mac_lo32 = struct.unpack_from('<I', mac_bytes, 0)[0]
	mac_hi16 = struct.unpack_from('<H', mac_bytes, 4)[0]
	return (mac_lo32, mac_hi16)


def get_14_vals(seed, mac_bytes):
	mac_lo32, mac_hi16 = mac_to_seed_parts(mac_bytes)
	mt_state = mt_init_by_array([seed, mac_lo32, mac_hi16])
	mt_generated = mt_generate(mt_state[:])
	return [mt_temper(mt_generated[i]) for i in xrange(14)]


def bf_process(data, vals14, encrypt = True):
	return doaucrypto.bf_process(data, vals14, 1 if encrypt else 0)


def make_sig(hdd_key, data):
	inner_hmac = hmac.new(AUTH_KEY, data, hashlib.sha1).digest()
	return hmac.new(hdd_key, inner_hmac, hashlib.sha1).digest()


def decode_ups(path, mac_bytes):
	with open(path, 'rb') as f:
		data = f.read()

	if len(data) != UPS_FILE_SIZE:
		raise ValueError('Wrong file size: 0x%X' % len(data))

	seed = struct.unpack_from('<I', data, SIGNATURE_SIZE)[0]
	mac_lo32, mac_hi16 = mac_to_seed_parts(mac_bytes)

	mt_xor_pt = doaucrypto.mt_xor_bytes(data[0x18:0x12148], seed, mac_lo32, mac_hi16, 14)
	vals14 = get_14_vals(seed, mac_bytes)
	bf_plaintext = bf_process(mt_xor_pt, vals14, encrypt = False)

	return bf_plaintext


def transfer_save(src_data, src_mac, dst_seed, dst_mac, dst_hdd_key):
	src_seed = struct.unpack_from('<I', src_data, SIGNATURE_SIZE)[0]
	src_mac_lo32, src_mac_hi16 = mac_to_seed_parts(src_mac)

	# Decrypt
	mt_xor_pt = doaucrypto.mt_xor_bytes(src_data[0x18:0x12148], src_seed, src_mac_lo32, src_mac_hi16, 14)
	src_14_vals = get_14_vals(src_seed, src_mac)
	bf_plaintext = bf_process(mt_xor_pt, src_14_vals, encrypt = False)

	# Encrypt
	dst_14_vals = get_14_vals(dst_seed, dst_mac)
	bf_ciphertext = bf_process(bf_plaintext, dst_14_vals, encrypt = True)
	dst_mac_lo32, dst_mac_hi16 = mac_to_seed_parts(dst_mac)
	mt_xor_ct = doaucrypto.mt_xor_bytes(bf_ciphertext, dst_seed, dst_mac_lo32, dst_mac_hi16, 14)

	magic = struct.pack('<I', dst_seed) + mt_xor_ct
	sig = make_sig(dst_hdd_key, magic)

	return sig + magic


def sign(xbox_hd_key, file_path, src_mac = None, dst_mac = None, src_hd_key = None):
	if src_mac is None or dst_mac is None:
		return (False, 'src_mac and dst_mac are required for {0}'.format(TITLE_NAME))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	if not allowed_file(os.path.basename(file_path)):
		return (False, 'Skipped: {0}'.format(file_path))

	if os.path.getsize(file_path) != UPS_FILE_SIZE:
		return (False, 'Not a ups.dat file (wrong size)')

	with open(file_path, 'rb') as f:
		src_data = f.read()

	dst_seed = random.getrandbits(32)
	result = transfer_save(src_data, src_mac, dst_seed, dst_mac, xbox_hd_key)

	with open(file_path, 'wb') as f:
		f.write(result)

	return (True, 'Signed -> {0}'.format(file_path))


def transfer(src_path, src_mac, dst_path, dst_mac, dst_hdd_key):
	with open(dst_path, 'rb') as f:
		dst_ref = f.read()

	dst_seed = struct.unpack_from('<I', dst_ref, SIGNATURE_SIZE)[0]

	with open(src_path, 'rb') as f:
		src_data = f.read()

	if len(src_data) != UPS_FILE_SIZE:
		return (False, 'Wrong file size: %s' % hex(len(src_data)))

	result = transfer_save(src_data, src_mac, dst_seed, dst_mac, dst_hdd_key)

	return (True, result)
