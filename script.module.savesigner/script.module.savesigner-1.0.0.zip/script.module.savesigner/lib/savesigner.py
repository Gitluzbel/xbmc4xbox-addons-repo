'''
	Xbox game save resigner

	Loads signer modules from the 'non_roamable' and 'roamable' subfolders and resigns save files using the console's HDD key.

	Resign all saves for a title (e.g. from lansync or a save transfer):
		signers = load_signers()
		ok, msg = resign_title('45410083', 'E:\\UDATA\\45410083', hdd_key_hex, signers)

	Resign all saves for a title that requires MAC addresses (e.g. DOAU):
		ok, msg = resign_title('54430006', 'E:\\UDATA\\54430006', hdd_key_hex, signers, src_mac_hex='AABBCCDDEEFF', dst_mac_hex='112233445566')

	Resign a single file:
		ok, msg = sign_save(0x45410083, hdd_key_hex, 'E:\\UDATA\\45410083\\Save\\save.bin')

	Resign a single file with a separate signature file (e.g. RBR):
		ok, msg = sign_save(0x53430005, hdd_key_hex, 'E:\\path\\profile.sav', sig_path='E:\\path\\signa.tur')

	Resign PSO quest files in TDATA:
		ok, signed, errors = manual_resign_title('E:\\TDATA\\4D53004A\\$C', 'pso_quests', hdd_key (optional))

	Command line PC (python 2.7):
		python savesigner.py 45410083 <hdd_key_hex> <file_path>
		python savesigner.py 53430005 <hdd_key_hex> <file_path> <sig_path>
		python savesigner.py 54430006 <hdd_key_hex> <file_path> "" <src_mac> <dst_mac>
'''
import inspect
import os
import shutil
import sys
import imp
from os import remove, stat, utime
from os.path import isdir, isfile, join

SIGNERS_FOLDERS = [
	os.path.join(os.path.dirname(os.path.abspath(__file__)), 'non_roamable'),
	os.path.join(os.path.dirname(os.path.abspath(__file__)), 'roamable'),
]

# xbmc4xbox-redux writes the "BackupSystemInfo" builtin's EEPROM dump to a
# .cfg file (see xbmc/utils/SystemInfo.h XBOX_EEPROM_CFG_BACKUP_FILE), not .ini.
SYSINFO_PATH = 'Q:\\system\\SystemInfo\\EEPROMBackup.cfg'


def backup_before_sign(file_path):
	'''Keep a copy of the save file's original content before it is signed
	in place. The signer only preserves mtime, not content, so if sign()
	writes a partial/corrupt result there would otherwise be no way back.'''
	backup_path = file_path + '.presign.bak'
	if not isfile(backup_path):
		try:
			shutil.copy2(file_path, backup_path)
		except Exception as error:
			print '[savesigner] backup_before_sign failed for {}: {}'.format(file_path, error)


# Signer loading
def load_signers():
	signers = {}
	for signers_folder in SIGNERS_FOLDERS:
		if not isdir(signers_folder):
			continue
		for filename in os.listdir(signers_folder):
			if not filename.endswith('.py') or filename.startswith('_'):
				continue
			if filename == os.path.basename(__file__):
				continue
			module_name = filename[:-3]
			module_path = join(signers_folder, filename)
			try:
				module = imp.load_source('signer_{0}'.format(module_name), module_path)
				if hasattr(module, 'get_info') and hasattr(module, 'sign'):
					info = module.get_info()
					title_id = info.get('title_id')
					if title_id is not None:
						signers[title_id] = module
						print 'Loaded signer: {0} (TitleID: 0x{1:08X})'.format(info.get('title_name', module_name), title_id)
			except Exception as error:
				print 'Failed to load {0}: {1}'.format(filename, error)
	return signers


# EEPROM helpers
def read_eeprom_ini(ini_path):
	result = {'mac': '', 'hdd_key': ''}
	try:
		for line in open(ini_path).readlines():
			line = line.strip()
			if not line or line.startswith('#') or '=' not in line:
				continue
			key, value = line.split('=', 1)
			key = key.strip()
			value = value.strip().strip('"')
			if key == 'XBOXMAC':
				result['mac'] = value.replace(':', '').replace('-', '').upper()
			elif key == 'HDDKey':
				result['hdd_key'] = value.replace(':', '').replace('-', '').replace(' ', '').upper()
	except Exception:
		pass
	return result


def read_eeprom_bin_mac(eeprom_path):
	try:
		with open(eeprom_path, 'rb') as file_handle:
			data = file_handle.read()
		if len(data) < 0x46:
			return ''
		mac_bytes = data[0x40:0x46]
		return ''.join('{:02X}'.format(ord(mac_byte) if isinstance(mac_byte, str) else mac_byte) for mac_byte in mac_bytes)
	except Exception:
		pass
	return ''


# Resigning saves
# Main resigner, point to folder E:\titleid
def resign_title(title_id_str, title_path, hdd_key_hex, signers, src_mac_hex = None, dst_mac_hex = None, src_hdd_hex = None):
	if not hdd_key_hex or len(hdd_key_hex) != 32:
		return False, 'bad hdd_key_hex for {}'.format(title_id_str)
	try:
		title_id = int(title_id_str, 16)
	except Exception:
		return False, 'cannot parse title_id {}'.format(title_id_str)
	module = signers.get(title_id)
	if module is None:
		return False, 'no signer for {}'.format(title_id_str)
	try:
		hdd_key = hdd_key_hex.decode('hex')
	except Exception as error:
		return False, 'hdd_key decode failed: {}'.format(error)

	src_mac = dst_mac = src_hd_key = None
	if src_mac_hex and len(src_mac_hex.replace(':', '').replace('-', '')) == 12:
		try:
			src_mac = src_mac_hex.replace(':', '').replace('-', '').decode('hex')
		except Exception:
			pass
	if dst_mac_hex and len(dst_mac_hex.replace(':', '').replace('-', '')) == 12:
		try:
			dst_mac = dst_mac_hex.replace(':', '').replace('-', '').decode('hex')
		except Exception:
			pass
	if src_hdd_hex and len(src_hdd_hex.replace(':', '').replace('-', '')) == 32:
		try:
			src_hd_key = src_hdd_hex.replace(':', '').replace('-', '').decode('hex')
		except Exception:
			pass

	sign_args = inspect.getargspec(module.sign).args
	use_mac = 'src_mac' in sign_args and 'dst_mac' in sign_args and src_mac is not None and dst_mac is not None
	title_name = module.get_info().get('title_name', title_id_str)
	signed = skipped = errors = 0

	try:
		for save_folder in os.listdir(title_path):
			save_path = join(title_path, save_folder)
			if not isdir(save_path):
				continue
			for root, dirs, files in os.walk(save_path):
				for filename in files:
					file_path = join(root, filename)
					try:
						original_mtime = stat(file_path).st_mtime
						backup_before_sign(file_path)
						if use_mac:
							ok, msg = module.sign(hdd_key, file_path, src_mac = src_mac, dst_mac = dst_mac, src_hd_key = src_hd_key)
						else:
							ok, msg = module.sign(hdd_key, file_path)
						if ok:
							utime(file_path, (original_mtime, original_mtime))
							signed += 1
							print '[savesigner] {} {} -> OK'.format(title_name, filename)
						elif msg.startswith('Skipped'):
							skipped += 1
						else:
							errors += 1
							print '[savesigner] {} {} -> {}'.format(title_name, filename, msg)
					except Exception as error:
						errors += 1
						print '[savesigner] {} {} error: {}'.format(title_name, filename, error)
	except Exception as error:
		return False, 'walk failed for {}: {}'.format(title_path, error)

	return True, '{} signed {} skipped {} errors'.format(signed, skipped, errors)


# sign_save, used by pointing to a single file
def sign_save(title_id, xbox_hd_key_hex, file_path, sig_path = None, src_mac_hex = None, dst_mac_hex = None):
	if len(xbox_hd_key_hex) != 32:
		return (False, 'XboxHDKey must be 32 hex characters')
	try:
		xbox_hd_key = xbox_hd_key_hex.decode('hex')
	except Exception:
		return (False, 'XboxHDKey is not valid hex')

	src_mac = None
	dst_mac = None

	if src_mac_hex is not None:
		src_mac_hex = src_mac_hex.replace(':', '').replace('-', '')
		if len(src_mac_hex) != 12:
			return (False, 'src_mac must be 12 hex characters (with or without colons)')
		try:
			src_mac = src_mac_hex.decode('hex')
		except Exception:
			return (False, 'src_mac is not valid hex')

	if dst_mac_hex is not None:
		dst_mac_hex = dst_mac_hex.replace(':', '').replace('-', '')
		if len(dst_mac_hex) != 12:
			return (False, 'dst_mac must be 12 hex characters (with or without colons)')
		try:
			dst_mac = dst_mac_hex.decode('hex')
		except Exception:
			return (False, 'dst_mac is not valid hex')

	signers = load_signers()
	module = signers.get(title_id)
	if module is None:
		return (False, 'No signer found for TitleID 0x{0:08X}'.format(title_id))

	args = inspect.getargspec(module.sign).args
	if 'src_mac' in args and 'dst_mac' in args:
		return module.sign(xbox_hd_key, file_path, src_mac = src_mac, dst_mac = dst_mac)
	return module.sign(xbox_hd_key, file_path, sig_path)


# Manual resign
def manual_resign_title(path, lib_name, hdd_key = None):
	if not hdd_key:
		eeprom = read_eeprom_ini(SYSINFO_PATH)
		hdd_key_hex = eeprom.get('hdd_key', '')
		if not hdd_key_hex or len(hdd_key_hex) != 32:
			print '[savesigner] manual_resign_title: could not read HDD key from {}'.format(SYSINFO_PATH)
			return False, 0, 0

		try:
			hdd_key = hdd_key_hex.decode('hex')
		except Exception as error:
			print '[savesigner] manual_resign_title: hdd_key decode failed: {}'.format(error)
			return False, 0, 0

	# Load the matching signer module by lib_name
	module = None
	for signers_folder in SIGNERS_FOLDERS:
		candidate = join(signers_folder, '{}.py'.format(lib_name))
		if isfile(candidate):
			try:
				module = imp.load_source('signer_{}'.format(lib_name), candidate)
			except Exception as error:
				print '[savesigner] manual_resign_title: failed to load {}: {}'.format(candidate, error)
				return False, 0, 0
			break

	if module is None or not hasattr(module, 'sign'):
		print '[savesigner] manual_resign_title: signer module not found for "{}"'.format(lib_name)
		return False, 0, 0

	signed = 0
	errors = 0
	try:
		for offer_folder in os.listdir(path):
			offer_path = join(path, offer_folder)
			if not isdir(offer_path):
				continue
			for filename in os.listdir(offer_path):
				if not filename.lower().endswith('.dat'):
					continue
				file_path = join(offer_path, filename)
				try:
					original_mtime = stat(file_path).st_mtime
					backup_before_sign(file_path)
					ok, msg = module.sign(hdd_key, file_path)
					if ok:
						utime(file_path, (original_mtime, original_mtime))
						signed += 1
						print '[savesigner] {} -> OK'.format(filename)
					elif msg.startswith('Skipped'):
						pass
					else:
						errors += 1
						print '[savesigner] {} -> {}'.format(filename, msg)
				except Exception as error:
					errors += 1
					print '[savesigner] {} error: {}'.format(filename, error)
	except Exception as error:
		print '[savesigner] manual_resign_title: walk failed: {}'.format(error)
		return False, signed, errors

	return True, signed, errors


if __name__ == '__main__':
	title_id = int(sys.argv[1], 16)
	xbox_hd_key_hex = sys.argv[2]
	file_path = sys.argv[3]
	sig_path = sys.argv[4] if len(sys.argv) >= 5 else None
	src_mac_hex = sys.argv[5] if len(sys.argv) >= 6 else None
	dst_mac_hex = sys.argv[6] if len(sys.argv) >= 7 else None
	success, message = sign_save(title_id, xbox_hd_key_hex, file_path, sig_path, src_mac_hex, dst_mac_hex)
	print message
