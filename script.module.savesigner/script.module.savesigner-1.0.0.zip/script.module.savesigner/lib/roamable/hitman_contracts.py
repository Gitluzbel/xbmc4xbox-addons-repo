import hmac
import hashlib
import os
import struct

# Title info
TITLE_ID = 0x45530012
TITLE_NAME = 'Hitman: Contracts'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
TITLE_SIGNATURE_KEY = '2AE2713DD4A34AE3F20C29CD851DD327'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
MIN_FILE_SIZE = 0x18


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size <= MIN_FILE_SIZE:
		return (False, 'File too small: {0}'.format(file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	internal_size = struct.unpack_from('<I', data, file_size - 4)[0]
	if file_size != (internal_size + MIN_FILE_SIZE):
		return (False, 'Skipped (size mismatch): {0}'.format(file_path))

	sig_offset = file_size - MIN_FILE_SIZE

	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	sig = hmac.new(auth_key, data[:internal_size], hashlib.sha1).digest()

	patched = data[:sig_offset] + sig + data[sig_offset + SIGNATURE_SIZE:]
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
