import hmac
import hashlib
import os
import struct

# Title info
TITLE_ID = 0x43430009
TITLE_NAME = 'Steel Battalion: Line of Contact'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
TITLE_SIGNATURE_KEY = 'B91003CEC57E68A99AA961D10DC34C98'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
SIGNATURE_OFFSET = 0x04
DATA_OFFSET = 0x18
MIN_FILE_SIZE = DATA_OFFSET


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size <= MIN_FILE_SIZE:
		return (False, 'File too small: {0}'.format(file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	stored_size = struct.unpack_from('<I', data, 0)[0]
	if stored_size != file_size:
		return (False, 'Skipped (size field mismatch): {0}'.format(file_path))

	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	sig = hmac.new(auth_key, data[DATA_OFFSET:], hashlib.sha1).digest()

	patched = data[:SIGNATURE_OFFSET] + sig + data[DATA_OFFSET:]
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
