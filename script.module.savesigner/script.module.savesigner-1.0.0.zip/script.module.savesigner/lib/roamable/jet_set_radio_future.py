import hmac
import hashlib
import os

# Title info
TITLE_ID = 0x5345000A
TITLE_NAME = 'Jet Set Radio Future'
REGION = 'NTSC-U / NTSC-J / PAL'

# Title IDs
TITLE_ID_NTSC = 0x5345000A
TITLE_ID_PAL = 0x49470018

# Keys
TITLE_SIGNATURE_KEY_NTSC = 'E1D4118A91D20D24C0E3BBB16232964D'
TITLE_SIGNATURE_KEY_PAL = '074BD1972F7BE074539F82143A722E4F'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
FILE_SIZE = 0xA080
DATA_OFFSET = 0x14
DATA_LENGTH = FILE_SIZE - DATA_OFFSET


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	if os.path.basename(file_path).upper() != 'JSRFDATA.SAV':
		return (False, 'Skipped: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size != FILE_SIZE:
		return (False, 'Skipped (wrong size 0x{0:X}): {1}'.format(file_size, file_path))

	# Gwt region from folder title ID
	parts = file_path.replace('\\', '/').split('/')
	title_id_str = ''
	for part in parts:
		if len(part) == 8:
			try:
				int(part, 16)
				title_id_str = part.upper()
			except ValueError:
				pass

	if title_id_str == '{:08X}'.format(TITLE_ID_PAL):
		title_sig_key_hex = TITLE_SIGNATURE_KEY_PAL
	else:
		title_sig_key_hex = TITLE_SIGNATURE_KEY_NTSC

	with open(file_path, 'rb') as fh:
		data = fh.read()

	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = title_sig_key_hex.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	sig = hmac.new(auth_key, data[DATA_OFFSET:], hashlib.sha1).digest()

	patched = sig + data[SIGNATURE_SIZE:]
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
