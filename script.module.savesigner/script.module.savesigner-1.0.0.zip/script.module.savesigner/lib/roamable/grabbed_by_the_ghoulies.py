import hmac
import hashlib
import os

# Title info
TITLE_ID = 0x4D530053
TITLE_NAME = 'Grabbed by the Ghoulies'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
TITLE_SIGNATURE_KEY = '4426DB89185652A1945C8820DC5A0A43'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
FILE_SIZE = 0x400
SIGNATURE_SIZE = 20
KEY_SIZE = 16
SIGNATURE_OFFSET = 0x3EC
DATA_SIZE = 0x3EC


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size != FILE_SIZE:
		return (False, 'Skipped (wrong size 0x{0:X}): {1}'.format(file_size, file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	sig = hmac.new(auth_key, data[:DATA_SIZE], hashlib.sha1).digest()

	patched = data[:SIGNATURE_OFFSET] + sig
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
