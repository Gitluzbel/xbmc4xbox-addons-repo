import os
import imp

# Title info
TITLE_ID = 0x55530041
TITLE_NAME = 'Splinter Cell: Chaos Theory (Multiplayer)'
REGION = 'NTSC-U / NTSC-J / PAL'

_module = imp.load_source(
	'splinter_cell_chaos_theory_primary',
	os.path.join(os.path.dirname(os.path.abspath(__file__)), 'splinter_cell_chaos_theory.py'),
)


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	return _module.sign(xbox_hd_key, file_path, sig_path)
