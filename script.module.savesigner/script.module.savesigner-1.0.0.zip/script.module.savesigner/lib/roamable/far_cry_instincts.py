import hmac
import hashlib
import os

# Title info
TITLE_ID = 0x55530008
TITLE_NAME = 'Far Cry Instincts'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
TITLE_SIGNATURE_KEY = '2FF20BB65D72ED5D46A2A2D625E1A625'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16

SKIP_EXTENSIONS = frozenset(['.sig'])
MAP_MAGICS = (b'CRY', b'DAT')


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	ext = os.path.splitext(file_path)[1].lower()
	if ext in SKIP_EXTENSIONS:
		return (False, 'Skipped: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size <= SIGNATURE_SIZE:
		return (False, 'File too small: {0}'.format(file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	if data[:3] in MAP_MAGICS:
		return (False, 'Skipped (map file, requires .sig resign): {0}'.format(file_path))

	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
	sig = hmac.new(auth_key, data[:-SIGNATURE_SIZE], hashlib.sha1).digest()

	patched = data[:-SIGNATURE_SIZE] + sig
	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
