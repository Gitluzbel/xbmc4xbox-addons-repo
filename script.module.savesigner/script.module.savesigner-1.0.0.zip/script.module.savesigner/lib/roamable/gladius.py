import hmac
import hashlib
import os
import struct

# Title info
TITLE_ID = 0x4C410008
TITLE_NAME = 'Gladius'
REGION = 'NTSC-U / PAL'

# Keys
TITLE_SIGNATURE_KEY = '48A73E2F85CF76F105EE68AC96231B2B'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
MIN_FILE_SIZE = 0x18
BLOCK_HEADER_SIZE = 0x18


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size <= MIN_FILE_SIZE:
		return (False, 'File too small: {0}'.format(file_path))

	with open(file_path, 'rb') as fh:
		buf = bytearray(fh.read())

	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]

	pos = 0
	blocks_signed = 0
	total_size = 0

	while total_size != file_size:
		block_size = struct.unpack_from('<i', buf, pos)[0]
		if block_size <= 0 or block_size > file_size or (total_size + block_size) > file_size:
			return (False, 'Bad block data at offset 0x{0:X}: {1}'.format(pos, file_path))

		block_data = bytes(buf[pos + BLOCK_HEADER_SIZE : pos + block_size])
		sig = hmac.new(auth_key, block_data, hashlib.sha1).digest()
		buf[pos + 4 : pos + 4 + SIGNATURE_SIZE] = sig

		blocks_signed += 1
		total_size += block_size
		pos += block_size

	with open(file_path, 'wb') as fh:
		fh.write(bytes(buf))

	return (True, 'Signed OK ({0} blocks) -> {1}'.format(blocks_signed, file_path))
