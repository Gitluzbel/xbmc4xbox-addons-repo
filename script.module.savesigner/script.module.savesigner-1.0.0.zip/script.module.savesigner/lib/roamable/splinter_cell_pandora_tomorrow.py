import hmac
import hashlib
import os
import struct

# Title info
TITLE_ID = 0x55530019
TITLE_NAME = 'Splinter Cell: Pandora Tomorrow'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
TITLE_SIGNATURE_KEY = '0D5B5C7E20F73FF9C24EC23B9A66B341'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
SG_FILE_SIZE = 0x2625A0
OFFLINE_PRF_MAGIC = 'UBIShanghai'
MIN_FILE_SIZE = 0x18


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)
	if file_size <= MIN_FILE_SIZE:
		return (False, 'File too small: {0}'.format(file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	cert_key = XBOX_CERT_KEY.decode('hex')
	title_sig_key = TITLE_SIGNATURE_KEY.decode('hex')
	auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]

	if file_size == SG_FILE_SIZE:
		sig = hmac.new(auth_key, data[:-SIGNATURE_SIZE], hashlib.sha1).digest()
		patched = data[:-SIGNATURE_SIZE] + sig

	else:
		magic_bytes = OFFLINE_PRF_MAGIC.encode('utf-16-le')
		if data[:len(magic_bytes)] == magic_bytes:
			sig = hmac.new(auth_key, data[:-SIGNATURE_SIZE], hashlib.sha1).digest()
			patched = data[:-SIGNATURE_SIZE] + sig
		else:
			internal_size = struct.unpack_from('<I', data, SIGNATURE_SIZE)[0]
			if (internal_size + SIGNATURE_SIZE + 4) != file_size:
				return (False, 'Skipped (unknown file type): {0}'.format(file_path))
			sig = hmac.new(auth_key, data[SIGNATURE_SIZE:], hashlib.sha1).digest()
			patched = sig + data[SIGNATURE_SIZE:]

	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
