import hmac
import hashlib
import os
import struct

# Title info
TITLE_ID = 0x55530038
TITLE_NAME = 'Splinter Cell: Chaos Theory'
REGION = 'NTSC-U / NTSC-J / PAL'

# Title IDs
TITLE_ID_SP = 0x55530038
TITLE_ID_MP = 0x55530041

# Keys
TITLE_SIGNATURE_KEY_SP = 'EC3283DB375155B3929ED6F1E1C9546F'
TITLE_SIGNATURE_KEY_MP = '6342DD40F83B4728EA822BFD8CB13AC4'
XBOX_CERT_KEY = '5C0733AE0401F7E8BA7993FDCD2F1FE0'

# Constants
SIGNATURE_SIZE = 20
KEY_SIZE = 16
SP_FILE_SIZES = frozenset([0x2625A0, 0x8094, 0x1934])
SKIP_FILE_SIZE = 0x8080
DDS_MAGIC = b'DDS '


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


def sign(xbox_hd_key, file_path, sig_path = None):
	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	file_size = os.path.getsize(file_path)

	if file_size == SKIP_FILE_SIZE:
		return (False, 'Skipped (image not initialized): {0}'.format(file_path))

	with open(file_path, 'rb') as fh:
		data = fh.read()

	# Get region from folder title ID
	parts = file_path.replace('\\', '/').split('/')
	title_id_str = ''
	for part in parts:
		if len(part) == 8:
			try:
				int(part, 16)
				title_id_str = part.upper()
			except ValueError:
				pass

	cert_key = XBOX_CERT_KEY.decode('hex')

	if file_size in SP_FILE_SIZES:
		title_sig_key = TITLE_SIGNATURE_KEY_SP.decode('hex')
		auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
		sig = hmac.new(auth_key, data[:-SIGNATURE_SIZE], hashlib.sha1).digest()
		patched = data[:-SIGNATURE_SIZE] + sig

	else:
		if file_size <= SIGNATURE_SIZE + 4:
			return (False, 'Skipped (unknown file type): {0}'.format(file_path))
		internal_size = struct.unpack_from('<I', data, SIGNATURE_SIZE)[0]
		if (internal_size + SIGNATURE_SIZE + 4) != file_size:
			return (False, 'Skipped (unknown file type): {0}'.format(file_path))
		title_sig_key = TITLE_SIGNATURE_KEY_MP.decode('hex')
		auth_key = hmac.new(cert_key, title_sig_key, hashlib.sha1).digest()[:KEY_SIZE]
		sig = hmac.new(auth_key, data[SIGNATURE_SIZE:], hashlib.sha1).digest()
		patched = sig + data[SIGNATURE_SIZE:]

	with open(file_path, 'wb') as fh:
		fh.write(patched)

	return (True, 'Signed OK -> {0}'.format(file_path))
