import hmac
import hashlib
import os

# Title info
TITLE_ID = 0x00000000
TITLE_NAME = 'Example Multi File Game'
REGION = 'NTSC-U / NTSC-J / PAL'

# Keys
# Title-specific signing key from the XBE certificate (bzSignatureKey)
TITLE_SIGNATURE_KEY = ('00000000000000000000000000000000')

# Shared Xbox platform key, same across all titles
XBOX_CERT_KEY = ('5C0733AE0401F7E8BA7993FDCD2F1FE0')

# Constants
# Files to skip, no signature, not processed
SKIP_FILES = (
	'savemeta.xbx',
	'saveimage.xbx',
)

# Files that must be signed, exact name match (lowercase)
ALLOWED_NAMES = (
	'profile.bin',
	'settings.dat',
)

# Also sign any file starting with these prefixes
ALLOWED_PREFIXES = (
	'slot',
	'save',
)

# Also sign any file with these extensions
ALLOWED_EXTS = (
	'.sav',
	'.dat',
)

SIGNATURE_SIZE = 20
KEY_SIZE = 16


# Info
def get_info():
	return {
		'title_id': TITLE_ID,
		'title_name': TITLE_NAME,
		'region': REGION,
	}


# File helpers
def allowed_file(name):
	low = name.lower()
	if low in SKIP_FILES:
		return False
	if low in ALLOWED_NAMES:
		return True
	for prefix in ALLOWED_PREFIXES:
		if low.startswith(prefix):
			return True
	for ext in ALLOWED_EXTS:
		if low.endswith(ext):
			return True
	return False


# Crypto helpers
def make_auth_key():
	return hmac.new(XBOX_CERT_KEY.decode('hex'), TITLE_SIGNATURE_KEY.decode('hex'), hashlib.sha1).digest()[:KEY_SIZE]


def sign_block(auth_key, xbox_hd_key, data_block):
	roamable = hmac.new(auth_key, data_block, hashlib.sha1).digest()
	return hmac.new(xbox_hd_key, roamable, hashlib.sha1).digest()


def sign(xbox_hd_key, file_path, sig_path = None):
	if len(xbox_hd_key) != KEY_SIZE:
		return (False, 'XboxHDKey must be 16 bytes, got {0}'.format(len(xbox_hd_key)))

	if not os.path.isfile(file_path):
		return (False, 'File not found: {0}'.format(file_path))

	name = os.path.basename(file_path)

	if not allowed_file(name):
		return (False, 'Skipped: {0}'.format(file_path))

	data = bytearray(open(file_path, 'rb').read())
	if len(data) < SIGNATURE_SIZE:
		return (False, 'File too small: {0}'.format(file_path))

	auth_key = make_auth_key()
	sig_offset = len(data) - SIGNATURE_SIZE
	sig = sign_block(auth_key, xbox_hd_key, bytes(data[:sig_offset]))
	data[sig_offset:] = sig

	open(file_path, 'wb').write(bytes(data))
	return (True, 'Signed -> {0}'.format(file_path))
