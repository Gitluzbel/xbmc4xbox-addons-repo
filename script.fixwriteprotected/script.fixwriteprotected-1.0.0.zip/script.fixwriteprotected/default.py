# -*- coding: utf-8 -*-
import os
import stat
import xbmcgui

FULL_PERMS = stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO


def count_items(root_path):
	total = 0
	for dirpath, dirnames, filenames in os.walk(root_path):
		total += 1
		total += len(filenames)
	return total


def chmod_files_in_tree(root_path, progress):
	root_path = os.path.abspath(root_path)
	total = count_items(root_path)
	done = 0

	for dirpath, dirnames, filenames in os.walk(root_path):
		if progress.iscanceled():
			return

		try:
			os.chmod(dirpath, FULL_PERMS)
		except OSError:
			pass

		done += 1
		percent = int((done / float(total)) * 100) if total else 100
		progress.update(percent, dirpath)

		for filename in filenames:
			if progress.iscanceled():
				return

			full_path = os.path.join(dirpath, filename)
			try:
				os.chmod(full_path, FULL_PERMS)
			except OSError:
				pass

			done += 1
			percent = int((done / float(total)) * 100) if total else 100
			progress.update(percent, full_path)


def main():
	dialog = xbmcgui.Dialog()
	folder = dialog.browse(3, "Select Root Folder", "files")

	if not folder:
		return

	progress = xbmcgui.DialogProgress()
	progress.create("Chmod Files", "Starting...")

	chmod_files_in_tree(folder, progress)

	progress.close()

	dialog.ok("Chmod Files", "Done.")


if __name__ == "__main__":
	main()
