# -*- coding: utf-8 -*-
"""
    Script by Xbox4Gamers
    Traduce la etiqueta de la descripcion en archivos default.xml
    dentro de carpetas _resources de forma recursiva.
    Crea backup default.bak antes de modificar.
    Compatible con XBMC4Gamers / Xbox Clasica (Python 2.7)
"""

import os
import re
import shutil
import traceback
import urllib
import urllib2
import json
import time
import threading

import xbmc
import xbmcgui

xbmc.executebuiltin('Dialog.Close(1100,true)')


# ══════════════════════════════════════════════════
# CONSTANTES
# ══════════════════════════════════════════════════
MARCA_TRADUCIDO_BASE = 'translated='
PAUSA_BASE           = 0.8
MAX_REINTENTOS       = 3
TAG_RAIZ             = "game"

# Idiomas disponibles con sus códigos ISO
IDIOMAS = {
    0: {'nombre': 'Espanol',   'codigo': 'es', 'latinos': u'áéíóúüñÁÉÍÓÚÜÑ¿¡'},
    1: {'nombre': 'Catalan',   'codigo': 'ca', 'latinos': u'àèéíïòóúüçÀÈÉÍÏÒÓÚÜÇ·'},
    2: {'nombre': 'Gallego',   'codigo': 'gl', 'latinos': u'áéíóúüñÁÉÍÓÚÜÑ'},
    3: {'nombre': 'Portugues', 'codigo': 'pt', 'latinos': u'áàâãéêíóôõúüçÁÀÂÃÉÊÍÓÔÕÚÜÇ'},
    4: {'nombre': 'Frances',   'codigo': 'fr', 'latinos': u'àâæçéèêëïîôùûüÿœÀÂÆÇÉÈÊËÏÎÔÙÛÜŸŒ'},
    5: {'nombre': 'Aleman',    'codigo': 'de', 'latinos': u'äöüßÄÖÜ'},
    6: {'nombre': 'Italiano',  'codigo': 'it', 'latinos': u'àèéìíîòóùúÀÈÉÌÍÎÒÓÙÚ'},
    7: {'nombre': 'Rumano',    'codigo': 'ro', 'latinos': u'ăâîșțĂÂÎȘȚ'}
}


# ══════════════════════════════════════════════════
# ESTADO COMPARTIDO ENTRE HILOS
# ══════════════════════════════════════════════════

class EstadoTraduccion:
    def __init__(self):
        self._lock          = threading.Lock()
        self._cancelado     = False
        self._total         = 0
        self._procesados    = 0
        self._nombre_actual = ""
        self._estado_actual = ""
        self._terminado     = False
        self._error         = None

    def cancelar(self):
        self._lock.acquire()
        try:
            self._cancelado = True
        finally:
            self._lock.release()

    def get_cancelado(self):
        self._lock.acquire()
        try:
            return self._cancelado
        finally:
            self._lock.release()

    def get_total(self):
        self._lock.acquire()
        try:
            return self._total
        finally:
            self._lock.release()

    def set_total(self, valor):
        self._lock.acquire()
        try:
            self._total = valor
        finally:
            self._lock.release()

    def get_procesados(self):
        self._lock.acquire()
        try:
            return self._procesados
        finally:
            self._lock.release()

    def incrementar(self):
        self._lock.acquire()
        try:
            self._procesados += 1
        finally:
            self._lock.release()

    def actualizar_ui(self, nombre, estado):
        self._lock.acquire()
        try:
            self._nombre_actual = nombre
            self._estado_actual = estado
        finally:
            self._lock.release()

    def leer_ui(self):
        self._lock.acquire()
        try:
            return self._nombre_actual, self._estado_actual
        finally:
            self._lock.release()

    def marcar_terminado(self, error=None):
        self._lock.acquire()
        try:
            self._terminado = True
            self._error     = error
        finally:
            self._lock.release()

    def get_terminado(self):
        self._lock.acquire()
        try:
            return self._terminado
        finally:
            self._lock.release()

    def get_error(self):
        self._lock.acquire()
        try:
            return self._error
        finally:
            self._lock.release()

    def get_porcentaje(self):
        self._lock.acquire()
        try:
            if self._total > 0:
                return int((self._procesados * 100) / self._total)
            return 0
        finally:
            self._lock.release()


# ══════════════════════════════════════════════════
# UTILIDADES
# ══════════════════════════════════════════════════

def limpiar_hashes(texto):
    if not texto:
        return texto

    limpio = texto
    limpio = limpio.replace("e050167b38f2a566522b4157651fc616", "")

    for _ in range(5):
        limpio = re.sub(r'\b[a-fA-F0-9]{32}\b', '', limpio)

    limpio = re.sub(r'\s+', ' ', limpio)
    limpio = re.sub(r' ([.,;:!?])', r'\1', limpio)

    return limpio.strip()


def marcar_como_traducido(xml_str, codigo_idioma):
    """Marca el XML como traducido añadiendo el atributo con el código de idioma"""
    marca = MARCA_TRADUCIDO_BASE + '"' + codigo_idioma + '"'
    patron = r'(<' + TAG_RAIZ + r')([\s>])'

    def reemplazar(m):
        apertura  = m.group(1)
        siguiente = m.group(2)
        if siguiente == '>':
            return apertura + ' ' + marca + '>'
        return apertura + ' ' + marca + siguiente

    nuevo, n = re.subn(patron, reemplazar, xml_str, count=1)
    if n == 0:
        xbmc.log(
            "[Traductor] AVISO: No se encontro tag raiz <" + TAG_RAIZ + ">",
            xbmc.LOGWARNING
        )
    return nuevo


def tiene_caracteres_latinos(texto, caracteres_latinos):
    """Detecta si el texto ya contiene caracteres específicos del idioma destino"""
    for char in caracteres_latinos:
        if char in texto:
            return True
    return False


# ══════════════════════════════════════════════════
# TRADUCCION
# ══════════════════════════════════════════════════

def traducir_texto(texto, estado, codigo_idioma, desde="en"):
    """Traduce texto usando Google Translate API con reintentos"""
    if not texto or not texto.strip():
        return None

    for intento in range(MAX_REINTENTOS):

        if estado.get_cancelado():
            xbmc.log("[Traductor] Traduccion cancelada por usuario.", xbmc.LOGINFO)
            return None

        try:
            texto_enc = urllib.quote(texto.encode('utf-8'))

            url = (
                "https://translate.googleapis.com/translate_a/single"
                "?client=gtx"
                "&sl=" + desde +
                "&tl=" + codigo_idioma +
                "&dt=t"
                "&q=" + texto_enc
            )

            req = urllib2.Request(url)
            req.add_header(
                'User-Agent',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/91.0.4472.124 Safari/537.36'
            )

            resp = urllib2.urlopen(req, timeout=10)
            raw  = resp.read()

            datos = json.loads(raw.decode('utf-8'))

            traduccion = u""
            if datos and isinstance(datos[0], list):
                for fragmento in datos[0]:
                    if fragmento and len(fragmento) > 0 and fragmento[0]:
                        traduccion += fragmento[0]

            if traduccion.strip():
                return traduccion.strip()

        except urllib2.HTTPError, e:
            if e.code == 429:
                espera = PAUSA_BASE * (2 ** intento) * 5
                xbmc.log(
                    "[Traductor] Rate limit (429). Esperando "
                    + str(espera) + "s...",
                    xbmc.LOGWARNING
                )
                _esperar_cancelable(espera, estado)
            else:
                xbmc.log(
                    "[Traductor] HTTPError " + str(e.code)
                    + " intento " + str(intento + 1),
                    xbmc.LOGERROR
                )
                _esperar_cancelable(PAUSA_BASE * (intento + 1), estado)

        except urllib2.URLError, e:
            xbmc.log(
                "[Traductor] URLError: " + str(e.reason)
                + " intento " + str(intento + 1),
                xbmc.LOGERROR
            )
            _esperar_cancelable(PAUSA_BASE * (intento + 1), estado)

        except Exception, e:
            xbmc.log(
                "[Traductor] Error: " + str(e)
                + " intento " + str(intento + 1),
                xbmc.LOGERROR
            )
            _esperar_cancelable(PAUSA_BASE * (intento + 1), estado)

    return None


def _esperar_cancelable(segundos, estado):
    """Espera tiempo determinado pero permite cancelación cada 0.2s"""
    fin = time.time() + segundos
    while time.time() < fin:
        if estado.get_cancelado():
            return
        time.sleep(0.2)


def traducir_tag(xml_str, tag, estado, codigo_idioma, caracteres_latinos):
    """Traduce todas las ocurrencias de un tag específico en el XML"""
    inicio_tag = "<" + tag + ">"
    fin_tag    = "</" + tag + ">"
    idx        = 0

    while True:

        if estado.get_cancelado():
            xbmc.log(
                "[Traductor] traducir_tag cancelado en <" + tag + ">",
                xbmc.LOGINFO
            )
            break

        pos_ini = xml_str.find(inicio_tag, idx)
        if pos_ini == -1:
            break

        pos_fin = xml_str.find(fin_tag, pos_ini + len(inicio_tag))
        if pos_fin == -1:
            xbmc.log(
                "[Traductor] Tag <" + tag + "> sin cierre.",
                xbmc.LOGWARNING
            )
            break

        contenido = xml_str[pos_ini + len(inicio_tag):pos_fin]
        limpio    = limpiar_hashes(contenido.strip())

        if not limpio or len(limpio) < 10:
            idx = pos_fin + len(fin_tag)
            continue

        # Si ya tiene caracteres del idioma destino, solo limpiar
        if tiene_caracteres_latinos(limpio, caracteres_latinos):
            if limpio != contenido.strip():
                xml_str = (
                    xml_str[:pos_ini]
                    + inicio_tag + limpio + fin_tag
                    + xml_str[pos_fin + len(fin_tag):]
                )
            idx = pos_ini + len(inicio_tag) + len(limpio) + len(fin_tag)
            continue

        xbmc.log(
            "[Traductor] Traduciendo <" + tag + "> a " + codigo_idioma + ": "
            + limpio[:60].encode('utf-8', 'replace') + "...",
            xbmc.LOGINFO
        )

        traducido = traducir_texto(limpio, estado, codigo_idioma, "en")

        if estado.get_cancelado():
            break

        nuevo_contenido = traducido if traducido else limpio

        if not traducido:
            xbmc.log(
                "[Traductor] Fallo traduccion. Guardando texto limpio.",
                xbmc.LOGWARNING
            )

        xml_str = (
            xml_str[:pos_ini]
            + inicio_tag + nuevo_contenido + fin_tag
            + xml_str[pos_fin + len(fin_tag):]
        )
        idx = pos_ini + len(inicio_tag) + len(nuevo_contenido) + len(fin_tag)

        _esperar_cancelable(PAUSA_BASE, estado)

    return xml_str


# ══════════════════════════════════════════════════
# PROCESADO DE ARCHIVOS
# ══════════════════════════════════════════════════

def recolectar_xmls(carpeta_raiz):
    """Busca todos los archivos default.xml en carpetas _resources"""
    xmls = []
    for raiz, dirs, archivos in os.walk(carpeta_raiz):
        raiz_norm = raiz.replace("\\", "/")
        if "_resources" not in raiz_norm:
            continue
        for archivo in archivos:
            if archivo.lower() == "default.xml":
                xmls.append(os.path.join(raiz, archivo))
    xbmc.log(
        "[Traductor] default.xml encontrados: " + str(len(xmls)),
        xbmc.LOGINFO
    )
    return xmls


def procesar_xml(ruta_xml, estado, solo_nuevos, codigo_idioma, caracteres_latinos):
    """Procesa un archivo XML individual según el modo seleccionado"""
    carpeta  = os.path.dirname(ruta_xml)
    ruta_bak = os.path.join(carpeta, "default.bak")
    nombre   = os.path.basename(carpeta)

    try:
        xbmc.log("[Traductor] ── Procesando: " + ruta_xml, xbmc.LOGINFO)
        estado.actualizar_ui(nombre, "leyendo...")

        if solo_nuevos:
            if os.path.isfile(ruta_bak):
                xbmc.log(
                    "[Traductor] Saltado (ya tiene .bak): " + nombre,
                    xbmc.LOGINFO
                )
                estado.actualizar_ui(nombre, "saltado (ya existe .bak)")
                estado.incrementar()
                return
            else:
                if not os.path.isfile(ruta_xml):
                    xbmc.log(
                        "[Traductor] No existe: " + ruta_xml,
                        xbmc.LOGWARNING
                    )
                    return
                shutil.copy2(ruta_xml, ruta_bak)
                xbmc.log(
                    "[Traductor] Backup creado (nuevo): " + ruta_bak,
                    xbmc.LOGINFO
                )

        else:
            if not os.path.isfile(ruta_xml):
                xbmc.log(
                    "[Traductor] No existe: " + ruta_xml,
                    xbmc.LOGWARNING
                )
                return

            if os.path.isfile(ruta_bak):
                xbmc.log(
                    "[Traductor] Bak existente, no se reescribe: " + ruta_bak,
                    xbmc.LOGINFO
                )
            else:
                shutil.copy2(ruta_xml, ruta_bak)
                xbmc.log(
                    "[Traductor] Backup creado (todos): " + ruta_bak,
                    xbmc.LOGINFO
                )

        f = open(ruta_bak, 'r')
        contenido = f.read()
        f.close()

        if isinstance(contenido, str):
            try:
                contenido = contenido.decode('utf-8')
            except UnicodeDecodeError:
                contenido = contenido.decode('latin-1')

        if estado.get_cancelado():
            return

        estado.actualizar_ui(nombre, "traduciendo overview...")
        contenido = traducir_tag(contenido, "overview", estado, codigo_idioma, caracteres_latinos)

        if estado.get_cancelado():
            return

        estado.actualizar_ui(nombre, "traduciendo description...")
        contenido = traducir_tag(contenido, "description", estado, codigo_idioma, caracteres_latinos)

        if estado.get_cancelado():
            return

        estado.actualizar_ui(nombre, "guardando...")
        contenido = marcar_como_traducido(contenido, codigo_idioma)

        if isinstance(contenido, unicode):
            contenido = contenido.encode('utf-8')

        f = open(ruta_xml, 'w')
        f.write(contenido)
        f.close()

        estado.incrementar()
        estado.actualizar_ui(nombre, "OK")

        xbmc.log(
            "[Traductor] OK ["
            + str(estado.get_procesados()) + "/" + str(estado.get_total())
            + "]: " + nombre,
            xbmc.LOGINFO
        )

    except Exception, e:
        xbmc.log(
            "[Traductor] Error en " + ruta_xml + ": " + str(e),
            xbmc.LOGERROR
        )
        traceback.print_exc()


def _hilo_traduccion(carpeta_raiz, estado, solo_nuevos, codigo_idioma, caracteres_latinos):
    """Hilo de trabajo que procesa todos los archivos XML"""
    try:
        xmls = recolectar_xmls(carpeta_raiz)
        estado.set_total(len(xmls))

        if estado.get_total() == 0:
            xbmc.log("[Traductor] Sin archivos que procesar.", xbmc.LOGWARNING)
            estado.marcar_terminado()
            return

        for ruta_xml in xmls:
            if estado.get_cancelado():
                xbmc.log("[Traductor] Hilo cancelado.", xbmc.LOGINFO)
                break
            procesar_xml(ruta_xml, estado, solo_nuevos, codigo_idioma, caracteres_latinos)

        estado.marcar_terminado()

    except Exception, e:
        xbmc.log("[Traductor] Error critico en hilo: " + str(e), xbmc.LOGERROR)
        traceback.print_exc()
        estado.marcar_terminado(error=str(e))


# ══════════════════════════════════════════════════
# BUCLE DE UI
# ══════════════════════════════════════════════════

def ejecutar_con_progreso(carpeta_raiz, progress_dialog, solo_nuevos, idioma_info):
    """Ejecuta el proceso de traducción mostrando progreso en la UI"""
    estado = EstadoTraduccion()
    
    codigo_idioma = idioma_info['codigo']
    caracteres_latinos = idioma_info['latinos']

    hilo = threading.Thread(
        target=_hilo_traduccion,
        args=(carpeta_raiz, estado, solo_nuevos, codigo_idioma, caracteres_latinos)
    )
    hilo.daemon = True
    hilo.start()

    xbmc.log("[Traductor] Hilo de trabajo iniciado.", xbmc.LOGINFO)

    while not estado.get_terminado():

        if progress_dialog.iscanceled():
            xbmc.log("[Traductor] Boton cancelar detectado.", xbmc.LOGINFO)
            estado.cancelar()
            progress_dialog.update(
                estado.get_porcentaje(),
                "Cancelando...",
                "Esperando que termine la operacion actual",
                ""
            )
            hilo.join(15)
            break

        nombre, estado_actual = estado.leer_ui()

        progress_dialog.update(
            estado.get_porcentaje(),
            "Traduciendo a " + idioma_info['nombre'] + " ---P.U.G.A---",
            nombre + "  [" + estado_actual + "]",
            str(estado.get_procesados()) + " / " + str(estado.get_total())
        )

        xbmc.sleep(300)

    if hilo.isAlive():
        hilo.join(30)

    return estado


def restaurar_backups(carpeta_raiz, progress_dialog, borrar_bak=False):
    """Restaura archivos desde default.bak a default.xml"""
    resultado = {"count": 0, "cancelado": False, "error": None}
    terminado_event = threading.Event()

    def _hilo_restaurar():
        try:
            baks = []
            for raiz, dirs, archivos in os.walk(carpeta_raiz):
                raiz_norm = raiz.replace("\\", "/")
                if "_resources" not in raiz_norm:
                    continue
                for archivo in archivos:
                    if archivo.lower() == "default.bak":
                        baks.append(os.path.join(raiz, archivo))

            if len(baks) == 0:
                xbmc.log("[Traductor] Sin backups.", xbmc.LOGWARNING)
                terminado_event.set()
                return

            for ruta_bak in baks:
                if resultado["cancelado"]:
                    break

                ruta_xml = os.path.join(
                    os.path.dirname(ruta_bak), "default.xml"
                )
                try:
                    shutil.copy2(ruta_bak, ruta_xml)
                    resultado["count"] += 1

                    if borrar_bak:
                        os.remove(ruta_bak)
                        xbmc.log(
                            "[Traductor] Restaurado y bak eliminado: " + ruta_xml,
                            xbmc.LOGINFO
                        )
                    else:
                        xbmc.log(
                            "[Traductor] Restaurado (bak conservado): " + ruta_xml,
                            xbmc.LOGINFO
                        )

                except Exception, e:
                    xbmc.log(
                        "[Traductor] Error restaurando " + ruta_bak
                        + ": " + str(e),
                        xbmc.LOGERROR
                    )

        except Exception, e:
            resultado["error"] = str(e)
            xbmc.log(
                "[Traductor] Error en hilo restaurar: " + str(e),
                xbmc.LOGERROR
            )
        finally:
            terminado_event.set()

    hilo = threading.Thread(target=_hilo_restaurar)
    hilo.daemon = True
    hilo.start()

    while not terminado_event.isSet():
        if progress_dialog.iscanceled():
            resultado["cancelado"] = True
            progress_dialog.update(0, "Cancelando...", "", "")
            hilo.join(10)
            break

        progress_dialog.update(
            0,
            "Restaurando backups...",
            str(resultado["count"]) + " restaurados",
            ""
        )
        xbmc.sleep(300)

    if hilo.isAlive():
        hilo.join(15)

    return resultado


# ══════════════════════════════════════════════════
# PUNTO DE ENTRADA
# ══════════════════════════════════════════════════

if __name__ == "__main__":
    xbmc.log(
        "| Scripts\\Xbox4Gamers\\Traductor Overview\\default.py v4.0 loaded.",
        xbmc.LOGINFO
    )

    dialog          = xbmcgui.Dialog()
    progress_dialog = xbmcgui.DialogProgress()

    opcion = dialog.select(
        "Xbox4Gamers - XBOX PUGA Traductor",
        [
            "Traducir Descripciones",
            "Restaurar backups originales",
        ]
    )

    if opcion == -1:
        xbmc.log("[Traductor] Cancelado.", xbmc.LOGINFO)

    elif opcion == 0:
        # ── SELECCIONAR IDIOMA ────────────────────────────────
        lista_idiomas = []
        for i in range(len(IDIOMAS)):
            lista_idiomas.append(IDIOMAS[i]['nombre'])
        
        idx_idioma = dialog.select(
            "Seleccionar idioma de destino",
            lista_idiomas
        )

        if idx_idioma == -1:
            xbmc.log("[Traductor] Seleccion de idioma cancelada.", xbmc.LOGINFO)

        else:
            idioma_info = IDIOMAS[idx_idioma]
            xbmc.log(
                "[Traductor] Idioma seleccionado: " 
                + idioma_info['nombre'] + " (" + idioma_info['codigo'] + ")",
                xbmc.LOGINFO
            )

            # ── SELECCIONAR MODO ──────────────────────────────
            modo = dialog.select(
                "Modo de traduccion",
                [
                    "Traducir TODOS (incluye ya procesados)",
                    "Traducir solo los NUEVOS (sin default.bak)",
                ]
            )

            if modo == -1:
                xbmc.log("[Traductor] Seleccion de modo cancelada.", xbmc.LOGINFO)

            else:
                solo_nuevos = (modo == 1)

                xbmc.log(
                    "[Traductor] Modo seleccionado: "
                    + ("SOLO NUEVOS" if solo_nuevos else "TODOS"),
                    xbmc.LOGINFO
                )

                # ── SELECCIONAR CARPETA ───────────────────────
                search_directory = dialog.browse(
                    0,
                    "Selecciona la carpeta raiz de tus juegos",
                    "files"
                )

                if search_directory:
                    xbmc.log(
                        "[Traductor] Carpeta: " + search_directory,
                        xbmc.LOGINFO
                    )

                    progress_dialog.create("Xbox4Gamers - XBOX PUGA Traductor")
                    progress_dialog.update(0, "Iniciando...", "", "")

                    try:
                        estado = ejecutar_con_progreso(
                            search_directory,
                            progress_dialog,
                            solo_nuevos,
                            idioma_info
                        )
                        progress_dialog.close()

                        if estado.get_cancelado():
                            dialog.ok(
                                "Traductor Overview",
                                "",
                                "Proceso cancelado.",
                                "Procesados: " + str(estado.get_procesados())
                                + " / " + str(estado.get_total())
                            )
                        elif estado.get_error():
                            dialog.ok(
                                "ERROR - Traductor Overview",
                                "",
                                "El script ha fallado.",
                                estado.get_error()
                            )
                        else:
                            dialog.ok(
                                "Traductor Overview",
                                "",
                                "Proceso completado a " + idioma_info['nombre'] + ".",
                                str(estado.get_procesados()) + " archivos traducidos."
                            )

                    except Exception, e:
                        xbmc.log(
                            "[Traductor] Error critico: " + str(e),
                            xbmc.LOGERROR
                        )
                        traceback.print_exc()
                        progress_dialog.close()
                        dialog.ok("ERROR", "", "El script ha fallado.", str(e))

                else:
                    xbmc.log("[Traductor] Sin carpeta seleccionada.", xbmc.LOGINFO)

    elif opcion == 1:
        # ── RESTAURAR ─────────────────────────────────────────
        search_directory = dialog.browse(
            0,
            "Selecciona la carpeta raiz de tus juegos",
            "files"
        )

        if search_directory:

            borrar_bak = dialog.yesno(
                "Restaurar Backups",
                "Deseas eliminar los archivos .bak",
                "despues de restaurar?",
                "",
                "Conservar .bak",
                "Eliminar .bak"
            )

            if borrar_bak:
                msg_bak = "Los archivos .bak SERAN ELIMINADOS tras restaurar."
            else:
                msg_bak = "Los archivos .bak seran conservados."

            confirmar = dialog.yesno(
                "Restaurar Backups",
                "Se restauraran todos los default.bak a default.xml.",
                msg_bak,
                "Continuar?"
            )

            if confirmar:
                progress_dialog.create("Xbox4Gamers - Restaurar Backups")

                try:
                    res = restaurar_backups(
                        search_directory,
                        progress_dialog,
                        borrar_bak=borrar_bak
                    )
                    progress_dialog.close()

                    if res["cancelado"]:
                        dialog.ok(
                            "Restaurar Backups",
                            "",
                            "Restauracion cancelada.",
                            str(res["count"]) + " archivos restaurados."
                        )
                    elif res["error"]:
                        dialog.ok(
                            "ERROR",
                            "",
                            "Fallo la restauracion.",
                            res["error"]
                        )
                    else:
                        if borrar_bak:
                            msg_fin = (
                                str(res["count"])
                                + " archivos restaurados. Backups eliminados."
                            )
                        else:
                            msg_fin = (
                                str(res["count"])
                                + " archivos restaurados. Backups conservados."
                            )

                        dialog.ok(
                            "Restaurar Backups",
                            "",
                            "Restauracion completada.",
                            msg_fin
                        )

                except Exception, e:
                    xbmc.log(
                        "[Traductor] Error: " + str(e),
                        xbmc.LOGERROR
                    )
                    traceback.print_exc()
                    progress_dialog.close()
                    dialog.ok("ERROR", "", "Fallo la restauracion.", str(e))

            else:
                xbmc.log("[Traductor] Restauracion cancelada por usuario.", xbmc.LOGINFO)

        else:
            xbmc.log("[Traductor] Sin carpeta seleccionada.", xbmc.LOGINFO)