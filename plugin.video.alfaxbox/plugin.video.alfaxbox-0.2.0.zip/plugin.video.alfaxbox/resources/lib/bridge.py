# -*- coding: utf-8 -*-
"""
Cliente de alfa-bridge (mini-pc/alfa-bridge/), el servicio del mini PC/VM
que ejecuta el addon Alfa de Kodi (esta Xbox no puede: Python 2.7 sin las
librerias que Alfa necesita) y recodifica el video a MPEG4/Xvid (el H.264
de las webs no se puede descodificar con fluidez aqui, mismo motivo que
en tdt-relay/invidious-download).

Endpoints usados: /alfa/list (navegar canales, buscar), /alfa/resolve
(resuelve un enlace de video y devuelve un token) y /alfa/stream?t=<token>
(el video ya recodificado).
"""
import json
import urllib
import urllib2

import xbmc

from .gui import addon

_MINIPC_NETBIOS_NAME = "XBOXMINIPC"
# Mismo valor de respaldo que usan plugin.video.invidious/tdtxbox si la
# resolucion NBNS falla (mini PC/VM apagado, timing raro al arrancar).
_FALLBACK_IP = "192.168.1.134"
BRIDGE_PORT = 3004

# Alfa puede tardar mucho en un canal lento o con Cloudflare (el bridge
# corta a los 150s); un poco mas de margen para no cortar antes que el.
REQUEST_TIMEOUT = 170


def _log(msg, level=xbmc.LOGNOTICE):
    xbmc.log("plugin.video.alfaxbox: " + msg, level)


def _to_str(obj):
    """json de Python 2 devuelve unicode; ListItem/urlencode de esta
    Xbox esperan str UTF-8 (mismo problema ya resuelto en tdtxbox)."""
    if isinstance(obj, unicode):
        return obj.encode("utf-8")
    if isinstance(obj, list):
        return [_to_str(x) for x in obj]
    if isinstance(obj, dict):
        return dict((_to_str(k), _to_str(v)) for k, v in obj.items())
    return obj


def host():
    override = (addon.getSetting("host") or "").strip()
    if override:
        return override
    try:
        from nbnsresolve import resolve_netbios_name
        ip = resolve_netbios_name(_MINIPC_NETBIOS_NAME)
    except Exception as e:
        _log("fallo resolviendo {} por NBNS: {}".format(_MINIPC_NETBIOS_NAME, e), xbmc.LOGDEBUG)
        ip = None
    if ip:
        _log("{} resuelto por NBNS a {}".format(_MINIPC_NETBIOS_NAME, ip), xbmc.LOGDEBUG)
    else:
        _log("NBNS no respondio, usando IP de respaldo {}".format(_FALLBACK_IP), xbmc.LOGDEBUG)
    return ip or _FALLBACK_IP


def _base():
    return "http://{}:{}".format(host(), BRIDGE_PORT)


def _get(path, params):
    """Devuelve (codigo_http, dict). Las respuestas de error del bridge
    (404 sin enlace, 410 token caducado, 504 Alfa lento...) tambien
    traen JSON con el motivo, asi que se leen igual que las buenas."""
    url = "{}{}?{}".format(_base(), path, urllib.urlencode(params))
    _log("GET {}".format(url[:200]), xbmc.LOGDEBUG)
    try:
        resp = urllib2.urlopen(url, timeout=REQUEST_TIMEOUT)
        code, body = resp.getcode(), resp.read()
    except urllib2.HTTPError as e:
        code, body = e.code, e.read()
    except Exception as e:
        _log("error de red hablando con alfa-bridge: {}".format(e), xbmc.LOGWARNING)
        return 0, {"error": "No se pudo contactar con el mini PC ({}). "
                            "Comprueba que esta encendido y que el servicio alfa-bridge esta activo.".format(e)}
    try:
        return code, _to_str(json.loads(body))
    except ValueError:
        return code, {"error": "Respuesta no valida de alfa-bridge (HTTP {})".format(code)}


def list_items(q="", text=None):
    params = {}
    if q:
        params["q"] = q
    if text:
        params["text"] = text.encode("utf-8") if isinstance(text, unicode) else text
    return _get("/alfa/list", params)[1]


def resolve(q):
    return _get("/alfa/resolve", {"q": q})[1]


def torrent_status(token):
    code, data = _get("/alfa/torrent/status", {"t": token})
    if code != 200:
        return {"state": "error", "error": data.get("error") or "el torrent ya no existe en el mini PC"}
    return data


def torrent_cancel(token):
    _get("/alfa/torrent/cancel", {"t": token})


def stream_url(token, start=0):
    params = {"t": token}
    if start:
        params["ss"] = "{:.1f}".format(start)
    return "{}/alfa/stream?{}".format(_base(), urllib.urlencode(params))


def describe_problem(data):
    """Texto para mostrar al usuario cuando Alfa no devolvio nada util:
    primero lo que Alfa mismo dijo (notificaciones/dialogos que en Kodi
    saldrian en pantalla), y si no, el error tecnico."""
    parts = []
    for n in data.get("notifications") or []:
        if len(n) > 1 and n[1]:
            parts.append(n[1])
    for d in data.get("dialogs") or []:
        parts.extend(x for x in d[1:] if x and len(x) > 3)
    if data.get("error"):
        parts.append(data["error"])
    seen, out = set(), []
    for p in parts:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out[:3]
