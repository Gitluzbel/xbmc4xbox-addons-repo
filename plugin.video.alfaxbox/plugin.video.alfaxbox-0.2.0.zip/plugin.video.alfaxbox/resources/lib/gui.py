import os
import sys
import urllib
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

addon = xbmcaddon.Addon()


# Con <reuselanguageinvoker> el modulo puede quedarse importado entre
# invocaciones del addon, asi que el handle y la ruta base se leen de
# sys.argv en cada llamada, no una sola vez al importar.
def _handle():
    return int(sys.argv[1])


def add_item(title, icon=None, thumb=None, url_params=None, video_infotag=None, is_folder=True):
    item = xbmcgui.ListItem(title)

    art = {}
    if icon:
        art["icon"] = os.path.join(addon.getAddonInfo("path"), "resources", "media", icon)
    if thumb:
        art["thumb"] = thumb
    item.setArt(art)

    url = "{}?{}".format(sys.argv[0], urllib.urlencode(url_params))

    if video_infotag is not None:
        item.setInfo("video", video_infotag)
    if not is_folder:
        item.setProperty("IsPlayable", "True")

    return xbmcplugin.addDirectoryItem(_handle(), url, item, is_folder, 0)


def end_listing(succeeded=True):
    return xbmcplugin.endOfDirectory(_handle(), succeeded)


def cancel_resolve():
    """Sin esto, si play() decide no reproducir nada, el dialogo de "cargando"
    de la consola se queda girando para siempre (mismo motivo que en
    plugin.video.invidious / plugin.video.tdtxbox)."""
    xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())


def play(url, title=None):
    item = xbmcgui.ListItem(title, path=url)
    if title:
        item.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(_handle(), True, item)


def notification(heading, message, time=5000):
    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_INFO, time)


def ok(heading, *lines):
    xbmcgui.Dialog().ok(heading, *lines)


def progress_dialog(heading, line1="", line2="", line3=""):
    dialog = xbmcgui.DialogProgress()
    dialog.create(heading, line1, line2, line3)
    return dialog


def yesno(heading, line1="", line2="", line3="", nolabel="", yeslabel=""):
    return xbmcgui.Dialog().yesno(heading, line1, line2, line3, nolabel, yeslabel)


def get_input(heading, default_text=""):
    keyboard = xbmc.Keyboard(default_text, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    return None
