# -*- coding: utf-8 -*-
import time

import xbmc
import gui

from . import bridge

# Entradas de la raiz de Alfa que no tienen sentido desde la Xbox (abren
# dialogos de ajustes, la videoteca de Kodi, gestor de descargas...):
# fuera del alcance del bridge, que solo navega canales y reproduce.
_UTILITY_LABEL_PREFIXES = ("Videoteca", "Descargas", "Ajustes", "Reportar", "Ayuda")
_UTILITY_ACTIONS = ("settings", "opciones", "configuracion")
_SEARCH_ACTIONS = ("new_search", "search")


def _show_problem(data, fallback):
    lines = bridge.describe_problem(data) or [fallback]
    gui.ok("AlfaXbox", *lines)


def _is_hidden(item, at_root):
    if not item["folder"] and not item["playable"]:
        return True  # texto informativo de Alfa, no se puede abrir
    if gui.addon.getSetting("hide_utility") != "false":
        if item.get("action") in _UTILITY_ACTIONS:
            return True
        if at_root and item["label"].startswith(_UTILITY_LABEL_PREFIXES):
            return True
    return False


def browse(url_params):
    q = url_params.get("q", "")
    text = None
    if url_params.get("ask"):
        text = gui.get_input("Buscar")
        if not text:
            gui.end_listing()
            return

    data = bridge.list_items(q, text)
    items = data.get("items") or []
    if not items:
        _show_problem(data, "Alfa no devolvio ningun resultado.")
        gui.end_listing()
        return

    show_thumbs = gui.addon.getSetting("show_thumbs") == "true"
    for it in items:
        if _is_hidden(it, at_root=not q):
            continue
        thumb = it["thumb"] if show_thumbs and it["thumb"].startswith("http") else None
        info = {"title": it["label"]}
        if it["plot"]:
            info["plot"] = it["plot"]
        if it["playable"]:
            gui.add_item(
                it["label"], "play.png", thumb=thumb,
                url_params={"route": "play", "q": it["q"], "name": it["label"]},
                video_infotag=info, is_folder=False,
            )
        else:
            params = {"route": "browse", "q": it["q"]}
            icon = "folder.png"
            if it["action"] in _SEARCH_ACTIONS:
                params["ask"] = "1"
                icon = "search.png"
            gui.add_item(it["label"], icon, thumb=thumb, url_params=params, video_infotag=info)
    gui.end_listing()


def play(url_params):
    """Mismo envoltorio que plugin.video.invidious/tdtxbox: si _play_impl()
    no resuelve nada, hay que decirselo explicitamente a Kodi o el
    dialogo de "cargando" se queda girando para siempre."""
    resolved = False
    try:
        resolved = _play_impl(url_params)
    finally:
        if not resolved:
            gui.cancel_resolve()


def _play_impl(url_params):
    q = url_params.get("q")
    if not q:
        xbmc.log("plugin.video.alfaxbox play: called without q", xbmc.LOGWARNING)
        return False

    name = url_params.get("name") or "AlfaXbox"
    data = bridge.resolve(q)
    token = data.get("token")
    if not token:
        xbmc.log("plugin.video.alfaxbox play: no se pudo resolver '{}': {}".format(name, data), xbmc.LOGWARNING)
        _show_problem(data, "No se pudo obtener el video de este enlace (la web o el servidor de video pueden haber cambiado o estar caidos).")
        return False

    # Si el video se corto hace poco, el bridge recuerda por 5 minutos donde iba (ver alfa_bridge.py, "resume")
    start = 0
    resume = data.get("resume")
    if resume and gui.yesno(
        "AlfaXbox",
        "La reproduccion se corto en {}.".format(_clock(resume["position"])),
        "Continuar desde ahi (disponible {} min mas)?".format(max(1, resume["seconds_left"] // 60)),
        "", "Desde el principio", "Continuar",
    ):
        start = resume["position"]

    if data.get("torrent") and not _wait_torrent(token, name):
        return False

    url = bridge.stream_url(token, start)
    xbmc.log("plugin.video.alfaxbox play: {} -> {}".format(name, url), xbmc.LOGNOTICE)
    gui.play(url, title=name)
    return True


# Torrest tarda en encontrar pares y llenar el buffer inicial; el bridge se rinde antes (90 s metadatos, 240 s
# buffer), este tope solo evita esperar para siempre si el bridge dejara de responder.
_TORRENT_WAIT_SECONDS = 360


def _clock(seconds):
    seconds = int(seconds)
    if seconds >= 3600:
        return "{}:{:02d}:{:02d}".format(seconds // 3600, seconds // 60 % 60, seconds % 60)
    return "{}:{:02d}".format(seconds // 60, seconds % 60)


def _size(n):
    return "{:.1f} MB".format(n / 1048576.0)


def _wait_torrent(token, name):
    """El bridge prepara el torrent en segundo plano (Torrest en el mini PC); aqui se muestra el progreso, como
    hace el addon Torrest en Kodi. True cuando esta listo para reproducir."""
    dialog = gui.progress_dialog("AlfaXbox", "Conectando con Torrest...", name)
    deadline = time.time() + _TORRENT_WAIT_SECONDS
    try:
        while True:
            st = bridge.torrent_status(token)
            state = st.get("state")
            if state == "ready":
                return True
            if state in ("error", "cancelled"):
                gui.ok("AlfaXbox", st.get("error") or "No se pudo preparar el torrent.")
                return False
            if state == "metadata":
                line1 = "Buscando pares y metadatos del torrent..."
            else:
                line1 = "Descargando el buffer inicial: {:.0f}%".format(st.get("progress", 0))
            line2 = "Pares: {}   Velocidad: {}/s".format(st.get("peers", 0), _size(st.get("rate", 0)))
            line3 = "{} ({})".format(st["name"], _size(st["size"])) if st.get("name") else name
            dialog.update(int(st.get("progress", 0)), line1, line2, line3)
            if dialog.iscanceled():
                bridge.torrent_cancel(token)
                return False
            if time.time() > deadline:
                bridge.torrent_cancel(token)
                gui.ok("AlfaXbox", "El torrent tarda demasiado en estar listo.")
                return False
            xbmc.sleep(1500)
    finally:
        dialog.close()
