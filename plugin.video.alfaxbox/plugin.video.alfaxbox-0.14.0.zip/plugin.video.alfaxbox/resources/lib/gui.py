import os
import sys
import urllib
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

# Con <reuselanguageinvoker> el motor podria dejar este modulo importado entre invocaciones
# distintas del addon (handle de Kodi distinto en cada una) - por eso antes esto se leia de sys.argv
# en cada llamada en vez de una vez al importar. Comprobado en produccion (26/09/2026) que en este
# motor NO es asi: cada invocacion reimporta el modulo de cero (sys.modules no lo mantiene vivo
# entre invocaciones), asi que leerlo aqui, a nivel de modulo, es seguro - mismo patron que ya usan
# plugin.video.tdtxbox/invidious. Ademas, hacerlo ANTES de instanciar Addon() evita un
# EXCEPTION_BREAKPOINT real confirmado por bisecion: combinar una llamada de red bloqueante con
# xbmcaddon.Addon()+xbmcgui en el mismo invoker crashea la consola minutos despues, en el cierre de
# un interprete completamente ajeno; con este orden (igual que tdtxbox/invidious) no reproduce.
ADDON_HANDLE = int(sys.argv[1])
ADDON_VFS_PATH = sys.argv[0]

addon = xbmcaddon.Addon()


def set_content(content):
    """movies/tvshows/episodes...: activa las vistas con caratula e informacion de la skin."""
    xbmcplugin.setContent(ADDON_HANDLE, content)


def add_item(title, icon=None, thumb=None, url_params=None, video_infotag=None, is_folder=True, art=None):
    item = xbmcgui.ListItem(title)

    images = {}
    if icon:
        images["icon"] = os.path.join(addon.getAddonInfo("path"), "resources", "media", icon)
    if thumb:
        images["thumb"] = thumb
    if art:
        images.update(art)
    item.setArt(images)
    if images.get("fanart"):
        item.setProperty("fanart_image", images["fanart"])      # skins antiguas leen esta propiedad

    url = "{}?{}".format(ADDON_VFS_PATH, urllib.urlencode(url_params))

    if video_infotag is not None:
        item.setInfo("video", video_infotag)
    if not is_folder:
        item.setProperty("IsPlayable", "True")

    return xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, item, is_folder, 0)


def end_listing(succeeded=True, cache=True):
    return xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded, False, cache)


def cancel_resolve():
    """Sin esto, si play() decide no reproducir nada, el dialogo de "cargando"
    de la consola se queda girando para siempre (mismo motivo que en
    plugin.video.invidious / plugin.video.tdtxbox)."""
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())


def play(url, title=None):
    item = xbmcgui.ListItem(title, path=url)
    if title:
        item.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, item)


def notification(heading, message, time=5000):
    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_INFO, time)


def ok(heading, *lines):
    xbmcgui.Dialog().ok(heading, *lines)


def progress_dialog(heading, line1="", line2="", line3=""):
    dialog = xbmcgui.DialogProgress()
    dialog.create(heading, line1, line2, line3)
    return dialog


def yesno(heading, line1="", line2="", line3="", nolabel="", yeslabel=""):
    return xbmcgui.Dialog().yesno(heading, line1, line2, line3, nolabel, yeslabel)


def select(heading, options):
    """Indice elegido, o -1 si el usuario cancela (Atras/Escape) sin elegir nada."""
    return xbmcgui.Dialog().select(heading, options)


def textviewer(heading, text):
    """Visor de texto de XBMC (para el changelog); si esta compilacion no lo tuviera, un dialogo con las primeras lineas."""
    try:
        xbmcgui.Dialog().textviewer(heading, text)
    except Exception:
        lines = [l for l in text.splitlines() if l.strip()][:3]
        xbmcgui.Dialog().ok(heading, *lines)


def get_input(heading, default_text=""):
    keyboard = xbmc.Keyboard(default_text, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    return None


class DownloadsOverlay(xbmcgui.WindowDialog):
    """Panel traslucido no bloqueante con el estado de las descargas en curso. Mismo mecanismo (controles
    anadidos a mano con xbmcgui.WindowDialog, sin fichero .xml) y los mismos datos que ya muestra el overlay de
    pausa de plugin.video.torrest (pares, semillas, velocidad de bajada/subida) - la diferencia es el gancho: alli
    aparece solo al pausar un video que ya se esta reproduciendo, aqui no hay ningun video en la Xbox (el trabajo
    vive en el mini PC). Se abre sola al arrancar una descarga (ver router.py, _start_download) y tambien desde el
    boton "Descargas" del menu principal (Home.xml, RunPlugin - ya no hay un item propio dentro de AlfaXbox).

    Atras/B cierra la ventana sin mas - no toca la descarga, que sigue igual en el mini PC. Y (mapeado a
    ACTION_QUEUE_ITEM por el <global> de gamepad.xml, el unico boton libre en una ventana sin seccion propia en el
    keymap) pide pausarla o retomarla segun lo que este mostrando en ese momento (ver router.py, _watch_downloads,
    que decide cual de las dos toca). Blanco (mapeado a ACTION_CONTEXT_MENU, mismo motivo que Y - libre en el
    <global> salvo en Home, donde no esta reasignado) pide CANCELARLA del todo (con confirmacion, ver
    _watch_downloads). Ninguna llamada de red se hace aqui mismo (esto corre en el hilo de la GUI); solo se dejan
    marcadas las peticiones para que el bucle de sondeo del script (otro hilo) las haga de verdad.

    Los tres avisos de botones (antes tres lineas de texto sueltas) van ahora en una sola fila abajo, con el
    icono del boton real de mando (B/Y/Blanco, preparados por el usuario) junto a un texto corto - mismo criterio
    visual que las tarjetas del carrusel de Inicio."""

    _W, _H = 900, 250
    _PAD = 24
    _HINT_ICON = 40
    _HINT_ROW_H = 46
    _HINT_SEGMENT_W = 280

    @staticmethod
    def _skin_background():
        """Mismo fondo de pantalla que pinta el propio skin (CommonBackground, en
        IncludesBackgroundBuilding.xml, usado por Home e Insignia): special://skin/backgrounds/<tema
        actual>.jpg, con SKINDEFAULT.jpg como respaldo si ese archivo no existe (mismo <texture
        fallback="..."> que usa el XML). xbmc.translatePath()+os.path.exists en vez de xbmcvfs, mismo criterio
        que el resto del proyecto para evitarlo en interpretes que se cierran (aqui no aplica de verdad -
        es el interprete principal del addon, no un servicio - pero se mantiene la costumbre)."""
        backgrounds_dir = xbmc.translatePath("special://skin/backgrounds/")
        theme = xbmc.getInfoLabel("Skin.CurrentTheme") or "SKINDEFAULT"
        candidate = os.path.join(backgrounds_dir, theme + ".jpg")
        if os.path.exists(candidate):
            return candidate
        return os.path.join(backgrounds_dir, "SKINDEFAULT.jpg")

    def __init__(self):
        xbmcgui.WindowDialog.__init__(self)
        x = (1280 - self._W) // 2
        # Xbox-Luzbel (26/09/2026): panel subido a la parte superior de la pantalla (antes centrado, y=235,
        # se solapaba con la fila de tarjetas del carrusel de Inicio) - y=75 deja libre el reloj/fecha de
        # arriba a la derecha (ocupan hasta ~y=65) sin llegar a las tarjetas (que empiezan en y=246).
        y = 75
        bg_path = os.path.join(addon.getAddonInfo("path"), "resources", "media", "black.png")
        media_path = os.path.join(addon.getAddonInfo("path"), "resources", "media")
        label_w = self._W - 2 * self._PAD
        # Xbox-Luzbel (26/09/2026): el atenuador negro semitransparente (probado antes) seguia dejando ver
        # de fondo el logo de Kodi, el carrusel y el texto de depuracion de Inicio por debajo (WindowDialog no
        # cierra la ventana de Inicio, solo se dibuja encima). A peticion del usuario: en vez de un negro
        # traslucido, se pinta EL MISMO fondo de pantalla que usa el propio skin (ver _skin_background) a
        # pantalla completa y del todo opaco - igual que se ve al entrar en Insignia (una ventana real que si
        # cierra Inicio del todo, pero comparte el mismo fondo via CommonBackground). No es exactamente lo
        # mismo por dentro (esto sigue siendo un dialogo encima de Inicio, no una ventana que lo reemplaza),
        # pero visualmente tapa a Inicio por completo y muestra lo mismo que se ve al entrar en Insignia.
        # aspectRatio=1 ("scale up (crops)") es el mas parecido al <aspectratio>scale</aspectratio> del XML del
        # skin - la imagen llena los 1280x720 recortando el sobrante en vez de deformarse o dejar barras.
        self._dimmer = xbmcgui.ControlImage(0, 0, 1280, 720, self._skin_background(), aspectRatio=1)
        self._bg = xbmcgui.ControlImage(x, y, self._W, self._H, bg_path, colorDiffuse="0xD0000000")
        self._label1 = xbmcgui.ControlLabel(x + self._PAD, y + self._PAD, label_w, 40, "",
                                             textColor="0xFFFFD700")
        self._label2 = xbmcgui.ControlLabel(x + self._PAD, y + self._PAD + 46, label_w, 36, "")
        self._label3 = xbmcgui.ControlLabel(x + self._PAD, y + self._PAD + 92, label_w, 36, "")

        # Tres avisos (Atras/Y/Blanco) en una sola fila, icono real de mando + texto corto en vez de las tres
        # lineas de texto sueltas de antes (a peticion del usuario, tras ver la captura de la consola). Iconos
        # a 40px (antes 26px, ilegibles - la B/Y/aro blanco no se distinguian de un manchon de color).
        # alignment=4 es XBFONT_CENTER_Y (ControlLabel no tiene un "aligny" propio, solo este bitmask).
        hint_y = y + self._H - self._PAD - self._HINT_ROW_H
        icon_dy = (self._HINT_ROW_H - self._HINT_ICON) // 2
        seg_x = [x + self._PAD + i * self._HINT_SEGMENT_W for i in range(3)]
        text_w = self._HINT_SEGMENT_W - self._HINT_ICON - 10
        self._hint_icon = xbmcgui.ControlImage(seg_x[0], hint_y + icon_dy, self._HINT_ICON, self._HINT_ICON,
                                                os.path.join(media_path, "button_b.png"))
        self._hint = xbmcgui.ControlLabel(seg_x[0] + self._HINT_ICON + 10, hint_y, text_w, self._HINT_ROW_H,
                                           "Cerrar", textColor="0xFFAAAAAA", alignment=4)
        self._hint2_icon = xbmcgui.ControlImage(seg_x[1], hint_y + icon_dy, self._HINT_ICON, self._HINT_ICON,
                                                 os.path.join(media_path, "button_y.png"))
        self._hint2 = xbmcgui.ControlLabel(seg_x[1] + self._HINT_ICON + 10, hint_y, text_w, self._HINT_ROW_H,
                                            "Pausar", textColor="0xFFAAAAAA", alignment=4)
        self._hint3_icon = xbmcgui.ControlImage(seg_x[2], hint_y + icon_dy, self._HINT_ICON, self._HINT_ICON,
                                                 os.path.join(media_path, "button_white.png"))
        self._hint3 = xbmcgui.ControlLabel(seg_x[2] + self._HINT_ICON + 10, hint_y, text_w, self._HINT_ROW_H,
                                            "Cancelar", textColor="0xFFAAAAAA", alignment=4)
        self._closed = False
        self._action_requested = False
        self._cancel_requested = False
        for control in (self._dimmer, self._bg, self._label1, self._label2, self._label3,
                         self._hint_icon, self._hint, self._hint2_icon, self._hint2,
                         self._hint3_icon, self._hint3):
            self.addControl(control)

    def set_text(self, line1, line2="", line3=""):
        self._label1.setLabel(line1)
        self._label2.setLabel(line2)
        self._label3.setLabel(line3)

    def set_hint2(self, text):
        """Texto corto junto al icono Y - cambia entre "Pausar"/"Reanudar"/"No disponible" segun el estado que
        se este mostrando, ver router.py, _watch_downloads."""
        self._hint2.setLabel(text)

    def set_hint3(self, text):
        """Texto corto junto al icono Blanco - "Cancelar" o "No disponible" (trabajos de Invidious, que no
        admite cancelar), ver router.py, _watch_downloads."""
        self._hint3.setLabel(text)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self._closed = True
            self.close()
        elif action_id == xbmcgui.ACTION_QUEUE_ITEM:
            self._action_requested = True
        elif action_id == xbmcgui.ACTION_CONTEXT_MENU:
            self._cancel_requested = True

    def request_close(self):
        """Cierra la ventana desde fuera de onAction() (el bucle de sondeo de router.py, tras confirmar y
        cancelar del todo una descarga) - mismo efecto que pulsar Atras."""
        self._closed = True
        self.close()

    @property
    def closed(self):
        return self._closed

    @property
    def action_requested(self):
        return self._action_requested

    def clear_action_requested(self):
        self._action_requested = False

    @property
    def cancel_requested(self):
        return self._cancel_requested

    def clear_cancel_requested(self):
        self._cancel_requested = False
