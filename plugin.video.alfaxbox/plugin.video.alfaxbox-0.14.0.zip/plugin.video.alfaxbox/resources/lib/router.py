# -*- coding: utf-8 -*-
import time

import xbmc
import gui

from . import bridge
from . import updater

# Entradas de la raiz de Alfa que no tienen sentido desde la Xbox (abren
# dialogos de ajustes, la videoteca de Kodi, gestor de descargas...):
# fuera del alcance del bridge, que solo navega canales y reproduce.
_UTILITY_LABEL_PREFIXES = ("Videoteca", "Descargas", "Ajustes", "Reportar", "Ayuda")
_UTILITY_ACTIONS = ("settings", "opciones", "configuracion")
_SEARCH_ACTIONS = ("new_search", "search")
_CONTENT_TYPES = ("movies", "tvshows", "episodes", "seasons")
# Anchos a los que el bridge reduce las imagenes: cabe de sobra en la textura de una vista de carteles y se descarga rapido.
_POSTER_WIDTH = 200
_FANART_WIDTH = 640


def _show_problem(data, fallback):
    lines = bridge.describe_problem(data) or [fallback]
    gui.ok("AlfaXbox", *lines)


def _is_hidden(item, at_root):
    if not item["folder"] and not item["playable"]:
        return True  # texto informativo de Alfa, no se puede abrir
    if item.get("action") == "save_download":
        # La propia entrada "-Descargar Pelicula/Serie-" de Alfa: en el bridge no hace nada de verdad (encola en un
        # proceso que termina al momento, ver alfa_bridge.py) - siempre oculta, tenga o no el usuario activado
        # "Ocultar entradas", porque ahora la descarga real se ofrece al reproducir (dialogo "Ver"/"Descargar").
        return True
    if gui.addon.getSetting("hide_utility") != "false":
        if item.get("action") in _UTILITY_ACTIONS:
            return True
        if at_root and item["label"].startswith(_UTILITY_LABEL_PREFIXES):
            return True
    return False


def browse(url_params):
    q = url_params.get("q", "")
    text = None
    if url_params.get("ask"):
        text = gui.get_input("Buscar")
        if not text:
            gui.end_listing()
            return

    data = bridge.list_items(q, text)
    items = data.get("items") or []
    if not items:
        _show_problem(data, "Alfa no devolvio ningun resultado.")
        gui.end_listing()
        return

    if not q:
        _update_entry()
    # Ajuste "show_posters": el antiguo "show_thumbs" (por defecto false en la 0.1.0) quedo guardado en la consola y pisaba el
    # nuevo valor por defecto, asi que las caratulas no salian; con otro nombre vale el defecto (true).
    show_thumbs = gui.addon.getSetting("show_posters") != "false"
    show_fanart = gui.addon.getSetting("show_fanart") == "true"
    if data.get("content") in _CONTENT_TYPES:
        gui.set_content(data["content"])
    for it in items:
        if _is_hidden(it, at_root=not q):
            continue
        art = _art(it, show_thumbs, show_fanart)
        info = _info(it)
        if it["playable"]:
            gui.add_item(
                it["label"], "play.png", art=art,
                url_params={"route": "play", "q": it["q"], "name": _display_name(it, info)},
                video_infotag=info, is_folder=False,
            )
        else:
            params = {"route": "browse", "q": it["q"]}
            icon = "folder.png"
            if it["action"] in _SEARCH_ACTIONS:
                params["ask"] = "1"
                icon = "search.png"
            gui.add_item(it["label"], icon, art=art, url_params=params, video_infotag=info)
    # El menu principal no se cachea: XBMC guarda la lista en cache y al volver a entrar no ejecutaba el addon, asi que
    # el aviso de actualizacion seguia saliendo (con la version vieja) aunque ya se hubiera actualizado.
    gui.end_listing(cache=bool(q))


def _update_entry():
    """Linea amarilla informativa al principio del menu principal: solo si hay version nueva (o esta es demasiado vieja)."""
    try:
        info = updater.check()
    except Exception as e:  # noqa: BLE001 - el aviso nunca debe romper el menu
        xbmc.log("plugin.video.alfaxbox: no se pudo comprobar la version: {}".format(e), xbmc.LOGWARNING)
        return
    if not info:
        return
    updater.announce(info)
    text = updater.label(info)
    if text:
        gui.add_item(text, "folder.png", url_params={"route": "updateinfo"})
    toast, warn = updater.alfa_status(info)
    pending = updater.alfa_pending(info)
    offered = updater.offer_alfa_upgrade(info)           # primera vez de la sesion: changelog + confirmacion
    if not offered:
        updater.announce_alfa(toast)
    if warn:
        gui.add_item("[COLOR yellow]{}[/COLOR]".format(warn[:110]), "folder.png", url_params={"route": "info", "msg": warn})
    line = updater.pending_line(info)
    if line:
        route = {"route": "alfaupgrade"} if pending.get("ready") else {"route": "info", "msg": line}
        gui.add_item("[COLOR yellow]{}[/COLOR]".format(line[:110]), "folder.png", url_params=route)


def show_info(url_params):
    """Linea amarilla informativa: al pulsarla se muestra el texto completo, nada mas."""
    gui.ok("AlfaXbox", url_params.get("msg", ""))
    gui.end_listing()


def alfa_upgrade(url_params):
    """Linea amarilla de "version nueva de Alfa": vuelve a mostrar los cambios y pregunta si instalar."""
    info = updater.check()
    if info:
        updater.offer_alfa_upgrade(info, force=True)
    gui.end_listing()


def update_info(url_params):
    """La linea amarilla solo informa: al pulsarla se explica donde se actualiza, nada mas."""
    updater.how_to()
    gui.end_listing()


def _art(it, show_thumbs, show_fanart):
    """Caratula y fondo, ya reducidos por el bridge a un tamano que la Xbox pueda con (ver image_cache.py)."""
    art = {}
    images = it.get("art") or {}
    poster = images.get("poster") or images.get("thumb")
    if show_thumbs and poster:
        art["thumb"] = art["poster"] = bridge.image_url(poster, _POSTER_WIDTH)
    if show_fanart and images.get("fanart"):
        art["fanart"] = bridge.image_url(images["fanart"], _FANART_WIDTH)
    return art


def _display_name(it, info):
    """Nombre para el dialogo "Ver"/"Descargar", "Descargas en curso" y los avisos de progreso - distinto del
    "label" de la fila en la lista (ver gui.add_item mas abajo, ese no cambia). En el nivel mas hondo de Alfa (la
    lista de enlaces de UNA pelicula concreta) el "label" de cada item es solo una etiqueta decorativa de
    calidad/formato (p.ej. "[?] [Torrent] [DVDrip] ['CAST'] [2,0 GB]"), nunca el nombre de la pelicula - Alfa no
    lo repite ahi porque el contexto ya esta claro al navegar. Bug reportado por el usuario (23/09/2026): sin
    esto, ni el dialogo ni "Descargas en curso" mostraban nunca el nombre real."""
    title = info.get("title")
    label = it["label"]
    if title and title != label:
        return "{} - {}".format(title, label)
    return label


def _info(it):
    """Etiquetas de video (resumen, ano, genero, nota...) con los tipos que espera XBMC."""
    info = {"title": it["label"]}
    if it.get("plot"):
        info["plot"] = it["plot"]
    for key, value in (it.get("info") or {}).items():
        try:
            if key in ("year", "season", "episode", "votes"):
                info[key] = int(value)
            elif key == "rating":
                info[key] = float(value)
            else:
                info[key] = value
        except (TypeError, ValueError):
            pass
    return info


def play(url_params):
    """Mismo envoltorio que plugin.video.invidious/tdtxbox: si _play_impl()
    no resuelve nada, hay que decirselo explicitamente a Kodi o el
    dialogo de "cargando" se queda girando para siempre."""
    resolved = False
    try:
        resolved = _play_impl(url_params)
    finally:
        if not resolved:
            gui.cancel_resolve()


def _play_impl(url_params):
    q = url_params.get("q")
    if not q:
        xbmc.log("plugin.video.alfaxbox play: called without q", xbmc.LOGWARNING)
        return False

    name = url_params.get("name") or "AlfaXbox"
    data = bridge.resolve(q)
    token = data.get("token")
    if not token:
        xbmc.log("plugin.video.alfaxbox play: no se pudo resolver '{}': {}".format(name, data), xbmc.LOGWARNING)
        _show_problem(data, "No se pudo obtener el video de este enlace (la web o el servidor de video pueden haber cambiado o estar caidos).")
        return False

    is_torrent = bool(data.get("torrent"))
    # Mismo patron ("Ver"/"Descargar" al pulsar, no un menu contextual aparte) que ya usa plugin.video.invidious.
    # Con un torrent, "Descargar" baja el archivo COMPLETO (no solo el buffer inicial que usa la reproduccion en
    # directo, ver torrent_jobs.py) - tarda mas, pero el bridge ya lo soporta igual que un enlace de hoster.
    #
    # Kodi abre su propio "busydialog" en cuanto arranca este script (OnPlayMedia/route=play) y lo deja abierto
    # esperando setResolvedUrl(). Confirmado por log en produccion (22/09/2026, ver NOTAS-PENDIENTE-2026-09-21.md
    # §14): abrir OTRO dialogo modal (este select) mientras ese busydialog sigue activo no llega a pintarse en
    # pantalla en esta build - GetSelectedItem() devuelve su valor por defecto (0, "Ver") sin que el usuario pueda
    # elegir nada. Cerrarlo primero (builtin idempotente, no falla si ya estaba cerrado) es el arreglo estandar en
    # addons de Kodi para diálogos interactivos abiertos dentro del propio resolve.
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    choice = gui.select(name, ["Ver", "Descargar"])
    if choice < 0:
        return False      # Atras/Escape: no elegido nada, no reproducir por defecto
    if choice == 1:
        _start_download(q, name)
        return False

    # Si el video se corto hace poco, el bridge recuerda por 5 minutos donde iba (ver alfa_bridge.py, "resume")
    start = 0
    resume = data.get("resume")
    if resume and gui.yesno(
        "AlfaXbox",
        "La reproduccion se corto en {}.".format(_clock(resume["position"])),
        "Continuar desde ahi (disponible {} min mas)?".format(max(1, resume["seconds_left"] // 60)),
        "", "Desde el principio", "Continuar",
    ):
        start = resume["position"]

    if is_torrent and not _wait_torrent(token, name):
        return False

    alang = {"Espanol": "spa", "English": "eng", "Original": "orig"}.get(gui.addon.getSetting("audio_lang"), "spa")
    url = bridge.stream_url(token, start, alang)
    xbmc.log("plugin.video.alfaxbox play: {} -> {}".format(name, url), xbmc.LOGNOTICE)
    gui.play(url, title=name)
    return True


def _start_download(q, name):
    folder = gui.addon.getSetting("download_folder") or "F:\\Videos"
    job_id, data = bridge.start_download(q, folder, filename=name, title=name)
    if not job_id:
        xbmc.log("plugin.video.alfaxbox download: no se pudo iniciar '{}': {}".format(name, data), xbmc.LOGWARNING)
        _show_problem(data, "No se pudo iniciar la descarga (el mini PC puede estar apagado o no responde).")
        return
    # La pantalla de "Descargas en curso" se abre aqui mismo, sola - antes solo se avisaba con una notificacion y
    # habia que entrar a mano al addon para verla (a peticion del usuario, 23/09/2026). Mismo motivo que con
    # gui.select() en _play_impl(): esto corre dentro del propio callback de resolucion de Kodi (route=play), que
    # deja su propio "busydialog" automatico abierto de fondo - cerrarlo antes evita que quede sin pintarse.
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    overlay = gui.DownloadsOverlay()
    overlay.show()
    try:
        _watch_downloads(overlay, job_id=job_id)
    finally:
        overlay.close()


# Torrest tarda en encontrar pares y llenar el buffer inicial; el bridge se rinde antes (90 s metadatos, 240 s
# buffer), este tope solo evita esperar para siempre si el bridge dejara de responder.
_TORRENT_WAIT_SECONDS = 360


def _clock(seconds):
    seconds = int(seconds)
    if seconds >= 3600:
        return "{}:{:02d}:{:02d}".format(seconds // 3600, seconds // 60 % 60, seconds % 60)
    return "{}:{:02d}".format(seconds // 60, seconds % 60)


def _size(n):
    return "{:.1f} MB".format(n / 1048576.0)


# Estados posibles, YA NORMALIZADOS entre las dos fuentes que fusiona este panel (ver _all_jobs) - mismas
# etiquetas que usan los propios servicios de avisos, para no decir cosas distintas en la pantalla que en el
# aviso (mientras siga activo alguno):
#   AlfaXbox (alfa_bridge.py DownloadJob): starting/torrent/downloading/uploading/done/error/cancelled/paused.
#   Invidious (invidious_download.py "stage", ver _INVIDIOUS_STAGE_TO_STATE): sin pausar/cancelar - ese backend
#   es mas simple y no tiene esa capacidad (25/09/2026, decision del usuario: panel de solo consulta para
#   Invidious, no se construye pausar/cancelar en su lado del mini PC por ahora).
_DOWNLOAD_STATE_LABELS = {
    "starting": "Empezando",
    "fetching": "Descargando",            # solo Invidious: bajando del origen, antes de recodificar
    "torrent": "Descargando el torrent",  # solo AlfaXbox
    "downloading": "Recodificando",
    "uploading": "Subiendo a la Xbox",
    "done": "Completada",
    "error": "Fallida",
    "cancelled": "Cancelada",             # solo AlfaXbox
    "paused": "Pausada",                  # solo AlfaXbox
}
_DOWNLOAD_TERMINAL_STATES = ("done", "error", "cancelled")

_INVIDIOUS_STAGE_TO_STATE = {
    "empezando": "starting",
    "descargando_video": "fetching",
    "descargando_audio": "fetching",
    "recodificando": "downloading",
    "subiendo": "uploading",
    "completado": "done",
    "fallo": "error",
}


def _normalize_alfaxbox_job(job):
    """Los trabajos de bridge.download_jobs()/download_status() ya usan el vocabulario de _DOWNLOAD_STATE_LABELS
    tal cual - solo se anade la etiqueta de origen ("Torrent" si el job trae datos de torrent, "AlfaXbox" si no)
    y can_control=True (unica fuente con pausar/cancelar de verdad, ver bridge.download_cancel/resume/discard)."""
    job = dict(job)
    job["source"] = "Torrent" if job.get("torrent") else "AlfaXbox"
    job["can_control"] = True
    return job


def _normalize_invidious_job(job):
    """Traduce el vocabulario de invidious_download.py ("stage") al de _DOWNLOAD_STATE_LABELS ("state") - ver
    _INVIDIOUS_STAGE_TO_STATE. can_control=False: ese backend no soporta pausar/cancelar."""
    return {
        "job": job.get("job_id"),
        "title": job.get("title") or job.get("video_id") or "Invidious",
        "state": _INVIDIOUS_STAGE_TO_STATE.get(job.get("stage"), job.get("stage")),
        "percent": job.get("percent"),
        "error": job.get("error"),
        "torrent": None,
        "source": "Invidious",
        "can_control": False,
    }


def _all_jobs():
    """Trabajos de AlfaXbox e Invidious fusionados en una sola lista (mas nuevo primero DENTRO de cada fuente -
    sin un timestamp comun para intercalar los dos con precision entre si, pero en la practica casi nunca hay
    descargas activas de las dos fuentes a la vez). Ver bridge.download_jobs()/bridge.invidious_jobs()."""
    jobs = [_normalize_alfaxbox_job(j) for j in bridge.download_jobs()]
    jobs += [_normalize_invidious_job(j) for j in bridge.invidious_jobs()]
    return jobs


def _pick_download_job(jobs):
    """El mas relevante para mostrar: el primero que siga en marcha (jobs ya vienen mas nuevo primero DENTRO de
    cada fuente, ver _all_jobs), o None si no hay ninguno activo. Antes devolvia el mas reciente de todos aunque
    ya hubiera terminado ("para ver como acabo"), pero el boton "Descargas" del menu principal (Home.xml) se
    puede abrir en cualquier momento sin relacion con ninguna descarga - mostrar una ya terminada, quiza de
    sesiones atras, confundia con una nueva (reportado por el usuario 25/09/2026). _start_download() sigue viendo
    el resultado de LA SUYA en concreto sin pasar por aqui (usa bridge.download_status(job_id) directamente)."""
    for job in jobs:
        if job.get("state") not in _DOWNLOAD_TERMINAL_STATES:
            return job
    return None


def _download_lines(job):
    """(titulo con etiqueta de origen entre corchetes, linea de estado/%, linea de pares/velocidad) para
    gui.DownloadsOverlay - la tercera linea solo tiene contenido en un torrent de AlfaXbox (unico caso con esos
    datos, ver alfa_bridge.py DownloadJob; Invidious nunca trae "torrent")."""
    state = job.get("state")
    label = _DOWNLOAD_STATE_LABELS.get(state, state or "?")
    percent = job.get("percent")
    line2 = "{}: {:.0f}%".format(label, percent) if percent is not None else label
    if state in ("error", "paused") and job.get("error"):
        line2 += " ({})".format(job["error"][:60])
    line3 = ""
    torrent = job.get("torrent")
    if torrent:
        line3 = "D:{}/s  U:{}/s   S:{}/{}  P:{}/{}".format(
            _size(torrent.get("download_rate", 0)), _size(torrent.get("upload_rate", 0)),
            torrent.get("seeders", 0), torrent.get("seeders_total", 0),
            torrent.get("peers", 0), torrent.get("peers_total", 0),
        )
    title = "[{}] {}".format(job.get("source", "?"), job.get("title") or "Descarga")
    return title, line2, line3


def _watch_downloads(overlay, job_id=None):
    """Bucle de sondeo compartido por show_downloads() (boton "Descargas" de Inicio, sigue el trabajo mas
    relevante de AlfaXbox O Invidious, ver _all_jobs) y _start_download() (recien arrancada en AlfaXbox, sigue
    ESE trabajo en concreto por id, aunque haya otras a la vez). Se refresca cada 1,5 s hasta que el overlay se
    cierra (Atras) o Kodi pide abortar.

    Y pide pausar o retomar segun lo que se este viendo en ese momento (estado "paused" -> retomar, cualquier
    otro no terminal -> pausar). Blanco pide CANCELAR del todo (borra lo ya descargado en el mini PC, a
    diferencia de Y que solo pausa) - pide confirmacion antes, y si se confirma cierra el overlay. Ninguno de los
    dos hace nada en un trabajo de Invidious (can_control=False, ver _normalize_invidious_job - ese backend no
    soporta pausar/cancelar) ni en uno ya terminado. Las llamadas de red las hace este hilo, nunca onAction()
    (ese corre en el hilo de la GUI, donde una llamada bloqueante no pinta bien)."""
    monitor = xbmc.Monitor()
    last_job_id = job_id
    last_state = None
    last_can_control = True
    while not overlay.closed and not monitor.abortRequested():
        if job_id:
            job = bridge.download_status(job_id)
            if job:
                job = _normalize_alfaxbox_job(job)
        else:
            jobs = _all_jobs()
            job = _pick_download_job(jobs) if jobs else None
        if job:
            last_job_id = job.get("job") or last_job_id
            last_state = job.get("state")
            last_can_control = job.get("can_control", True)
            overlay.set_text(*_download_lines(job))
            if last_can_control:
                overlay.set_hint2("Reanudar" if last_state == "paused" else "Pausar")
                overlay.set_hint3("Cancelar")
            else:
                overlay.set_hint2("No disponible")
                overlay.set_hint3("No disponible")
        else:
            overlay.set_text("Descargas", "No hay ninguna descarga activa ni reciente.")
        if overlay.action_requested:
            overlay.clear_action_requested()
            if last_can_control and last_job_id and last_state not in _DOWNLOAD_TERMINAL_STATES:
                if last_state == "paused":
                    bridge.download_resume(last_job_id)
                else:
                    bridge.download_cancel(last_job_id)
        if overlay.cancel_requested:
            overlay.clear_cancel_requested()
            if last_can_control and last_job_id and last_state not in _DOWNLOAD_TERMINAL_STATES:
                if gui.yesno(
                    "AlfaXbox",
                    "Cancelar la descarga?",
                    "Se perdera lo ya descargado - no se puede deshacer.",
                    "", "No", "Si, cancelar",
                ):
                    bridge.download_discard(last_job_id)
                    overlay.request_close()
        if monitor.waitForAbort(1.5):
            break


def show_downloads(url_params):
    """Pantalla no bloqueante con el estado de las descargas en curso (ver gui.DownloadsOverlay) - accesible desde
    el boton "Descargas" del menu principal (Home.xml, RunPlugin), no desde el menu de AlfaXbox. Sigue el trabajo
    mas relevante de todos (ver _pick_download_job). Atras la cierra sin tocar nada; Y pausa o retoma segun
    corresponda, Blanco cancela del todo (ver _watch_downloads). Invocado por RunPlugin (no una navegacion de
    carpeta), asi que no hace falta end_listing() al terminar."""
    overlay = gui.DownloadsOverlay()
    overlay.show()
    try:
        _watch_downloads(overlay)
    finally:
        overlay.close()


def _wait_torrent(token, name):
    """El bridge prepara el torrent en segundo plano (Torrest en el mini PC); aqui se muestra el progreso, como
    hace el addon Torrest en Kodi. True cuando esta listo para reproducir."""
    dialog = gui.progress_dialog("AlfaXbox", "Conectando con Torrest...", name)
    deadline = time.time() + _TORRENT_WAIT_SECONDS
    try:
        while True:
            st = bridge.torrent_status(token)
            state = st.get("state")
            if state == "ready":
                return True
            if state in ("error", "cancelled"):
                gui.ok("AlfaXbox", st.get("error") or "No se pudo preparar el torrent.")
                return False
            if state == "metadata":
                line1 = "Buscando pares y metadatos del torrent..."
            else:
                line1 = "Descargando el buffer inicial: {:.0f}%".format(st.get("progress", 0))
            line2 = "Pares: {}   Velocidad: {}/s".format(st.get("peers", 0), _size(st.get("rate", 0)))
            line3 = "{} ({})".format(st["name"], _size(st["size"])) if st.get("name") else name
            dialog.update(int(st.get("progress", 0)), line1, line2, line3)
            if dialog.iscanceled():
                bridge.torrent_cancel(token)
                return False
            if time.time() > deadline:
                bridge.torrent_cancel(token)
                gui.ok("AlfaXbox", "El torrent tarda demasiado en estar listo.")
                return False
            xbmc.sleep(1500)
    finally:
        dialog.close()
