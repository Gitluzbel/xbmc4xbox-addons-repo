import sys
import urlparse
import xbmc

import resources.lib.router as router


def run():
    url_params = dict(urlparse.parse_qsl(sys.argv[2][1:]))

    route = url_params.pop("route", "browse")

    if route == "browse":
        router.browse(url_params)
    elif route == "play":
        router.play(url_params)
    elif route == "alfaupgrade":
        router.alfa_upgrade(url_params)
    elif route == "info":
        router.show_info(url_params)
    elif route == "updateinfo":
        router.update_info(url_params)
    elif route == "downloads":
        router.show_downloads(url_params)
    else:
        xbmc.log("plugin.video.alfaxbox: wrong route: '{}'".format(route), xbmc.LOGNOTICE)
