# -*- coding: utf-8 -*-
"""
Aviso (solo informativo) de que hay una version nueva de AlfaXbox.

El bridge (mini PC) mira cada 30 min la version publicada en el repositorio de addons (repository.xboxog, que una GitHub Action
regenera al hacer push a main) y la ofrece en /alfa/status como "addon_latest", junto con "min_addon", la version minima del
addon que necesita. Asi la Xbox no necesita HTTPS ni bajarse el addons.xml, y el aviso funciona aunque el ajuste global de
actualizaciones de XBMC este en "Nunca" (asi esta en esta consola).

Este modulo NO actualiza nada: solo avisa. La actualizacion la hace XBMC desde Complementos > Actualizaciones disponibles (probado
el 19/09/2026: el repositorio se refresca y XBMC instala la version nueva sin mas). Intentar instalar desde el addon con el comando
InstallAddon no sirve: en esta compilacion sale sin hacer nada si el addon ya esta instalado.
"""
import os
import re
import time

import xbmc
import xbmcgui

import gui
from . import bridge

_NOTIFIED_PROPERTY = "alfaxbox.update_notified"


def _version(text):
    return tuple(int(n) for n in re.findall(r"\d+", text or "")) or (0,)


def installed_version():
    """Version instalada, leida del addon.xml en disco cada vez: con <reuselanguageinvoker> el interprete sigue vivo tras una
    actualizacion y xbmcaddon.Addon() (creado al importar) seguiria diciendo la version vieja."""
    try:
        with open(os.path.join(gui.addon.getAddonInfo("path"), "addon.xml")) as f:
            m = re.search(r'<addon\s[^>]*?version="([^"]+)"', f.read())
        if m:
            return m.group(1)
    except (IOError, OSError):
        pass
    return gui.addon.getAddonInfo("version")


def check():
    """{"installed", "latest", "available", "too_old", "min"} o None si el mini PC no contesta."""
    status = bridge.status()
    if not status:
        return None
    installed = installed_version()
    latest = status.get("addon_latest") or ""
    minimum = status.get("min_addon") or ""
    return {
        "installed": installed,
        "latest": latest,
        "min": minimum,
        "available": bool(latest) and _version(latest) > _version(installed),
        "too_old": bool(minimum) and _version(installed) < _version(minimum),
        "alfa": status.get("alfa") or {},
    }


def _once_per_session(key):
    """True la primera vez que se pregunta en esta sesion de XBMC (propiedad de la ventana principal)."""
    try:
        window = xbmcgui.Window(10000)
        if window.getProperty(key):
            return False
        window.setProperty(key, "1")
    except Exception:
        pass
    return True


def label(info):
    """Texto de la linea amarilla del menu, o None si esta al dia."""
    if info["too_old"]:
        return "[COLOR yellow]AlfaXbox {} es demasiado antiguo para el mini PC (necesita {}): actualizalo[/COLOR]".format(
            info["installed"], info["min"])
    if info["available"]:
        return "[COLOR yellow]Hay una actualizacion de AlfaXbox: {} (tienes {})[/COLOR]".format(info["latest"], info["installed"])
    return None


def announce(info):
    """Toast una vez por sesion de XBMC cuando hay version nueva."""
    if info["available"] and _once_per_session(_NOTIFIED_PROPERTY):
        gui.notification("AlfaXbox", "Hay una version nueva: {} (tienes {})".format(info["latest"], info["installed"]), time=8000)


def how_to():
    gui.ok(
        "AlfaXbox",
        "Para actualizar: Complementos > Actualizaciones disponibles > AlfaXbox > Actualizar.",
        "Despues reinicia XBMC. Si no aparece, espera unos minutos: el repositorio tarda en refrescarse.",
    )


_ALFA_RESULTS = {
    "al-dia": "al dia",
    "actualizado": "parche aplicado",
    "sin-parches": "sin parches publicados",
    "revertido": "el ultimo parche fallo y se revirtio",
    "error": "no se pudo comprobar",
    "pendiente": "hay un parche pendiente",
}


def _when(stamp):
    """'2026-09-19 05:50:12' -> '19/09 05:50'."""
    m = re.match(r"\d{4}-(\d\d)-(\d\d) (\d\d:\d\d)", stamp or "")
    return "{}/{} {}".format(m.group(2), m.group(1), m.group(3)) if m else ""


def alfa_status(info):
    """(texto para el aviso de la sesion, texto de la linea amarilla o None) sobre el Alfa del mini PC, que se actualiza solo
    cada dia (update_alfa.py). La linea amarilla solo sale si hay algo que atender: un parche que fallo y se revirtio, una
    comprobacion con error o una version completa nueva de Alfa (esa hay que instalarla a mano)."""
    alfa = info.get("alfa")
    if not alfa:
        return None, None
    base = "Alfa {}".format(alfa.get("version", "?"))
    if alfa.get("fix"):
        base += " parche {}".format(alfa["fix"])
    result = alfa.get("result", "")
    toast = "{}: {}".format(base, _ALFA_RESULTS.get(result, result or "sin datos"))
    when = _when(alfa.get("checked"))
    if when:
        toast += " (comprobado {})".format(when)
    warn = None
    if alfa.get("new_version") and not alfa.get("pending"):
        warn = "Hay una version nueva de Alfa: {} (el mini PC usa {}). Hay que actualizarla a mano.".format(
            alfa["new_version"], alfa.get("version", "?"))
    if result == "revertido":
        warn = "El ultimo parche de Alfa fallo y se revirtio; se usa el anterior. {}".format(alfa.get("message", ""))
    elif result == "error":
        warn = "No se pudieron comprobar los parches de Alfa en el mini PC. {}".format(alfa.get("message", ""))
    return toast, warn


def announce_alfa(text):
    """Aviso una vez por sesion de XBMC, la primera vez que se entra en AlfaXbox."""
    if text and _once_per_session(_NOTIFIED_PROPERTY + ".alfa"):
        gui.notification("AlfaXbox", text, time=6000)


def alfa_pending(info):
    """Version completa nueva de Alfa preparada por el mini PC (descargada, con md5 y dependencias comprobados) o None."""
    pending = (info.get("alfa") or {}).get("pending") or {}
    return pending if pending.get("version") else None


def pending_line(info):
    """Texto de la linea amarilla sobre una version nueva de Alfa, o None."""
    pending = alfa_pending(info)
    if not pending:
        return None
    if pending.get("ready"):
        return "Hay una version nueva de Alfa: {} (pulsa para ver los cambios e instalar)".format(pending["version"])
    return "Alfa {} no se puede instalar sola: {}".format(pending["version"], pending.get("message", ""))


def offer_alfa_upgrade(info, force=False):
    """Muestra los cambios de la version nueva de Alfa y pide confirmacion para instalarla en el mini PC. Sin force, solo la
    primera vez que se entra en cada sesion de XBMC; la linea amarilla del menu permite volver a verlo."""
    pending = alfa_pending(info)
    if not pending or not pending.get("ready"):
        return False
    if not force and not _once_per_session(_NOTIFIED_PROPERTY + ".alfa_upgrade"):
        return False
    installed = (info.get("alfa") or {}).get("version", "?")
    heading = "Alfa {} disponible (el mini PC usa {})".format(pending["version"], installed)
    gui.textviewer(heading, pending.get("changelog") or "Alfa no publica la lista de cambios de esta version.")
    if gui.yesno(
        "AlfaXbox",
        "Instalar Alfa {} ahora?".format(pending["version"]),
        "Tarda un minuto; mientras, los canales no responden.",
        "", "Ahora no", "Instalar",
    ):
        run_alfa_upgrade(pending["version"])
    return True


def run_alfa_upgrade(version):
    """Lanza la instalacion en el mini PC y espera mostrando el progreso. El bridge copia lo anterior, prueba que Alfa funciona
    y, si no, lo deja como estaba."""
    started = bridge.upgrade_start(version)
    if not started.get("started"):
        gui.ok("AlfaXbox", "No se pudo iniciar la instalacion de Alfa {}.".format(version), started.get("error", ""))
        return False
    dialog = gui.progress_dialog("AlfaXbox", "Instalando Alfa {} en el mini PC...".format(version), "Copia de seguridad, instalacion y prueba.")
    deadline = time.time() + 15 * 60
    state = {}
    try:
        while time.time() < deadline:
            state = bridge.upgrade_status()
            if state.get("state") in ("done", "error"):
                break
            dialog.update(0, "Instalando Alfa {} en el mini PC...".format(version), "Puede tardar un minuto.", "")
            if dialog.iscanceled():
                break
            xbmc.sleep(2000)
    finally:
        dialog.close()
    if state.get("state") == "done":
        gui.ok("AlfaXbox", "Alfa actualizado a la version {}.".format(version), state.get("message", ""))
        return True
    if state.get("state") == "error":
        gui.ok("AlfaXbox", "No se instalo Alfa {}: se ha dejado la version anterior.".format(version), state.get("message", "")[:150])
    else:
        gui.ok("AlfaXbox", "La instalacion sigue en marcha en el mini PC.", "Mira el resultado en unos minutos al abrir AlfaXbox.")
    return False
