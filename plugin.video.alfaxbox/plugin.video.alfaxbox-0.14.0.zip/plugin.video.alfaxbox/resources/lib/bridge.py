# -*- coding: utf-8 -*-
"""
Cliente de alfa-core/alfa-downloads (mini-pc/alfa-bridge/, ver su README.md - "varios servicios en vez de uno")
- el resto del addon (router.py, gui.py) no sabe ni le importa que hay varios servicios en el mini PC.

Desde el 26/09/2026 (bisecado en produccion, NOTAS-PENDIENTE-2026-09-21.md #36) este modulo YA NO abre sockets
el mismo: combinar una llamada de red bloqueante con xbmcaddon.Addon()/xbmcgui en el mismo interprete de esta
build de XBMC4Xbox corrompe algo que revienta minutos despues en el cierre de OTRO interprete cualquiera.
service.alfaxbox.netclient (servicio aparte, sin xbmcgui ni xbmcaddon en absoluto) es quien de verdad habla con
el mini PC ahora; este modulo solo escribe una peticion en un fichero y espera a que aparezca la respuesta en
otro (ver _call() y el addon.xml de ese servicio para el protocolo completo). stream_url()/image_url() son la
excepcion: nunca hicieron una llamada de red aqui (solo construian el texto de una URL que luego pide el propio
reproductor/skin de Kodi), asi que no necesitan pasar por ese protocolo - solo leen la IP ya resuelta de un
fichero que ese mismo servicio mantiene actualizado (ver _host()).
"""
import json
import os
import time
import urllib

import xbmc

from .gui import addon

_NETCLIENT_ADDON_ID = "service.alfaxbox.netclient"
_BASE_DIR = xbmc.translatePath("special://profile/addon_data/{}/".format(_NETCLIENT_ADDON_ID))
_REQUESTS_DIR = os.path.join(_BASE_DIR, "requests")
_RESPONSES_DIR = os.path.join(_BASE_DIR, "responses")
_HOST_FILE = os.path.join(_BASE_DIR, "host.txt")
_FALLBACK_IP = "192.168.1.134"      # mismo valor de respaldo que usa service.alfaxbox.netclient si la NBNS falla

CORE_PORT = 3004
DOWNLOADS_PORT = 3006
IMG_PORT = 3007

# Alfa puede tardar mucho en un canal lento o con Cloudflare (alfa-core corta a los 150s); un poco mas de margen
# que eso para no cortar antes que el.
REQUEST_TIMEOUT = 170

# Cuanto se espera, sondeando el fichero de respuesta (sin red: solo os.path.exists), antes de darse por vencido -
# un poco mas que el "timeout" que se le pide al propio servicio de red, para dejarle tiempo a escribir el error.
_POLL_MARGIN_SECONDS = 5
_POLL_INTERVAL_MS = 60


def _log(msg, level=xbmc.LOGNOTICE):
    xbmc.log("plugin.video.alfaxbox: " + msg, level)


def _to_str(obj):
    """json de Python 2 devuelve unicode; ListItem/urlencode de esta
    Xbox esperan str UTF-8 (mismo problema ya resuelto en tdtxbox)."""
    if isinstance(obj, unicode):
        return obj.encode("utf-8")
    if isinstance(obj, list):
        return [_to_str(x) for x in obj]
    if isinstance(obj, dict):
        return dict((_to_str(k), _to_str(v)) for k, v in obj.items())
    return obj


def _host():
    """IP del mini PC que service.alfaxbox.netclient dejo en disco (la resuelve el, por NBNS, sin red en ESTE
    proceso) - solo para construir el TEXTO de stream_url()/image_url(), ver el docstring de arriba."""
    try:
        with open(_HOST_FILE, "rb") as f:
            ip = f.read().decode("ascii").strip()
        if ip:
            return ip
    except (OSError, IOError):
        pass
    return _FALLBACK_IP


def _ensure_dirs():
    for d in (_REQUESTS_DIR, _RESPONSES_DIR):
        if not os.path.isdir(d):
            os.makedirs(d)


def _call(backend, path, params, timeout=REQUEST_TIMEOUT):
    """Pide a service.alfaxbox.netclient que haga esta llamada por nosotros (ver su addon.xml/default.py) y
    espera la respuesta sondeando un fichero - devuelve (codigo_http, dict), igual que antes hacia _get() al
    hablar con el socket directamente. code=0 si no se pudo contactar con el mini PC, o si el servicio de red de
    la consola no contesto a tiempo (deberia ser rarisimo: solo si ese servicio esta parado o la consola muy
    cargada)."""
    _ensure_dirs()
    request_id = "%d-%s" % (int(time.time() * 1000) % 10 ** 8, os.urandom(4).encode("hex"))
    request_path = os.path.join(_REQUESTS_DIR, request_id + ".json")
    response_path = os.path.join(_RESPONSES_DIR, request_id + ".json")
    body = json.dumps({"backend": backend, "path": path, "params": params or {}, "timeout": timeout})
    tmp = request_path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(body.encode("utf-8") if isinstance(body, unicode) else body)
    # os.rename() en esta build NO sobreescribe si el destino ya existe (a diferencia de Unix) - request_id
    # es unico por llamada asi que no deberia pasar nunca, pero por si acaso (ver el mismo problema real en
    # service.alfaxbox.netclient/default.py, host.txt).
    try:
        os.remove(request_path)
    except OSError:
        pass
    os.rename(tmp, request_path)

    deadline = time.time() + timeout + _POLL_MARGIN_SECONDS
    while time.time() < deadline:
        if os.path.exists(response_path):
            break
        xbmc.sleep(_POLL_INTERVAL_MS)
    else:
        _log("service.alfaxbox.netclient no contesto a tiempo ({}, {})".format(backend, path), xbmc.LOGWARNING)
        try:
            os.remove(request_path)      # por si sigue ahi (el servicio esta caido/parado del todo)
        except OSError:
            pass
        return 0, {"error": "El servicio de red de la consola (service.alfaxbox.netclient) no contesto a tiempo. "
                            "Comprueba en Ajustes de la consola que ese servicio esta activado."}

    try:
        with open(response_path, "rb") as f:
            data = json.loads(f.read().decode("utf-8"))
    except (OSError, ValueError) as e:
        _log("respuesta ilegible de service.alfaxbox.netclient: {}".format(e), xbmc.LOGWARNING)
        data = {"code": 0, "json": {"error": "Respuesta ilegible del servicio de red de la consola"}}
    finally:
        try:
            os.remove(response_path)
        except OSError:
            pass
    return data.get("code", 0), _to_str(data.get("json") or {})


def status():
    """Estado de alfa-core (versiones incluidas); respuesta rapida, no debe retrasar el menu si el mini PC no contesta."""
    code, data = _call("core", "/alfa/status", {}, timeout=4)
    return data if code == 200 else {}


def upgrade_start(version):
    """Pide al mini PC instalar una version completa de Alfa ya preparada (ver update_alfa.py)."""
    return _call("core", "/alfa/upgrade", {"version": version}, timeout=15)[1]


def upgrade_status():
    return _call("core", "/alfa/upgrade/status", {}, timeout=10)[1]


# Ajuste "BTDigg / proxies" (categoria "Velocidad"): un unico labelenum con las 4 combinaciones de las dos esperas opcionales de
# Alfa en el mini PC, en vez de dos "bool" - con dos ajustes de tipo bool independientes la etiqueta larga de cada uno tapaba el
# interruptor al enfocarlo (mismo problema que tenia "Calidad de imagen" en TDTXbox). "Sin ninguno" es el valor de fabrica: sin
# BTDigg ni proxies, abrir los enlaces de una pelicula pasa de ~80 s a ~6 s (medido el 21/09/2026); "Normal" es como viene Alfa de
# serie (mas lento, mas resultados en canales BT y webs que solo abren por proxy). Un bridge anterior a la 1.6.0 ignora estos
# parametros.
_SPEED_MODES = {
    "Sin ninguno": (False, False),
    "Sin BTDigg": (False, True),
    "Sin proxies": (True, False),
    "Normal": (True, True),
}
DEFAULT_SPEED_MODE = "Sin ninguno"


def alfa_options():
    btdigg, proxies = _SPEED_MODES.get(addon.getSetting("speed_mode"), _SPEED_MODES[DEFAULT_SPEED_MODE])
    return {"btdigg": "1" if btdigg else "0", "proxies": "1" if proxies else "0"}


def list_items(q="", text=None):
    params = alfa_options()
    if q:
        params["q"] = q
    if text:
        params["text"] = text.encode("utf-8") if isinstance(text, unicode) else text
    return _call("core", "/alfa/list", params)[1]


def resolve(q):
    params = alfa_options()
    params["q"] = q
    return _call("core", "/alfa/resolve", params)[1]


def start_download(q, folder, filename="", title=""):
    """Pide a alfa-downloads que descargue el enlace entero y lo suba por FTP a "folder" en la Xbox. No espera a
    que termine - devuelve (job_id o None, data): data trae el error si algo fue mal al arrancar el trabajo (mini
    PC apagado, enlace no resoluble...). El progreso lo sondea el panel "Descargas" bajo demanda (ver router.py,
    show_downloads/_watch_downloads), no un servicio de fondo aparte."""
    params = alfa_options()
    params.update({"q": q, "folder": folder.encode("utf-8") if isinstance(folder, unicode) else folder})
    if filename:
        params["filename"] = filename.encode("utf-8") if isinstance(filename, unicode) else filename
    if title:
        params["title"] = title.encode("utf-8") if isinstance(title, unicode) else title
    code, data = _call("downloads", "/alfa/download", params, timeout=20)
    return (data.get("job") if code == 200 else None), data


def download_jobs():
    """Lista de trabajos de descarga (activos o recientes, mas nuevo primero). Lista vacia si el mini PC no
    responde, nunca lanza.

    timeout corto (2s) a proposito, distinto del resto del cliente: esto lo llama router.show_downloads() en un
    bucle de sondeo cada 1,5s mientras la pantalla esta abierta."""
    code, data = _call("downloads", "/alfa/download/status", {}, timeout=2)
    return data.get("jobs", []) if code == 200 else []


def download_status(job_id):
    """Estado de UN trabajo conocido - None si el mini PC no responde o el trabajo ya no existe. Mismo timeout
    corto que download_jobs(), mismo motivo."""
    code, data = _call("downloads", "/alfa/download/status", {"job": job_id}, timeout=2)
    return data if code == 200 else None


# Puerto de invidious-download (mismo mini PC, ver plugin.video.invidious/resources/lib/invidious.py,
# DOWNLOAD_JOB_PORT) - consultado desde AQUI (no solo desde el propio addon de Invidious) para fusionar sus
# trabajos en el mismo panel "Descargas" del boton de Inicio.
INVIDIOUS_DOWNLOAD_PORT = 3002


def invidious_jobs():
    """Lista de trabajos de invidious-download (mismo formato que devuelve /status.json) - lista vacia si el mini
    PC no responde, nunca lanza. Mismo timeout corto de 2s que download_jobs()."""
    code, data = _call("invidious", "/status.json", {}, timeout=2)
    return data.get("jobs", []) if code == 200 else []


def download_cancel(job_id):
    """Pide PAUSAR un trabajo de descarga en curso (boton Y de gui.DownloadsOverlay, cuando esta activo) -
    conserva lo que ya se hubiera hecho para poder retomarlo despues, no lo borra. Mismo criterio de timeout
    corto que download_jobs() - esto tambien puede llamarse desde ese mismo bucle de sondeo."""
    _call("downloads", "/alfa/download/cancel", {"job": job_id}, timeout=3)


def download_resume(job_id):
    """Pide retomar una descarga pausada (boton Y de gui.DownloadsOverlay, cuando esta pausada)."""
    _call("downloads", "/alfa/download/resume", {"job": job_id}, timeout=3)


def download_discard(job_id):
    """Descarta del todo una descarga pausada (borra lo que quedara en el mini PC)."""
    _call("downloads", "/alfa/download/discard", {"job": job_id}, timeout=3)


def torrent_status(token):
    code, data = _call("core", "/alfa/torrent/status", {"t": token})
    if code != 200:
        return {"state": "error", "error": data.get("error") or "el torrent ya no existe en el mini PC"}
    return data


def torrent_cancel(token):
    _call("core", "/alfa/torrent/cancel", {"t": token})


def image_url(url, width):
    """Caratula/fondo reducidos por alfa-img (la Xbox no descarga bien los "original" de TMDB)."""
    return "http://{}:{}/alfa/img.jpg?{}".format(_host(), IMG_PORT, urllib.urlencode({"u": url, "w": width}))


def stream_url(token, start=0, alang=None):
    params = {"t": token}
    if start:
        params["ss"] = "{:.1f}".format(start)
    if alang:
        params["alang"] = alang          # spa | eng | orig: pista de audio que suena al empezar (el bridge las pasa todas)
    return "http://{}:{}/alfa/stream?{}".format(_host(), CORE_PORT, urllib.urlencode(params))


def describe_problem(data):
    """Texto para mostrar al usuario cuando Alfa no devolvio nada util:
    primero lo que Alfa mismo dijo (notificaciones/dialogos que en Kodi
    saldrian en pantalla), y si no, el error tecnico."""
    parts = []
    for n in data.get("notifications") or []:
        if len(n) > 1 and n[1]:
            parts.append(n[1])
    for d in data.get("dialogs") or []:
        parts.extend(x for x in d[1:] if x and len(x) > 3)
    if data.get("error"):
        parts.append(data["error"])
    seen, out = set(), []
    for p in parts:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out[:3]
