# -*- coding: utf-8 -*-
import time

import xbmc
import gui

from . import bridge
from . import updater

# Entradas de la raiz de Alfa que no tienen sentido desde la Xbox (abren
# dialogos de ajustes, la videoteca de Kodi, gestor de descargas...):
# fuera del alcance del bridge, que solo navega canales y reproduce.
# Xbox-Luzbel (13/10/2026): "Favoritos" anadido a peticion del usuario - es el acceso directo de Alfa
# a "Mis enlaces" desde la raiz, redundante con la opcion "Mis enlaces" ya disponible al reproducir
# cualquier item (ver _play_impl()).
_UTILITY_LABEL_PREFIXES = ("Videoteca", "Descargas", "Ajustes", "Reportar", "Ayuda", "Favoritos")
_UTILITY_ACTIONS = ("settings", "opciones", "configuracion")
_SEARCH_ACTIONS = ("new_search", "search")
_CONTENT_TYPES = ("movies", "tvshows", "episodes", "seasons")
# Anchos a los que el bridge reduce las imagenes: cabe de sobra en la textura de una vista de carteles y se descarga rapido.
_POSTER_WIDTH = 200
_FANART_WIDTH = 640


def _show_problem(data, fallback):
    lines = bridge.describe_problem(data) or [fallback]
    gui.ok("AlfaXbox", *lines)


def _is_hidden(item, at_root):
    if not item["folder"] and not item["playable"]:
        return True  # texto informativo de Alfa, no se puede abrir
    if item.get("action") == "save_download":
        # La propia entrada "-Descargar Pelicula/Serie-" de Alfa: en el bridge no hace nada de verdad (encola en un
        # proceso que termina al momento, ver alfa_bridge.py) - siempre oculta, tenga o no el usuario activado
        # "Ocultar entradas", porque ahora la descarga real se ofrece al reproducir (dialogo "Ver"/"Descargar").
        return True
    if gui.addon.getSetting("hide_utility") != "false":
        if item.get("action") in _UTILITY_ACTIONS:
            return True
        if at_root and item["label"].startswith(_UTILITY_LABEL_PREFIXES):
            return True
    return False


def browse(url_params):
    q = url_params.get("q", "")
    text = None
    if url_params.get("ask"):
        text = gui.get_input("Buscar")
        if not text:
            gui.end_listing()
            return

    data = bridge.list_items(q, text)
    items = data.get("items") or []
    if not items:
        _show_problem(data, "Alfa no devolvio ningun resultado.")
        gui.end_listing()
        return

    if not q:
        _update_entry()
        gui.add_item("Restaurar copia de seguridad de Alfa...", "folder.png", url_params={"route": "alfarestore"})
    # Ajuste "show_posters": el antiguo "show_thumbs" (por defecto false en la 0.1.0) quedo guardado en la consola y pisaba el
    # nuevo valor por defecto, asi que las caratulas no salian; con otro nombre vale el defecto (true).
    show_thumbs = gui.addon.getSetting("show_posters") != "false"
    show_fanart = gui.addon.getSetting("show_fanart") == "true"
    if data.get("content") in _CONTENT_TYPES:
        gui.set_content(data["content"])
    for it in items:
        if _is_hidden(it, at_root=not q):
            continue
        art = _art(it, show_thumbs, show_fanart)
        info = _info(it)
        if it["playable"]:
            # Xbox-Luzbel (09/10/2026, #151): "poster" va tambien en la URL de reproduccion (no solo en el
            # ListItem) para que, si el usuario elige "Descargar" en vez de "Ver", _start_download() pueda
            # pasarselo al mini PC y la ventana de Descargas tenga algo que ensenar a la derecha - solo
            # decorativo, sin el la ventana funciona exactamente igual que antes.
            play_params = {"route": "play", "q": it["q"], "name": _display_name(it, info)}
            if art.get("poster"):
                play_params["poster"] = art["poster"]
            # Xbox-Luzbel (10/10/2026, #151): titulo LIMPIO (sin la etiqueta decorativa de
            # calidad/formato que _display_name() añade), a peticion del usuario - para la ventana de
            # Descargas, no para el dialogo "Ver"/"Descargar" (ese SI necesita la etiqueta para
            # distinguir entre enlaces de la misma pelicula, ver _display_name()). info["title"] ya es
            # el titulo real cuando existe (puesto por _info() desde it["info"]["title"]); si no,
            # it["label"] es lo unico que hay.
            play_params["title"] = info.get("title") or it["label"]
            # Xbox-Luzbel (12/10/2026, "Mis enlaces"): channel/item_action del propio it - necesarios solo
            # si el usuario elige "Anadir a Alfavoritos" en el dialogo de _play_impl() (ver
            # bridge.add_favourite()), no para reproducir/descargar.
            play_params["channel"] = it.get("channel", "")
            play_params["item_action"] = it.get("action", "")
            gui.add_item(
                it["label"], "play.png", art=art,
                url_params=play_params,
                video_infotag=info, is_folder=False,
            )
        else:
            params = {"route": "browse", "q": it["q"]}
            icon = "folder.png"
            if it["action"] in _SEARCH_ACTIONS:
                params["ask"] = "1"
                icon = "search.png"
            gui.add_item(it["label"], icon, art=art, url_params=params, video_infotag=info)
    # El menu principal no se cachea: XBMC guarda la lista en cache y al volver a entrar no ejecutaba el addon, asi que
    # el aviso de actualizacion seguia saliendo (con la version vieja) aunque ya se hubiera actualizado.
    gui.end_listing(cache=bool(q))


def _update_entry():
    """Linea amarilla informativa al principio del menu principal: solo si hay version nueva (o esta es demasiado vieja)."""
    try:
        info = updater.check()
    except Exception as e:  # noqa: BLE001 - el aviso nunca debe romper el menu
        xbmc.log("plugin.video.alfaxbox: no se pudo comprobar la version: {}".format(e), xbmc.LOGWARNING)
        return
    if not info:
        return
    updater.announce(info)
    text = updater.label(info)
    if text:
        gui.add_item(text, "folder.png", url_params={"route": "updateinfo"})
    toast, warn = updater.alfa_status(info)
    pending = updater.alfa_pending(info)
    offered = updater.offer_alfa_upgrade(info)           # primera vez de la sesion: changelog + confirmacion
    if not offered:
        updater.announce_alfa(toast)
    if warn:
        gui.add_item("[COLOR yellow]{}[/COLOR]".format(warn[:110]), "folder.png", url_params={"route": "info", "msg": warn})
    line = updater.pending_line(info)
    if line:
        route = {"route": "alfaupgrade"} if pending.get("ready") else {"route": "info", "msg": line}
        gui.add_item("[COLOR yellow]{}[/COLOR]".format(line[:110]), "folder.png", url_params=route)


def show_info(url_params):
    """Linea amarilla informativa: al pulsarla se muestra el texto completo, nada mas."""
    gui.ok("AlfaXbox", url_params.get("msg", ""))
    gui.end_listing()


def alfa_upgrade(url_params):
    """Linea amarilla de "version nueva de Alfa": vuelve a mostrar los cambios y pregunta si instalar."""
    info = updater.check()
    if info:
        updater.offer_alfa_upgrade(info, force=True)
    gui.end_listing()


def alfa_restore(url_params):
    """Entrada del menu raiz: lista las copias de seguridad de Alfa del mini PC y ofrece restaurar una."""
    updater.offer_alfa_restore()
    gui.end_listing()


def update_info(url_params):
    """La linea amarilla solo informa: al pulsarla se explica donde se actualiza, nada mas."""
    updater.how_to()
    gui.end_listing()


def _is_local_bridge_url(url):
    """Xbox-Luzbel (14/10/2026): los iconos de categoria de Alfa (Novedades/Peliculas/Terror/... -
    ver /alfa/theme-icon en alfa_core.py) ya vienen del propio mini PC, con el tamano justo (256x256
    o menos) - no hay que pasarlos por bridge.image_url()/alfa-img como las caratulas de verdad
    (TMDB). Si se hiciera, alfa-img los rechazaria siempre: image_cache.py tiene un guardia
    anti-SSRF a proposito (_allowed(), "este servicio no debe servir de puente a la red local") que
    descarta cualquier URL apuntando a una IP privada - exactamente lo que es la del mini PC."""
    return "/alfa/theme-icon" in (url or "")


def _art(it, show_thumbs, show_fanart):
    """Caratula y fondo, ya reducidos por el bridge a un tamano que la Xbox pueda con (ver image_cache.py) -
    salvo los iconos de categoria propios de Alfa, que van sin pasar por ahi (ver _is_local_bridge_url)."""
    art = {}
    images = it.get("art") or {}
    poster = images.get("poster") or images.get("thumb")
    if show_thumbs and poster:
        art["thumb"] = art["poster"] = poster if _is_local_bridge_url(poster) else bridge.image_url(poster, _POSTER_WIDTH)
    if show_fanart and images.get("fanart"):
        fanart = images["fanart"]
        art["fanart"] = fanart if _is_local_bridge_url(fanart) else bridge.image_url(fanart, _FANART_WIDTH)
    return art


def _display_name(it, info):
    """Nombre para el dialogo "Ver"/"Descargar", "Descargas en curso" y los avisos de progreso - distinto del
    "label" de la fila en la lista (ver gui.add_item mas abajo, ese no cambia). En el nivel mas hondo de Alfa (la
    lista de enlaces de UNA pelicula concreta) el "label" de cada item es solo una etiqueta decorativa de
    calidad/formato (p.ej. "[?] [Torrent] [DVDrip] ['CAST'] [2,0 GB]"), nunca el nombre de la pelicula - Alfa no
    lo repite ahi porque el contexto ya esta claro al navegar. Bug reportado por el usuario (23/09/2026): sin
    esto, ni el dialogo ni "Descargas en curso" mostraban nunca el nombre real."""
    title = info.get("title")
    label = it["label"]
    if title and title != label:
        return "{} - {}".format(title, label)
    return label


def _info(it):
    """Etiquetas de video (resumen, ano, genero, nota...) con los tipos que espera XBMC."""
    info = {"title": it["label"]}
    if it.get("plot"):
        info["plot"] = it["plot"]
    for key, value in (it.get("info") or {}).items():
        try:
            if key in ("year", "season", "episode", "votes"):
                info[key] = int(value)
            elif key == "rating":
                info[key] = float(value)
            else:
                info[key] = value
        except (TypeError, ValueError):
            pass
    return info


def play(url_params):
    """Mismo envoltorio que plugin.video.invidious/tdtxbox: si _play_impl()
    no resuelve nada, hay que decirselo explicitamente a Kodi o el
    dialogo de "cargando" se queda girando para siempre."""
    resolved = False
    try:
        resolved = _play_impl(url_params)
    finally:
        if not resolved:
            gui.cancel_resolve()


def _play_impl(url_params):
    q = url_params.get("q")
    if not q:
        xbmc.log("plugin.video.alfaxbox play: called without q", xbmc.LOGWARNING)
        return False

    name = url_params.get("name") or "AlfaXbox"
    title = url_params.get("title") or name
    poster = url_params.get("poster") or ""
    channel = url_params.get("channel") or ""
    item_action = url_params.get("item_action") or ""

    # Mismo patron ("Ver"/"Descargar" al pulsar, no un menu contextual aparte) que ya usa plugin.video.invidious.
    # Con un torrent, "Descargar" baja el archivo COMPLETO (no solo el buffer inicial que usa la reproduccion en
    # directo, ver torrent_jobs.py) - tarda mas, pero el bridge ya lo soporta igual que un enlace de hoster.
    #
    # Kodi abre su propio "busydialog" en cuanto arranca este script (OnPlayMedia/route=play) y lo deja abierto
    # esperando setResolvedUrl(). Confirmado por log en produccion (22/09/2026, ver NOTAS-PENDIENTE-2026-09-21.md
    # §14): abrir OTRO dialogo modal (este select) mientras ese busydialog sigue activo no llega a pintarse en
    # pantalla en esta build - GetSelectedItem() devuelve su valor por defecto (0, "Ver") sin que el usuario pueda
    # elegir nada. Cerrarlo primero (builtin idempotente, no falla si ya estaba cerrado) es el arreglo estandar en
    # addons de Kodi para diálogos interactivos abiertos dentro del propio resolve.
    #
    # Xbox-Luzbel (13/10/2026, "Mis enlaces"): el resolve() (bridge.resolve(), puede tardar - habla con
    # la web/hoster de verdad) se mueve AHORA detras de este dialogo y solo se llama para "Ver": ni
    # "Descargar" (ya resolvia el solo con el "q", nunca necesito el resultado de resolve()) ni "Mis
    # enlaces" (solo guarda el enlace, no hace falta comprobar que el video cargue) lo necesitan - antes
    # se resolvia siempre, incluso si el usuario iba a elegir Descargar.
    #
    # Xbox-Luzbel (13/10/2026): "Anadir a Favoritos" (la Favoritos NATIVA de Kodi) se quita de aqui a
    # peticion del usuario - el boton White del mando YA guarda el item en esa misma lista via el menu
    # contextual nativo (CONTEXT_BUTTON_ADD_FAVOURITE, GUIMediaWindow.cpp), asi que esta opcion aqui
    # solo duplicaba un camino que ya existe. "Anadir a Alfavoritos" se renombra a "Mis enlaces" (el
    # nombre real de esa lista dentro de Alfa, "Alfavoritos" no significaba nada para el usuario). El
    # builtin C++ AlfaXbox.AddFavourite y gui.add_native_favourite() se quedan sin llamar desde aqui -
    # ver el comentario en gui.py.
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    choice = gui.select(name, ["Ver", "Descargar", "Mis enlaces"])
    if choice < 0:
        return False      # Atras/Escape: no elegido nada, no reproducir por defecto
    if choice == 1:
        _start_download(q, name, poster, title)
        return False
    if choice == 2:
        _add_favourite(q, channel, item_action, name)
        return False

    data = bridge.resolve(q)
    token = data.get("token")
    if not token:
        xbmc.log("plugin.video.alfaxbox play: no se pudo resolver '{}': {}".format(name, data), xbmc.LOGWARNING)
        _show_problem(data, "No se pudo obtener el video de este enlace (la web o el servidor de video pueden haber cambiado o estar caidos).")
        return False

    is_torrent = bool(data.get("torrent"))

    # Si el video se corto hace poco, el bridge recuerda por 5 minutos donde iba (ver alfa_bridge.py, "resume")
    start = 0
    resume = data.get("resume")
    if resume and gui.yesno(
        "AlfaXbox",
        "La reproduccion se corto en {}.".format(_clock(resume["position"])),
        "Continuar desde ahi (disponible {} min mas)?".format(max(1, resume["seconds_left"] // 60)),
        "", "Desde el principio", "Continuar",
    ):
        start = resume["position"]

    if is_torrent and not _wait_torrent(token, name):
        return False

    alang = {"Espanol": "spa", "English": "eng", "Original": "orig"}.get(gui.addon.getSetting("audio_lang"), "spa")
    url = bridge.stream_url(token, start, alang)
    xbmc.log("plugin.video.alfaxbox play: {} -> {}".format(name, url), xbmc.LOGNOTICE)
    gui.play(url, title=name)
    return True


def _start_download(q, name, poster="", title=None):
    # Xbox-Luzbel (10/10/2026, #151): "name" (la descripcion completa, con etiqueta de
    # calidad/formato) sigue siendo el nombre de archivo - util conservar esos datos ahi. "title" (el
    # titulo limpio, sin esa etiqueta) es lo que se muestra en la ventana de Descargas - a peticion
    # del usuario, que no queria ver el enlace/etiqueta del torrent mezclado con el titulo.
    folder = gui.addon.getSetting("download_folder") or "F:\\Videos"
    job_id, data = bridge.start_download(q, folder, filename=name, title=title or name, poster=poster)
    if not job_id:
        xbmc.log("plugin.video.alfaxbox download: no se pudo iniciar '{}': {}".format(name, data), xbmc.LOGWARNING)
        _show_problem(data, "No se pudo iniciar la descarga (el mini PC puede estar apagado o no responde).")
        return
    # Xbox-Luzbel (27/09/2026, NOTAS-PENDIENTE-2026-09-21.md #54): el panel "Descargas" (antes
    # gui.DownloadsOverlay + _watch_downloads(), aqui mismo) se porto a C++ - ver xbmc/utils/AlfaDownloads.cpp.
    # Mismo motivo que Insignia/weather.openmeteo (#44/#48): abrirlo justo despues de usar OTRO addon de Python
    # (p.ej. Invidious) desaloja su interprete y revienta la consola - portarlo quita a Python de en medio del
    # todo para este camino, se abra desde aqui o desde el boton "Descargas" de Inicio. Mismo motivo que
    # gui.select() en _play_impl(): esto corre dentro del propio callback de resolucion de Kodi (route=play),
    # que deja su propio "busydialog" automatico abierto de fondo - cerrarlo antes evita que quede sin pintarse.
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    xbmc.executebuiltin("AlfaXbox.ShowDownloads")


def _pick_favourite_folder():
    """Dialogo "Guardar enlace en:" - mismo orden de opciones que el select interno de Alfa
    (modules/alfavorites.py _selecciona_perfil(): carpetas existentes + "Crear nueva carpeta..." al
    final), para que el indice elegido aqui sirva tal cual como "choice" en bridge.add_favourite().
    Devuelve (indice, nombre_nueva_carpeta_o_None), o (None, None) si el usuario cancela en cualquier
    paso. "Gestionar listas de enlaces" (el ultimo item de ese menu, para cambiar de fichero de
    alfavoritos) se descarta aqui - no pinta nada en un guardado rapido."""
    data = bridge.list_items("module=alfavorites&action=mainlist")
    items = data.get("items") or []
    choices = [it["label"] for it in items if it["label"] != "Gestionar listas de enlaces"]
    if not choices:
        xbmc.log("plugin.video.alfaxbox favourite: no se pudo consultar Mis enlaces: {}".format(data), xbmc.LOGWARNING)
        _show_problem(data, "No se pudo consultar Mis enlaces (el mini PC puede estar apagado o no responde).")
        return None, None

    idx = gui.select("Guardar enlace en:", choices)
    if idx < 0:
        return None, None
    if choices[idx].startswith("Crear nueva carpeta"):
        new_name = gui.get_input("Nombre de la nueva carpeta")
        if not new_name:
            return None, None
        return idx, new_name
    return idx, None


def _add_favourite(q, channel, item_action, name):
    idx, new_folder_name = _pick_favourite_folder()
    if idx is None:
        return
    data = bridge.add_favourite(q, channel, item_action, idx, new_folder_name)
    notifications = data.get("notifications") or []
    if notifications:
        heading, message = notifications[-1]
        gui.notification(heading, message)
    else:
        xbmc.log("plugin.video.alfaxbox favourite: no se pudo guardar '{}': {}".format(name, data), xbmc.LOGWARNING)
        gui.notification("AlfaXbox", data.get("error") or "No se pudo guardar el enlace.")


# Torrest tarda en encontrar pares y llenar el buffer inicial; el bridge se rinde antes (90 s metadatos, 240 s
# buffer), este tope solo evita esperar para siempre si el bridge dejara de responder.
_TORRENT_WAIT_SECONDS = 360


def _clock(seconds):
    seconds = int(seconds)
    if seconds >= 3600:
        return "{}:{:02d}:{:02d}".format(seconds // 3600, seconds // 60 % 60, seconds % 60)
    return "{}:{:02d}".format(seconds // 60, seconds % 60)


def _size(n):
    return "{:.1f} MB".format(n / 1048576.0)


# Xbox-Luzbel (27/09/2026, #54): _DOWNLOAD_STATE_LABELS/_normalize_*_job/_all_jobs/_pick_download_job/
# _download_lines/_watch_downloads/show_downloads se retiraron de aqui - el panel "Descargas" (fetch +
# normalizado + botones Y/Blanco) se porto a C++ del todo, ver xbmc/utils/AlfaDownloads.cpp.


def _wait_torrent(token, name):
    """El bridge prepara el torrent en segundo plano (Torrest en el mini PC); aqui se muestra el progreso, como
    hace el addon Torrest en Kodi. True cuando esta listo para reproducir."""
    dialog = gui.progress_dialog("AlfaXbox", "Conectando con Torrest...", name)
    deadline = time.time() + _TORRENT_WAIT_SECONDS
    try:
        while True:
            st = bridge.torrent_status(token)
            state = st.get("state")
            if state == "ready":
                return True
            if state in ("error", "cancelled"):
                gui.ok("AlfaXbox", st.get("error") or "No se pudo preparar el torrent.")
                return False
            if state == "metadata":
                line1 = "Buscando pares y metadatos del torrent..."
            else:
                line1 = "Descargando el buffer inicial: {:.0f}%".format(st.get("progress", 0))
            line2 = "Semillas: {}   Pares: {}   Velocidad: {}/s".format(st.get("seeders", 0), st.get("peers", 0), _size(st.get("rate", 0)))
            line3 = "{} ({})".format(st["name"], _size(st["size"])) if st.get("name") else name
            dialog.update(int(st.get("progress", 0)), line1, line2, line3)
            if dialog.iscanceled():
                bridge.torrent_cancel(token)
                return False
            if time.time() > deadline:
                bridge.torrent_cancel(token)
                gui.ok("AlfaXbox", "El torrent tarda demasiado en estar listo.")
                return False
            xbmc.sleep(1500)
    finally:
        dialog.close()
