import os
import sys
import urllib
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

# Con <reuselanguageinvoker> el motor podria dejar este modulo importado entre invocaciones
# distintas del addon (handle de Kodi distinto en cada una) - por eso antes esto se leia de sys.argv
# en cada llamada en vez de una vez al importar. Comprobado en produccion (26/09/2026) que en este
# motor NO es asi: cada invocacion reimporta el modulo de cero (sys.modules no lo mantiene vivo
# entre invocaciones), asi que leerlo aqui, a nivel de modulo, es seguro - mismo patron que ya usan
# plugin.video.tdtxbox/invidious. Ademas, hacerlo ANTES de instanciar Addon() evita un
# EXCEPTION_BREAKPOINT real confirmado por bisecion: combinar una llamada de red bloqueante con
# xbmcaddon.Addon()+xbmcgui en el mismo invoker crashea la consola minutos despues, en el cierre de
# un interprete completamente ajeno; con este orden (igual que tdtxbox/invidious) no reproduce.
ADDON_HANDLE = int(sys.argv[1])
ADDON_VFS_PATH = sys.argv[0]

addon = xbmcaddon.Addon()


def set_content(content):
    """movies/tvshows/episodes...: activa las vistas con caratula e informacion de la skin."""
    xbmcplugin.setContent(ADDON_HANDLE, content)


def add_item(title, icon=None, thumb=None, url_params=None, video_infotag=None, is_folder=True, art=None):
    item = xbmcgui.ListItem(title)

    images = {}
    if icon:
        images["icon"] = os.path.join(addon.getAddonInfo("path"), "resources", "media", icon)
    if thumb:
        images["thumb"] = thumb
    if art:
        images.update(art)
    item.setArt(images)
    if images.get("fanart"):
        item.setProperty("fanart_image", images["fanart"])      # skins antiguas leen esta propiedad

    url = "{}?{}".format(ADDON_VFS_PATH, urllib.urlencode(url_params))

    if video_infotag is not None:
        item.setInfo("video", video_infotag)
    if not is_folder:
        item.setProperty("IsPlayable", "True")

    return xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, item, is_folder, 0)


def end_listing(succeeded=True, cache=True):
    return xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded, False, cache)


def cancel_resolve():
    """Sin esto, si play() decide no reproducir nada, el dialogo de "cargando"
    de la consola se queda girando para siempre (mismo motivo que en
    plugin.video.invidious / plugin.video.tdtxbox)."""
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())


def play(url, title=None):
    item = xbmcgui.ListItem(title, path=url)
    if title:
        item.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, item)


def notification(heading, message, time=5000):
    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_INFO, time)


def ok(heading, *lines):
    xbmcgui.Dialog().ok(heading, *lines)


def progress_dialog(heading, line1="", line2="", line3=""):
    dialog = xbmcgui.DialogProgress()
    dialog.create(heading, line1, line2, line3)
    return dialog


def yesno(heading, line1="", line2="", line3="", nolabel="", yeslabel=""):
    return xbmcgui.Dialog().yesno(heading, line1, line2, line3, nolabel, yeslabel)


def select(heading, options):
    """Indice elegido, o -1 si el usuario cancela (Atras/Escape) sin elegir nada."""
    return xbmcgui.Dialog().select(heading, options)


def textviewer(heading, text):
    """Visor de texto de XBMC (para el changelog); si esta compilacion no lo tuviera, un dialogo con las primeras lineas."""
    try:
        xbmcgui.Dialog().textviewer(heading, text)
    except Exception:
        lines = [l for l in text.splitlines() if l.strip()][:3]
        xbmcgui.Dialog().ok(heading, *lines)


def get_input(heading, default_text=""):
    keyboard = xbmc.Keyboard(default_text, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    return None
