# -*- coding: utf-8 -*-
"""
service.invidious.lcd
======================

invidious-remux genera los MP4 con "empty_moov" (necesario para poder
empezar a reproducir al instante, sin esperar a tener el vídeo entero),
y eso significa que el fichero nunca lleva la duración total en la
cabecera - confirmado a mano leyendo el campo duration del mvhd, sigue
siendo 0 aunque se le diga a ffmpeg la duración por adelantado con -t.
Por eso Player.Duration y LCD.ProgressBar (ambos dependen exactamente
de lo mismo en el núcleo: g_application.GetTotalTime(), que a su vez
solo sabe lo que el demuxer detecta del propio fichero) se quedan en
blanco para estos streams.

La duración real SÍ la sabemos, por la propia API de Invidious - solo
que por una vía completamente distinta al fichero. router.py escribe
esa duración conocida en una propiedad de ventana global justo antes
de reproducir; este servicio, en segundo plano, la usa para calcular
tiempo restante y progreso él mismo, y los publica como propiedades
propias para que LCD.xml las lea en vez de las que no funcionan.

Para cualquier otro vídeo (que sí lleva duración real en el fichero)
esto no cambia nada - getTotalTime() ya devuelve algo válido, así que
simplemente se usa ese valor tal cual, sin tocar la propiedad de
Invidious para nada.
"""
import xbmc
import xbmcgui

WINDOW = xbmcgui.Window(10000)

PROP_KNOWN_LENGTH = "InvidiousLength"  # escrita por router.py
PROP_TIME_LINE = "InvidiousTimeLine"
PROP_PROGRESS_BAR = "InvidiousProgressBar"
PROP_PROGRESS_PCT = "InvidiousProgressPct"

# Un segundo es de sobra para un dato de texto en una LCD - no hace
# falta más precisión, y así se minimiza el trabajo en un hardware
# tan limitado como esta Xbox.
POLL_INTERVAL_SECONDS = 1.0

# 18 caracteres de relleno + 2 de corchetes = 20.
BAR_WIDTH = 18


def format_elapsed(seconds):
    # Siempre H:MM:SS, incluso por debajo de una hora ("0:00:37") - a
    # propósito, para que el ancho del texto no cambie según avanza la
    # reproducción y así no se desplace en la LCD al cruzar la hora.
    seconds = int(max(0, seconds))
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return "{}:{:02d}:{:02d}".format(hours, minutes, seconds)


def format_remaining(seconds):
    seconds = int(max(0, seconds))
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return "- {}:{:02d}:{:02d}".format(hours, minutes, seconds)


def build_bar(fraction):
    fraction = max(0.0, min(1.0, fraction))
    filled = int(round(fraction * BAR_WIDTH))
    return "[" + ("#" * filled) + ("-" * (BAR_WIDTH - filled)) + "]"


class LCDPlayerMonitor(xbmc.Player):
    def clear_properties(self):
        WINDOW.clearProperty(PROP_TIME_LINE)
        WINDOW.clearProperty(PROP_PROGRESS_BAR)
        WINDOW.clearProperty(PROP_PROGRESS_PCT)

    def onPlayBackStopped(self):
        self.clear_properties()

    def onPlayBackEnded(self):
        self.clear_properties()


def tick(player):
    if not player.isPlayingVideo():
        return

    try:
        elapsed = player.getTime()
        known = WINDOW.getProperty(PROP_KNOWN_LENGTH)
        if known:
            # Prioridad a la duración real (de la API de Invidious)
            # sobre la que reporte el reproductor: confirmado que para
            # streams empty_moov getTotalTime() no siempre da un 0
            # limpio, a veces da un valor pequeño/parcial mientras el
            # demuxer todavía está analizando fragmentos - eso rompía
            # el cálculo por completo (progreso al 100% desde el
            # segundo uno). Si hay una duración conocida puesta por
            # router.py, se usa siempre esa en vez de fiarse del
            # reproductor.
            total = float(known)
        else:
            total = player.getTotalTime()
    except Exception:
        # isPlayingVideo() pudo cambiar justo entre esa comprobación
        # y estas llamadas (la reproducción paró a mitad) - no pasa
        # nada, simplemente se salta este tick.
        return

    if total <= 0:
        return

    fraction = elapsed / total

    # Se construye la línea entera aquí, con el espacio ya puesto a
    # mano, en vez de dejar que LCD.xml junte dos $INFO[] con un
    # espacio suelto en el XML - así el espaciado no depende de cómo
    # lo maneje el analizador de plantillas LCD.
    time_line = "{} {}".format(format_elapsed(elapsed), format_remaining(total - elapsed))

    WINDOW.setProperty(PROP_TIME_LINE, time_line)
    WINDOW.setProperty(PROP_PROGRESS_BAR, build_bar(fraction))
    WINDOW.setProperty(PROP_PROGRESS_PCT, "{}%".format(int(fraction * 100)))


def main():
    player = LCDPlayerMonitor()
    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        tick(player)
        if monitor.waitForAbort(POLL_INTERVAL_SECONDS):
            break

    player.clear_properties()
    WINDOW.clearProperty(PROP_KNOWN_LENGTH)


if __name__ == "__main__":
    main()
