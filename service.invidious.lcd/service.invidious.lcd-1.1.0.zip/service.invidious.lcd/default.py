# -*- coding: utf-8 -*-
"""
service.invidious.lcd
======================

invidious-remux genera los MP4 con "empty_moov" (necesario para poder
empezar a reproducir al instante, sin esperar a tener el vídeo entero),
y eso significa que el fichero nunca lleva la duración total en la
cabecera - confirmado a mano leyendo el campo duration del mvhd, sigue
siendo 0 aunque se le diga a ffmpeg la duración por adelantado con -t.
Por eso Player.Duration y LCD.ProgressBar (ambos dependen exactamente
de lo mismo en el núcleo: g_application.GetTotalTime(), que a su vez
solo sabe lo que el demuxer detecta del propio fichero) se quedan en
blanco para estos streams.

La duración real SÍ la sabemos, por la propia API de Invidious - solo
que por una vía completamente distinta al fichero. router.py escribe
esa duración conocida en una propiedad de ventana global justo antes
de reproducir; este servicio, en segundo plano, la usa para calcular
tiempo restante y progreso él mismo, y los publica como propiedades
propias para que LCD.xml las lea en vez de las que no funcionan.

Para cualquier otro vídeo (que sí lleva duración real en el fichero)
esto no cambia nada - getTotalTime() ya devuelve algo válido, así que
simplemente se usa ese valor tal cual, sin tocar la propiedad de
Invidious para nada.
"""
import json
import time

import xbmc
import xbmcgui

try:  # Python 2 (la Xbox)
    from urlparse import urlparse, parse_qs
    from urllib2 import urlopen
except ImportError:  # por si algun dia se prueba fuera de la consola
    from urllib.parse import urlparse, parse_qs
    from urllib.request import urlopen

WINDOW = xbmcgui.Window(10000)

PROP_KNOWN_LENGTH = "InvidiousLength"  # escrita por router.py
PROP_TIME_LINE = "InvidiousTimeLine"
PROP_PROGRESS_BAR = "InvidiousProgressBar"
PROP_PROGRESS_PCT = "InvidiousProgressPct"

# Streams de AlfaXbox: el bridge del mini PC (alfa-bridge) recodifica al vuelo a un mp4 fragmentado que tampoco lleva duración
# (mismo problema que invidious-remux), así que se le pregunta la duración real del vídeo, que sondea de su fichero de origen.
ALFA_STREAM_PATH = "/alfa/stream"
ALFA_QUERY_TIMEOUT_SECONDS = 3
ALFA_RETRY_SECONDS = 3
ALFA_GIVE_UP_SECONDS = 180
_alfa = {"token": None, "total": None, "next_try": 0.0, "give_up": 0.0}

# Un segundo es de sobra para un dato de texto en una LCD - no hace
# falta más precisión, y así se minimiza el trabajo en un hardware
# tan limitado como esta Xbox.
POLL_INTERVAL_SECONDS = 1.0

# 18 caracteres de relleno + 2 de corchetes = 20.
BAR_WIDTH = 18


def format_elapsed(seconds):
    # Siempre H:MM:SS, incluso por debajo de una hora ("0:00:37") - a
    # propósito, para que el ancho del texto no cambie según avanza la
    # reproducción y así no se desplace en la LCD al cruzar la hora.
    seconds = int(max(0, seconds))
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return "{}:{:02d}:{:02d}".format(hours, minutes, seconds)


def format_remaining(seconds):
    seconds = int(max(0, seconds))
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return "- {}:{:02d}:{:02d}".format(hours, minutes, seconds)


def build_bar(fraction):
    fraction = max(0.0, min(1.0, fraction))
    filled = int(round(fraction * BAR_WIDTH))
    return "[" + ("#" * filled) + ("-" * (BAR_WIDTH - filled)) + "]"


def alfa_stream_info(player):
    """(url_base, token, desplazamiento) si lo que suena es un stream de alfa-bridge; si no, None.

    El desplazamiento es el "ss" de la URL: al reanudar tras un corte el stream arranca en ese segundo del vídeo, y el
    reproductor cuenta desde 0 - el tiempo real transcurrido es ss + getTime()."""
    try:
        playing = player.getPlayingFile()
    except Exception:
        return None
    parsed = urlparse(playing)
    if parsed.path.rstrip("/") != ALFA_STREAM_PATH:
        return None
    query = parse_qs(parsed.query)
    token = (query.get("t") or [""])[0]
    if not token:
        return None
    try:
        offset = max(0.0, float((query.get("ss") or ["0"])[0]))
    except ValueError:
        offset = 0.0
    return "{}://{}".format(parsed.scheme, parsed.netloc), token, offset


def alfa_total(base, token):
    """Duración real (segundos) del vídeo que sirve alfa-bridge, o None mientras no se sepa.

    El bridge la lee de la cabecera del origen al abrir el stream, así que los primeros segundos aún no está: se
    reintenta cada ALFA_RETRY_SECONDS hasta ALFA_GIVE_UP_SECONDS. Una vez conocida se recuerda (no se vuelve a preguntar)."""
    now = time.time()
    if _alfa["token"] != token:
        _alfa.update(token=token, total=None, next_try=0.0, give_up=now + ALFA_GIVE_UP_SECONDS)
    if _alfa["total"] is not None or now < _alfa["next_try"] or now > _alfa["give_up"]:
        return _alfa["total"]
    _alfa["next_try"] = now + ALFA_RETRY_SECONDS
    try:
        answer = json.loads(urlopen("{}/alfa/duration?t={}".format(base, token), timeout=ALFA_QUERY_TIMEOUT_SECONDS).read())
    except Exception:
        return None
    if answer.get("duration"):
        _alfa["total"] = float(answer["duration"])
    elif answer.get("probed"):
        _alfa["give_up"] = 0.0  # el contenedor no declara duración: no tiene sentido seguir preguntando
    return _alfa["total"]


class LCDPlayerMonitor(xbmc.Player):
    def clear_properties(self):
        WINDOW.clearProperty(PROP_TIME_LINE)
        WINDOW.clearProperty(PROP_PROGRESS_BAR)
        WINDOW.clearProperty(PROP_PROGRESS_PCT)

    def onPlayBackStopped(self):
        self.clear_properties()

    def onPlayBackEnded(self):
        self.clear_properties()


def tick(player):
    if not player.isPlayingVideo():
        return

    try:
        elapsed = player.getTime()
        alfa = alfa_stream_info(player)
        known = WINDOW.getProperty(PROP_KNOWN_LENGTH)
        if alfa:
            # AlfaXbox: la duración sale del bridge, nunca de InvidiousLength (que puede ser de un vídeo anterior).
            base, token, offset = alfa
            elapsed += offset
            total = alfa_total(base, token)
            if total is None:
                # Aún sin duración (los primeros segundos, o el origen no la declara): al menos el tiempo transcurrido.
                WINDOW.setProperty(PROP_TIME_LINE, format_elapsed(elapsed))
                WINDOW.clearProperty(PROP_PROGRESS_BAR)
                WINDOW.clearProperty(PROP_PROGRESS_PCT)
                return
        elif known:
            # Prioridad a la duración real (de la API de Invidious)
            # sobre la que reporte el reproductor: confirmado que para
            # streams empty_moov getTotalTime() no siempre da un 0
            # limpio, a veces da un valor pequeño/parcial mientras el
            # demuxer todavía está analizando fragmentos - eso rompía
            # el cálculo por completo (progreso al 100% desde el
            # segundo uno). Si hay una duración conocida puesta por
            # router.py, se usa siempre esa en vez de fiarse del
            # reproductor.
            total = float(known)
        else:
            total = player.getTotalTime()
    except Exception:
        # isPlayingVideo() pudo cambiar justo entre esa comprobación
        # y estas llamadas (la reproducción paró a mitad) - no pasa
        # nada, simplemente se salta este tick.
        return

    if total <= 0:
        return

    fraction = elapsed / total

    # Se construye la línea entera aquí, con el espacio ya puesto a
    # mano, en vez de dejar que LCD.xml junte dos $INFO[] con un
    # espacio suelto en el XML - así el espaciado no depende de cómo
    # lo maneje el analizador de plantillas LCD.
    time_line = "{} {}".format(format_elapsed(elapsed), format_remaining(total - elapsed))

    WINDOW.setProperty(PROP_TIME_LINE, time_line)
    WINDOW.setProperty(PROP_PROGRESS_BAR, build_bar(fraction))
    WINDOW.setProperty(PROP_PROGRESS_PCT, "{}%".format(int(fraction * 100)))


def main():
    player = LCDPlayerMonitor()
    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        tick(player)
        if monitor.waitForAbort(POLL_INTERVAL_SECONDS):
            break

    player.clear_properties()
    WINDOW.clearProperty(PROP_KNOWN_LENGTH)


if __name__ == "__main__":
    main()
