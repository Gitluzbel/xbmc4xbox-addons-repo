# -*- coding: utf-8 -*-
''' 
	XBL Cloud Sync
	Script by Rocky5

	Original concept:
		https://github.com/OGXBL/XBLCloudGameSave

	Requires latest XBMC4Gamers or my XBMC4Xbox 3.6 version.
	The script uses stuff not in older version of XBMC4Xbox or XBMC4Gamers.
'''
from limpp import RGBA_data, BGR_to_BMP
from os import makedirs, listdir, remove, rename, stat, utime, walk
from os.path import basename, dirname, isdir, isfile, getsize, join, relpath
from qrcode import QRCode, ERROR_CORRECT_L
from xbmc import sleep, executebuiltin, getCondVisibility, getInfoLabel, getLocalizedString
from xbmcaddon import Addon
from xbmcgui import DialogProgress, Dialog, Window
from urllib2 import Request, urlopen
from urllib import quote
from ssl import create_default_context, CERT_NONE
from base64 import b64encode
from socket import create_connection
import savesigner, simpleini, sys, zipfile, json, traceback, gc, inspect

WINDOW = Window(10020)
GETPROPERTY = WINDOW.getProperty

ADDON_ID = 'XBL Cloud Sync'
ADDON = Addon(ADDON_ID)
ROOT_DIR = ADDON.getAddonInfo('path')

ZIP_CHUNK_SIZE = 32 * 1024
UPLOAD_HOST = 'xb.live'
AUTH_HOST = 'auth.insigniastats.live'
OUTPUT_DIR = 'E:\\CACHE\\XBL Cloud Sync'
SESSION_PATH = join(OUTPUT_DIR, 'insignia_session.txt')
REPORT_PATH = join(OUTPUT_DIR, '{} Report.txt'.format(ADDON_ID))

QR_PATH = join(ROOT_DIR, 'qrcode.bmp')
BG_ZIP_PATH = join(ROOT_DIR, 'resources', 'qr_background.zip')
QR_X = 565
QR_Y = 197
QR_SIZE = 190
URL_X = 205
URL_Y = 222
URL_HEIGHT = 17
BG_WIDTH = 960
BG_HEIGHT = 540
FONT_W = 5
FONT_H = 7
FONT_GAP = 1

EEPROMBIN = 'Q:\\system\\SystemInfo\\EEPROMBackup.bin'
SYSINFO_PATH = 'Q:\\system\\SystemInfo\\EEPROMBackup.cfg'
CERBIOS_INI = 'E:\\Cerbios\\cerbios.ini'
UDATA_PART_MAP = {1: 'E', 6: 'F', 7: 'G'}
SIGNERS_CACHE = None

LOCAL_RESIGN_SAVES = False
if ADDON.getSetting('local_sign').strip().lower() == 'true':
	LOCAL_RESIGN_SAVES = True

SSL_CONTEXT = create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = CERT_NONE


# Utilities / helpers
## UDATA / Cerbios
def get_udata_path():
	if isfile(CERBIOS_INI):
		try:
			ini = simpleini.load(CERBIOS_INI)
			section = '' if simpleini.get(ini, '', 'tudataredir') is not None else 'CERBIOS CONFIG EDITOR'
			redir = simpleini.get(ini, section, 'tudataredir', 'false').strip().lower()
			if redir == 'true':
				part = simpleini.get(ini, section, 'tudataredirpart', '1').strip()
				drive = UDATA_PART_MAP.get(int(part), 'E')
				return '{}:\\UDATA'.format(drive)
		except Exception as error:
			print '[{}] get_udata_path failed: {}'.format(ADDON_ID, error)
	return 'E:\\UDATA'


UDATA_PATH = get_udata_path()


## Logging / formatting
def log(message):
	try:
		if isinstance(message, unicode):
			message = message.encode('ascii', errors = 'replace').decode('ascii')
		print '[{}] {}'.format(ADDON_ID, message)
	except Exception:
		pass


def safe(text):
	try:
		if isinstance(text, unicode):
			return text.encode('ascii', 'replace')
		return str(text)
	except Exception:
		return ''


## Progress / notifications
class ProgressDialog(object):
	def __init__(self, title):
		self.dialog = DialogProgress()
		self.dialog.create(title, '', 'Initializing...', '')

	def update(self, percent = 0, line1 = '', line2 = '', line3 = ''):
		log('{}% {} {} {}'.format(percent, safe(line1), safe(line2), safe(line3)))
		try:
			self.dialog.update(int(percent), safe(line1), safe(line2), safe(line3))
		except Exception:
			pass

	def is_canceled(self):
		try:
			return self.dialog.iscanceled()
		except Exception:
			return False

	def close(self):
		try:
			self.dialog.close()
		except Exception:
			pass


def notify(message):
	try:
		executebuiltin('Notification({}, {}, 3000, {}\\icon.png)'.format(ADDON_ID, message.encode('utf-8', errors = 'replace'), ROOT_DIR))
	except Exception:
		pass


## File / path
def create_dir(path):
	try:
		if not isdir(path):
			makedirs(path)
	except Exception as error:
		log('create_dir failed: {}'.format(error))


# Networking
## HTTP
def http_request(method, host, path, headers = None, body = None):
	try:
		request = Request('https://' + host + path, data = body)
		request.get_method = lambda: method
		for header_name, header_value in (headers or {}).items():
			request.add_header(header_name, header_value)
		response = urlopen(request, context = SSL_CONTEXT, timeout = 60)
		return response.getcode(), response.read()
	except Exception as error:
		log('{} {}: {}'.format(method, path, error))
		return 0, b''


def upload_file_streamed(host, path, session_key, extra_headers, file_path):
	try:
		file_size = getsize(file_path)
	except Exception:
		return 0, b''
	try:
		sock = SSL_CONTEXT.wrap_socket(create_connection((host, 443), timeout = 120), server_hostname = host)
		header_lines = [
			'POST {} HTTP/1.1'.format(path),
			'Host: {}'.format(host),
			'Content-Type: application/octet-stream',
			'Content-Length: {}'.format(file_size),
			'X-Session-Key: {}'.format(session_key),
			'Connection: close',
		]
		for header_name, header_value in (extra_headers or {}).items():
			if header_name not in ('Content-Type', 'X-Session-Key'):
				header_lines.append('{}: {}'.format(header_name, header_value))
		header_lines += ['', '']
		sock.sendall('\r\n'.join(header_lines).encode('utf-8'))
		with open(file_path, 'rb') as file_handle:
			while True:
				chunk = file_handle.read(ZIP_CHUNK_SIZE)
				if not chunk:
					break
				sock.sendall(chunk)
		response_data = b''
		while True:
			try:
				part = sock.recv(4096)
				if not part:
					break
				response_data += part
			except Exception:
				break
		sock.close()
		if not response_data:
			return 0, b''
		status_parts = response_data.split(b'\r\n', 1)[0].decode('utf-8', errors = 'replace').split(' ', 2)
		status_code = int(status_parts[1]) if len(status_parts) >= 2 and status_parts[1].isdigit() else 0
		header_end = response_data.find(b'\r\n\r\n')
		return status_code, response_data[header_end + 4:] if header_end != -1 else b''
	except Exception as error:
		log('upload_file_streamed: {}'.format(error))
		return 0, b''


## JSON
def json_parse(data):
	if not data:
		return {}
	try:
		return json.loads(data.decode('utf-8', errors = 'replace') if isinstance(data, bytes) else data)
	except Exception:
		return {}


def json_get(data, key, default = ''):
	return data.get(key, default) if isinstance(data, dict) else default


## Session
def load_session():
	try:
		lines = [line.rstrip('\r\n') for line in open(SESSION_PATH).readlines()]
		if len(lines) >= 2 and lines[0]:
			log('session loaded for {}'.format(lines[1]))
			return lines[0], lines[1], lines[2] if len(lines) >= 3 else ''
		log('session file empty or incomplete')
	except Exception as error:
		log('load_session: {}'.format(error))
	return '', '', ''


def save_session(session_key, username, console_id = ''):
	create_dir(OUTPUT_DIR)
	try:
		with open(SESSION_PATH, 'w') as file_handle:
			file_handle.write(session_key + '\n' + username + '\n')
			if console_id:
				file_handle.write(console_id + '\n')
		log('session saved for {}'.format(username))
	except Exception as error:
		log('save_session failed: {}'.format(error))


def clear_session():
	try:
		remove(SESSION_PATH)
	except Exception:
		pass


BMPFONT = {
	'&': [0,1,1,0,0,1,0,0,1,0,1,0,1,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,0,1,0,1,1,0,1],
	'_': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1],
	'!': [0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0],
	'.': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0],
	'/': [0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,0],
	'-': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	'?': [0,1,1,1,0,1,0,0,0,1,0,0,0,0,1,0,0,1,1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0],
	'=': [0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0],
	':': [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],
	'0': [0,1,1,1,0,1,0,0,1,1,1,0,0,1,1,1,0,1,1,1,1,0,1,1,1,1,0,0,1,1,0,1,1,1,0],
	'1': [0,0,1,0,0,0,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,1,1,1,0],
	'2': [0,1,1,1,0,1,0,0,0,1,0,0,0,0,1,0,0,1,1,0,0,1,0,0,0,1,0,0,0,0,1,1,1,1,1],
	'3': [1,1,1,1,0,0,0,0,0,1,0,0,0,1,0,0,0,1,1,0,0,0,0,0,1,1,0,0,0,1,1,1,1,1,0],
	'4': [0,0,0,1,0,0,0,1,1,0,0,1,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,0,1,0,0,0,0,1,0],
	'5': [1,1,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,1,0,1,1,1,0],
	'6': [0,0,1,1,0,0,1,0,0,0,1,0,0,0,0,1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,0,1,1,1,0],
	'7': [1,1,1,1,1,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0],
	'8': [0,1,1,1,0,1,0,0,0,1,1,0,0,0,1,0,1,1,1,0,1,0,0,0,1,1,0,0,0,1,0,1,1,1,0],
	'9': [0,1,1,1,0,1,0,0,0,1,1,0,0,0,1,0,1,1,1,1,0,0,0,0,1,0,0,0,1,0,0,1,1,0,0],
	'a': [0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,1,0,1,1,0,1,1,0,0,1,1,0,1,1,0,1],
	'b': [1,0,0,0,0,1,0,0,0,0,1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,1,1,1,0],
	'c': [0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,1,1,1,0],
	'd': [0,0,0,0,1,0,0,0,0,1,0,1,1,0,1,1,0,0,1,1,1,0,0,0,1,1,0,0,0,1,0,1,1,1,1],
	'e': [0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,0,0,0,1,1,1,1,1,0,1,0,0,0,0,0,0,1,1,1],
	'f': [0,0,1,1,0,0,1,0,0,0,0,1,0,0,0,1,1,1,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0],
	'g': [0,0,0,0,0,0,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,1,1,1,1,0,0,0,0,1,0,1,1,1,0],
	'h': [1,0,0,0,0,1,0,0,0,0,1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1],
	'i': [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0],
	'j': [0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,1,0,0,1,0,0,1,1,0,0],
	'k': [1,0,0,0,0,1,0,0,1,0,1,0,1,0,0,1,1,0,0,0,1,0,1,0,0,1,0,0,1,0,1,0,0,0,1],
	'l': [0,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1,0],
	'm': [0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,1,0,1,0,1,1,0,1,0,1,1,0,1,0,1,1,0,0,0,1],
	'n': [0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1],
	'o': [0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,0,1,1,1,0],
	'p': [0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,1,1,1,0,1,0,0,0,0],
	'q': [0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,1,1,1,1,0,0,0,0,1],
	'r': [0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,1,1,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0],
	's': [0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,0,0,0,0,0,1,1,1,0,0,0,0,0,1,0,1,1,1,0],
	't': [0,1,0,0,0,0,1,0,0,0,1,1,1,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,1,1,0],
	'u': [0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,0,1,1,1,1],
	'v': [0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0],
	'w': [0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,1,1,0,1,0,1,1,0,1,0,1,1,0,0,0,1],
	'x': [0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0,0,1,0,1,0,1,0,0,0,1],
	'y': [0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,1,0,1,1,1,1,0,0,0,0,1,0,1,1,1,0],
	'z': [0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,1,1,1,1],
	'A': [0,0,1,0,0,0,1,0,1,0,1,0,0,0,1,1,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,0,0,0,1],
	'B': [1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,1,1,1,0],
	'C': [0,1,1,1,0,1,0,0,0,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,1,0,1,1,1,0],
	'D': [1,1,1,0,0,1,0,0,1,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,1,0,1,1,1,0,0],
	'E': [1,1,1,1,1,1,0,0,0,0,1,0,0,0,0,1,1,1,1,0,1,0,0,0,0,1,0,0,0,0,1,1,1,1,1],
	'F': [1,1,1,1,1,1,0,0,0,0,1,0,0,0,0,1,1,1,1,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0],
	'G': [0,1,1,1,0,1,0,0,0,1,1,0,0,0,0,1,0,1,1,1,1,0,0,0,1,1,0,0,0,1,0,1,1,1,1],
	'H': [1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1],
	'I': [1,1,1,1,1,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,1,1,1,1,1],
	'J': [0,0,1,1,1,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,1,0,0,1,0,1,0,0,1,0,0,1,1,0,0],
	'K': [1,0,0,0,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,0,1,0,1,0,0,1,0,0,1,0,1,0,0,0,1],
	'L': [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1,1,1,1],
	'M': [1,0,0,0,1,1,1,0,1,1,1,0,1,0,1,1,0,1,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1],
	'N': [1,0,0,0,1,1,1,0,0,1,1,0,1,0,1,1,0,0,1,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1],
	'O': [0,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,0,1,1,1,0],
	'P': [1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,1,1,1,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0],
	'Q': [0,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,1,0,1,1,0,0,1,0,0,1,1,0,1],
	'R': [1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,1,1,1,1,0,1,0,1,0,0,1,0,0,1,0,1,0,0,0,1],
	'S': [0,1,1,1,0,1,0,0,0,1,1,0,0,0,0,0,1,1,1,0,0,0,0,0,1,1,0,0,0,1,0,1,1,1,0],
	'T': [1,1,1,1,1,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0],
	'U': [1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,0,1,1,1,0],
	'V': [1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0],
	'W': [1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,0,1,0,1,1,0,1,0,1,1,1,0,1,1,1,0,0,0,1],
	'X': [1,0,0,0,1,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0,0,1,0,1,0,1,0,0,0,1,1,0,0,0,1],
	'Y': [1,0,0,0,1,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0],
	'Z': [1,1,1,1,1,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1,1,1,1,1],
}


def draw_text_on_bmp(bg_data, text, x, y, bg_width, bg_height, color = (0, 0, 0), scale_x = 1, scale_y = 1):
	bpp = 3
	pad = (4 - (bg_width * bpp) % 4) % 4
	row_stride = bg_width * bpp + pad
	pixel_offset = 54
	cx = x
	for char in text.lower():
		glyph = BMPFONT.get(char) or BMPFONT.get(char.upper())
		if glyph is None:
			cx += (FONT_W + FONT_GAP) * scale_x
			continue
		for gy in range(FONT_H):
			for gx in range(FONT_W):
				if glyph[gy * FONT_W + gx]:
					for sy in range(scale_y):
						for sx in range(scale_x):
							bx = cx + gx * scale_x + sx
							by = y + gy * scale_y + sy
							if bx >= bg_width or by >= bg_height:
								continue
							file_row = bg_height - 1 - by
							offset = pixel_offset + file_row * row_stride + bx * bpp
							bg_data[offset] = color[2]
							bg_data[offset + 1] = color[1]
							bg_data[offset + 2] = color[0]
		cx += (FONT_W + FONT_GAP) * scale_x


def write_qr_bmp(url, path, border = 4):
	try:
		qr = QRCode(version = 1, error_correction = ERROR_CORRECT_L, box_size = 1, border = border)
		qr.add_data(url)
		qr.make(fit = True)
		matrix = qr.get_matrix()
	except Exception as error:
		log('qr generate: {}'.format(error))
		return False
	try:
		module_count = len(matrix)
		cell_size = QR_SIZE // module_count
		actual_size = module_count * cell_size
		bg_data = None
		if isfile(BG_ZIP_PATH):
			try:
				with zipfile.ZipFile(BG_ZIP_PATH, 'r') as zfh:
					bg_data = bytearray(zfh.read('qr_background.bmp'))
			except Exception as error:
				log('qr bg load: {}'.format(error))
		if bg_data:
			bpp = 3
			pad = (4 - (BG_WIDTH * bpp) % 4) % 4
			row_stride = BG_WIDTH * bpp + pad
			pixel_offset = 54
			for qr_row in range(actual_size):
				for qr_col in range(actual_size):
					is_dark = matrix[qr_row // cell_size][qr_col // cell_size]
					bg_x = QR_X + qr_col
					bg_y = QR_Y + qr_row
					if bg_x >= BG_WIDTH or bg_y >= BG_HEIGHT:
						continue
					file_row = BG_HEIGHT - 1 - bg_y
					offset = pixel_offset + file_row * row_stride + bg_x * bpp
					bg_data[offset] = 0 if is_dark else 255
					bg_data[offset + 1] = 0 if is_dark else 255
					bg_data[offset + 2] = 0 if is_dark else 255
			url_parts = url.split('?', 1)
			draw_text_on_bmp(bg_data, url_parts[0], URL_X, URL_Y, BG_WIDTH, BG_HEIGHT, color = (255, 255, 255))
			if len(url_parts) > 1:
				draw_text_on_bmp(bg_data, '?' + url_parts[1], URL_X, URL_Y + URL_HEIGHT - 7, BG_WIDTH, BG_HEIGHT, color = (255, 255, 255))
			with open(path, 'wb') as fh:
				fh.write(bytes(bg_data))
		else:
			image_size = actual_size
			pixel_data = ''
			for row_index in range(image_size):
				matrix_row = row_index // cell_size
				for col_index in range(image_size):
					matrix_col = col_index // cell_size
					if matrix[matrix_row][matrix_col]:
						pixel_data += chr(0) + chr(0) + chr(0) + chr(255)
					else:
						pixel_data += chr(255) + chr(255) + chr(255) + chr(255)
			rgba = RGBA_data(image_size, image_size, pixel_data)
			BGR_to_BMP(rgba, path, '24')
		log('qr written: {}'.format(path))
		return True
	except Exception as error:
		log('qr write: {}'.format(error))
		return False


def verify_session(session_key):
	if not session_key:
		return False, ''
	status, body = http_request(
		'GET',
		AUTH_HOST,
		'/api/auth/user',
		headers = {'X-Session-Key': session_key}
	)
	if status // 100 != 2:
		return False, ''
	username = json_get(json_parse(body), 'username')
	return bool(username), username


def truncate_fatx(name):
	return name[:32]


def device_login(dialog_login):
	status, body = http_request(
		'POST',
		AUTH_HOST,
		'/api/auth/device',
		headers = {'Content-Type': 'application/json'},
		body = b'{}'
	)
	if status // 100 != 2:
		dialog_login.update(8, 'Sign in failed', 'Auth server unreachable')
		dialog_login.close()
		return '', ''

	response_data = json_parse(body)
	device_code = json_get(response_data, 'device_code')
	user_code = json_get(response_data, 'user_code')
	verify_url = json_get(response_data, 'verification_uri_complete') or 'http://{}/device-link.html?user_code={}'.format(AUTH_HOST, user_code)
	poll_interval = max(int(json_get(response_data, 'interval') or 5), 1)

	if not device_code or not user_code:
		dialog_login.update(8, 'Sign in failed', 'Bad response from auth server')
		dialog_login.close()
		return '', ''

	write_qr_bmp(verify_url, QR_PATH)
	dialog_login.close()
	executebuiltin('ShowPicture({})'.format(QR_PATH))

	while not getCondVisibility('Window.IsActive(2007)'):
		sleep(500)

	token_body = '{{"grant_type":"urn:ietf:params:oauth:grant-type:device_code","device_code":"{}"}}'.format(device_code).encode('utf-8')
	session_key = username = ''
	poll_attempt = 0
	while True:
		if not getCondVisibility('Window.IsActive(2007)'):
			break
		poll_attempt += 1
		if poll_attempt > 20:
			break
		elapsed = 0
		while elapsed < poll_interval * 1000:
			sleep(100)
			elapsed += 100
			if not getCondVisibility('Window.IsActive(2007)'):
				break
		poll_status, poll_body = http_request(
			'POST',
			AUTH_HOST,
			'/api/auth/device/token',
			headers = {'Content-Type': 'application/json'},
			body = token_body
		)
		poll_data = json_parse(poll_body)
		error = json_get(poll_data, 'error')
		if error == 'authorization_pending':
			continue
		if error == 'slow_down':
			poll_interval += 5
			continue
		if error:
			log('sign in error: {}'.format(error))
			if 'expired' in error:
				break
			continue
		session_key = json_get(poll_data, 'sessionKey')
		username = json_get(poll_data, 'username')
		if session_key:
			break

	executebuiltin('Window.Close(2007)')
	sleep(500)
	try:
		remove(QR_PATH)
	except Exception:
		pass
	return session_key, username


## Scanning / fingerprinting
def scan_udata(scan_path):
	titles = []
	try:
		for title_id in listdir(scan_path):
			title_path = join(scan_path, title_id)
			if not isdir(title_path):
				continue
			title_name = title_id
			meta_path = join(title_path, 'TitleMeta.xbx')
			if isfile(meta_path):
				try:
					raw = open(meta_path, 'rb').read()
					text = raw.decode('utf-16-le', errors = 'replace')[1:] if raw[:2] == b'\xff\xfe' else raw.decode('utf-8', errors = 'replace')
					for meta_line in text.splitlines():
						meta_line = meta_line.strip()
						if meta_line.startswith('TitleName='):
							title_name = meta_line[10:].strip()
							break
				except Exception:
					pass
			saves = []
			for save_folder in listdir(title_path):
				save_path = join(title_path, save_folder)
				if not isdir(save_path):
					continue
				total_size = file_count = latest_mtime = 0
				for root, dirs, files in walk(save_path):
					for filename in files:
						try:
							file_stat = stat(join(root, filename))
							total_size += file_stat.st_size
							file_count += 1
							if file_stat.st_mtime > latest_mtime:
								latest_mtime = file_stat.st_mtime
						except Exception:
							pass
				saves.append({'folder': save_folder, 'size': total_size, 'count': file_count, 'mtime': latest_mtime})
			titles.append({'titleId': title_id, 'titleName': title_name, 'path': title_path, 'saves': saves})
	except Exception as error:
		log('scan_udata: {}'.format(error))
	return titles


def fingerprint_title(title):
	hash_value = 14695981039346656037
	hash_mask = (1 << 64) - 1
	total_size = sum(save['size'] for save in title['saves'])
	total_count = sum(save['count'] for save in title['saves'])
	latest_mtime = max(save['mtime'] for save in title['saves']) if title['saves'] else 0
	for byte in '{}|{}|{}|{}'.format(title['titleId'], total_size, total_count, int(latest_mtime)).encode('utf-8'):
		hash_value ^= (byte if isinstance(byte, int) else ord(byte))
		hash_value = (hash_value * 1099511628211) & hash_mask
	return '{:016x}'.format(hash_value)


## File / path
def zip_directory(src_path, dest_path):
	try:
		with zipfile.ZipFile(dest_path, 'w', zipfile.ZIP_STORED) as zip_file:
			for root, dirs, files in walk(src_path):
				for filename in files:
					full_path = join(root, filename)
					archive_name = relpath(full_path, src_path)
					try:
						with open(full_path, 'rb') as file_handle:
							file_data = bytearray()
							while True:
								chunk = file_handle.read(ZIP_CHUNK_SIZE)
								if not chunk:
									break
								file_data.extend(chunk)
						zip_file.writestr(archive_name, bytes(file_data))
						del file_data
					except Exception as error:
						log('zip skip {}: {}'.format(archive_name, error))
		return True
	except Exception as error:
		log('zip: {}'.format(error))
		return False


def unzip_to_dir(src_path, dest_path):
	try:
		create_dir(dest_path)
		with zipfile.ZipFile(src_path, 'r') as zip_file:
			for entry_name in zip_file.namelist():
				out_path = join(dest_path, entry_name)
				if entry_name.endswith('/'):
					create_dir(out_path)
					continue
				create_dir(dirname(out_path))
				with zip_file.open(entry_name) as zip_entry:
					with open(out_path, 'wb') as file_handle:
						while True:
							chunk = zip_entry.read(ZIP_CHUNK_SIZE)
							if not chunk:
								break
							file_handle.write(chunk)
		return True
	except Exception as error:
		log('unzip: {}'.format(error))
		return False


## API
def upload_console_data(session_key, serial, hdd_key_hex):
	eeprom_b64 = ''
	if isfile(EEPROMBIN):
		try:
			eeprom_b64 = b64encode(open(EEPROMBIN, 'rb').read()).decode('ascii')
		except Exception as error:
			log('eeprom read: {}'.format(error))
	payload = json.dumps({
		'sessionKey': session_key,
		'serial': serial or '',
		'hdd_key_hex': hdd_key_hex or '',
		'eeprom_base64': eeprom_b64,
		'console_id_scheme': 'v2',
	})
	status, body = http_request(
		'POST',
		UPLOAD_HOST,
		'/api/me/xbox-saves/console-data',
		headers = {'Content-Type': 'application/json', 'X-Session-Key': session_key},
		body = payload.encode('utf-8')
	)
	if status // 100 == 2:
		data = json_parse(body)
		return json_get(data, 'console_id') or json_get(data, 'consoleId')
	return ''


def fetch_manifest(session_key):
	status, body = http_request(
		'GET',
		UPLOAD_HOST,
		'/api/me/xbox-saves/manifest',
		headers = {'X-Session-Key': session_key}
	)
	if status // 100 == 2:
		return body.decode('utf-8', errors = 'replace') if isinstance(body, bytes) else body
	return ''


def manifest_matches(manifest, console_id, profile, title_id, fingerprint):
	if profile:
		return '{}:{}:{}={}'.format(console_id, profile, title_id, fingerprint) in manifest
	needle = ':{}={}'.format(title_id, fingerprint)
	for line in manifest.splitlines():
		if line.startswith(console_id + ':') and needle in line:
			return True
	return False


def manifest_get_any_mtime(manifest, title_id):
	best = 0
	for line in manifest.splitlines():
		if '=' not in line or '|nosync' in line:
			continue
		manifest_key, manifest_val = line.split('=', 1)
		if not manifest_key.endswith(':' + title_id):
			continue
		parts = manifest_val.split('|')
		try:
			mtime = int(parts[1]) if len(parts) > 1 and parts[1].strip().isdigit() else 0
			if mtime > best:
				best = mtime
		except Exception:
			pass
	return best


def manifest_get_content_hash(manifest, title_id):
	for line in manifest.splitlines():
		if '=' not in line:
			continue
		manifest_key, manifest_val = line.split('=', 1)
		if not manifest_key.endswith(':' + title_id):
			continue
		parts = manifest_val.split('|')
		if len(parts) >= 3 and parts[2] and parts[2] not in ('nosync',):
			return parts[2].strip()
	return ''


def upload_save(session_key, console_id, hdd_key_hex, serial, profile, profile_label, title_id, title_name, save_count, total_bytes, fingerprint, save_modified, dukex_path):
	api_path = ('/api/me/xbox-saves/game?title_id={}&console_id={}&hdd_key_hex={}&serial={}&profile={}&save_count={}&total_bytes={}&fingerprint={}&save_modified={}&console_id_scheme=v2'.format(
		quote(title_id or ''),
		quote(console_id or 'unknown'),
		quote(hdd_key_hex or ''),
		quote(serial or ''),
		quote(profile or ''),
		save_count, total_bytes,
		quote(fingerprint or ''),
		int(save_modified))
	)
	request_headers = {'X-Title-Name-B64': b64encode((title_name or '').encode('utf-8')).decode('ascii')}
	if profile_label:
		request_headers['X-Profile-Label-B64'] = b64encode(profile_label.encode('utf-8')).decode('ascii')
	status, _ = upload_file_streamed(UPLOAD_HOST, api_path, session_key, request_headers, dukex_path)
	return status // 100 == 2


def download_save(session_key, source_console, target_console, source_profile, title_id, dest_path):
	api_path = '/api/me/xbox-saves/download/{}?console_id={}&target_console_id={}&profile={}'.format(
		title_id,
		source_console or '',
		target_console or '',
		source_profile or ''
	)
	try:
		request = Request('https://' + UPLOAD_HOST + api_path)
		request.add_header('X-Session-Key', session_key)
		response = urlopen(request, context = SSL_CONTEXT, timeout = 60)
		status_code = response.getcode()
		if status_code in (422, 500):
			log('download_save: server resign error {} for {}'.format(status_code, title_id))
			return False
		if status_code // 100 != 2:
			return False

		# removed when working
		print "Session key: {}".format(session_key)
		print "Source console ID: {}".format(source_console)
		print "Current console ID: {}".format(target_console)
		print "Source Profile: {}".format(source_profile)
		print "TitleID: {}".format(title_id)
		print "Destination: {}".format(dest_path)
		print "API: {}".format(api_path)
		resigned = response.headers.get('X-Xbox-Save-Resigned', '0')
		log('download_save: resigned header = {}'.format(resigned))

		with open(dest_path, 'wb') as file_handle:
			while True:
				chunk = response.read(ZIP_CHUNK_SIZE)
				if not chunk:
					break
				file_handle.write(chunk)
		return True
	except Exception as error:
		log('download_save: {}'.format(error))
		return False


## Save resigning
def get_signers():
	global SIGNERS_CACHE
	if SIGNERS_CACHE is None:
		try:
			SIGNERS_CACHE = savesigner.load_signers()
			log('get_signers: loaded {} signer(s)'.format(len(SIGNERS_CACHE)))
		except Exception as error:
			log('get_signers: failed: {}'.format(error))
			SIGNERS_CACHE = {}
	return SIGNERS_CACHE


def resign_saves(title_id_str, title_path, hdd_key_hex, src_mac_hex = None, dst_mac_hex = None, src_hdd_hex = None):
	ok, msg = savesigner.resign_title(
		title_id_str,
		title_path,
		hdd_key_hex,
		get_signers(),
		src_mac_hex = src_mac_hex,
		dst_mac_hex = dst_mac_hex,
		src_hdd_hex = src_hdd_hex
	)
	if not ok:
		log('resign_saves: {}'.format(msg))


## EEPROM helpers
def fetch_console_eeprom(session_key, console_id, dest_path):
	try:
		request = Request('https://{}/api/me/xbox-saves/eeprom?console_id={}'.format(UPLOAD_HOST, console_id))
		request.add_header('X-Session-Key', session_key)
		response = urlopen(request, context = SSL_CONTEXT, timeout = 60)
		status_code = response.getcode()
		if status_code // 100 != 2:
			return False
		with open(dest_path, 'wb') as file_handle:
			while True:
				chunk = response.read(ZIP_CHUNK_SIZE)
				if not chunk:
					break
				file_handle.write(chunk)
		return True
	except Exception as error:
		log('fetch_console_eeprom: {}'.format(error))
		return False


def fetch_console_hdd_key(session_key, console_id):
	status, body = http_request(
		'POST',
		UPLOAD_HOST,
		'/api/me/xbox-saves/reveal-hdd-key',
		headers = {'Content-Type': 'application/json', 'X-Session-Key': session_key},
		body = json.dumps({'console_id': console_id}).encode('utf-8')
	)
	if status // 100 == 2:
		data = json_parse(body)
		return json_get(data, 'hdd_key', '').replace(':', '').replace('-', '').replace(' ', '').upper()
	return ''


def read_mac_from_eeprom(eeprom_path):
	return savesigner.read_eeprom_bin_mac(eeprom_path)


## Profiles
def individual_saves_enabled():
	try:
		content = open(join('Q:\\system\\UserData', 'udata_settings.xml')).read()
		if 'individual_saves' not in content:
			return False
		return '"true"' in content or "'true'" in content
	except Exception:
		return False


## Reporting & convert bytes to readable values
def format_size(size):
	if size >= 1048576:
		return '{:.1f} MB'.format(size / 1048576.0)
	if size >= 1024:
		return '{:.1f} KB'.format(size / 1024.0)
	return '{} B'.format(size)


def write_report(titles):
	try:
		create_dir(OUTPUT_DIR)
		sorted_titles = sorted(titles, key = lambda t: safe(t['titleName']).lower())
		with open(REPORT_PATH, 'wb') as fh:
			total_size = sum(sum(save['size'] for save in title['saves']) for title in sorted_titles)
			total_saves = sum(len(title['saves']) for title in sorted_titles)
			fh.write('{} - Save Report\n'.format(ADDON_ID).encode('utf-8'))
			fh.write('{}\n'.format('=' * 60).encode('utf-8'))
			fh.write('{} titles  |  {} save slots  |  {}\n\n'.format(len(sorted_titles), total_saves, format_size(total_size)).encode('utf-8'))
			for title in sorted_titles:
				name = safe(title['titleName'])
				size = sum(save['size'] for save in title['saves'])
				slots = len(title['saves'])
				fh.write('{:<12}  {}\n'.format(title['titleId'], name).encode('utf-8', errors = 'replace'))
				fh.write('{:<12}  {} slot{}  {}\n\n'.format('', slots, 's' if slots != 1 else ' ', format_size(size)).encode('utf-8', errors = 'replace'))
	except Exception as error:
		log('write_report: {}'.format(error))


## Args
def parse_args():
	force_mode = smart_mode = signin_mode = restore_mode = restore_missing_mode = False
	for arg in sys.argv[1:]:
		arg_lower = arg.lower()
		if arg_lower == 'force':
			force_mode = True
		elif arg_lower == 'smart':
			smart_mode = True
		elif arg_lower == 'signin':
			signin_mode = True
		elif arg_lower == 'restore':
			restore_mode = True
		elif arg_lower == 'restoremissing':
			restore_missing_mode = True
	return force_mode, smart_mode, signin_mode, restore_mode, restore_missing_mode


# Console info
def parse_sysinfo(console_id = ''):
	info = {'serial': '', 'hdd_key': '', 'online_key': '', 'xboxmac': ''}
	paths = []
	if console_id:
		paths.append(join(OUTPUT_DIR, '{}_info.ini'.format(console_id)))
	paths.append(SYSINFO_PATH)
	for path in paths:
		if not isfile(path):
			continue
		try:
			for line in open(path).readlines():
				line = line.strip()
				if line.startswith('#') or '=' not in line:
					continue
				key, value = line.split('=', 1)
				key = key.strip()
				value = value.strip().strip('"')
				if key == 'XBOXSerial':
					info['serial'] = value
				elif key == 'HDDKey':
					info['hdd_key'] = value
				elif key == 'OnlineKey':
					info['online_key'] = value
				elif key == 'XBOXMAC':
					info['xboxmac'] = value
			if info['serial'] or info['hdd_key']:
				break
		except Exception:
			pass
	return info


def backup_and_read_sysinfo():
	if isfile(SYSINFO_PATH):
		remove(SYSINFO_PATH)
	if isfile(EEPROMBIN):
		remove(EEPROMBIN)
	executebuiltin('BackupSystemInfo')
	while True:
		if isfile(SYSINFO_PATH):
			try:
				if stat(SYSINFO_PATH).st_size > 0:
					break
			except Exception:
				pass
		sleep(100)
	return parse_sysinfo()


def save_sysinfo(console_id):
	if not console_id or not isfile(SYSINFO_PATH):
		return
	try:
		dest = join(OUTPUT_DIR, '{}_info.ini'.format(console_id))
		with open(SYSINFO_PATH, 'r') as src_file:
			with open(dest, 'w') as dst_file:
				dst_file.write(src_file.read())
		log('sysinfo saved to {}'.format(dest))
	except Exception as error:
		log('save_sysinfo: {}'.format(error))


# Functions (signin, sync etc...)
def signin():
	create_dir(OUTPUT_DIR)
	session_key, username, console_id = load_session()
	if session_key:
		session_valid, verified_username = verify_session(session_key)
		if session_valid:
			notify('Already signed in as {}'.format(verified_username))
			return

	dialog_signin = ProgressDialog(ADDON_ID)
	dialog_signin.update(5, 'Signing in...', 'QRcode will automatically close when you link your account.')
	session_key, username = device_login(dialog_signin)
	if session_key:
		dialog_signin.update(50, 'Reading hardware info...')
		info = backup_and_read_sysinfo()
		serial = info['serial']
		hdd_key_hex = info['hdd_key'].replace(':', '')
		dialog_signin.update(80, 'Registering console...')
		new_console_id = upload_console_data(session_key, serial, hdd_key_hex)
		if new_console_id:
			console_id = new_console_id
			save_sysinfo(console_id)
		save_session(session_key, username, console_id)
		notify('Signed in as {}'.format(username))
	dialog_signin.close()


def sync(force_mode, smart_mode):
	log('starting (force = {} smart = {})'.format(force_mode, smart_mode))
	create_dir(OUTPUT_DIR)
	canceled = False

	dialog_prepare = ProgressDialog('XBL Cloud - Preparing')
	dialog_prepare.update(5, 'Checking session...')
	session_key, username, console_id = load_session()
	logged_in = False

	if session_key:
		dialog_prepare.update(15, 'Verifying session...')
		session_valid, verified_username = verify_session(session_key)
		if session_valid:
			logged_in = True
			username = verified_username
			dialog_prepare.update(20, 'Signed in', username)
		else:
			clear_session()
			session_key = ''

	if not logged_in:
		dialog_prepare.update(20, 'Login required...')
		session_key, username = device_login(dialog_prepare)
		if session_key:
			logged_in = True
			save_session(session_key, username, console_id)
			dialog_prepare.update(25, 'Signed in', username)
			notify('Signed in as {}'.format(username))
		else:
			dialog_prepare.update(25, 'Not signed in', 'Local backup only')
			dialog_prepare.close()
			return

	dialog_prepare.update(40, 'Reading hardware info...')
	info = backup_and_read_sysinfo()
	serial = info['serial']
	hdd_key_hex = info['hdd_key'].replace(':', '')

	dialog_prepare.update(60, 'Scanning saves...')
	if individual_saves_enabled():
		profile_key = truncate_fatx(getInfoLabel('System.ProfileName').strip())
		profile_label = profile_key
	else:
		profile_key = ''
		profile_label = ''

	titles = scan_udata(UDATA_PATH)
	grand_total = len(titles)
	dialog_prepare.update(75, 'Scanning done...', profile_label or UDATA_PATH, '{} titles, {} saves'.format(grand_total, sum(len(title['saves']) for title in titles)))
	write_report(titles)

	dialog_prepare.update(80, 'Uploading console data...')
	new_console_id = upload_console_data(session_key, serial, hdd_key_hex)
	if new_console_id:
		console_id = new_console_id
		save_session(session_key, username, console_id)
		save_sysinfo(console_id)
		dialog_prepare.update(88, 'Uploading console data...', 'Console ID: {}'.format(console_id))
	elif console_id:
		dialog_prepare.update(88, 'Uploading console data...', 'Cached console ID: {}'.format(console_id))
	else:
		dialog_prepare.update(88, 'Uploading console data...', 'WARNING: no console ID')

	dialog_prepare.update(90, 'Fetching manifest...')
	manifest = fetch_manifest(session_key)
	dialog_prepare.update(100, 'Fetching manifest...', 'Ready' if manifest else 'No manifest')

	smart_sync = not force_mode
	total_created = total_uploaded = total_skipped = titles_done = 0

	dialog_sync = ProgressDialog('XBL Cloud - Force Sync' if force_mode else 'XBL Cloud - Sync')
	dialog_sync.update(1, 'Smart sync' if smart_sync else 'Force all')
	for title in titles:
		if dialog_sync.is_canceled():
			canceled = True
			break
		title_id = title['titleId']
		title_name = title['titleName'] or title_id
		title_fp = fingerprint_title(title)
		titles_done += 1
		progress_pct = int(100 * titles_done / max(grand_total, 1))

		if smart_sync and console_id and manifest and manifest_matches(manifest, console_id, profile_key, title_id, title_fp):
			total_skipped += 1
			dialog_sync.update(progress_pct, 'Skipping...', title_name, '{} of {}'.format(titles_done, grand_total))
			continue

		if smart_sync and manifest:
			any_mtime = manifest_get_any_mtime(manifest, title_id)
			local_mtime = int(max(save['mtime'] for save in title['saves']) if title['saves'] else 0)
			if any_mtime and local_mtime < any_mtime:
				total_skipped += 1
				dialog_sync.update(progress_pct, 'Server newer - skipping...', title_name, '{} of {}'.format(titles_done, grand_total))
				continue

		dialog_sync.update(progress_pct, 'Compressing...', title_name, '{} of {}'.format(titles_done, grand_total))

		zip_path = join(OUTPUT_DIR, title_id + '.zip')
		dukex_path = join(OUTPUT_DIR, title_id + '.dukex')

		if not zip_directory(title['path'], zip_path):
			dialog_sync.update(progress_pct, 'WARNING: zip failed', title_name)
			continue

		try:
			if isfile(dukex_path):
				remove(dukex_path)
			rename(zip_path, dukex_path)
		except Exception:
			dialog_sync.update(progress_pct, 'WARNING: rename failed', title_name)
			continue

		total_created += 1
		save_total_size = sum(save['size'] for save in title['saves'])
		save_file_count = len(title['saves'])
		save_latest_mtime = max(save['mtime'] for save in title['saves']) if title['saves'] else 0
		dialog_sync.update(progress_pct, 'Uploading...', title_name, '{} of {}'.format(titles_done, grand_total))
		if upload_save(session_key, console_id, hdd_key_hex, serial, profile_key, profile_label, title_id, title_name, save_file_count, save_total_size, title_fp, save_latest_mtime, dukex_path):
			total_uploaded += 1
		else:
			dialog_sync.update(progress_pct, 'WARNING: upload failed', title_name)

		try:
			remove(dukex_path)
		except Exception:
			pass
		gc.collect()

	dialog_sync.update(100, 'Upload complete', '{} compressed {} uploaded {} skipped'.format(total_created, total_uploaded, total_skipped))

	if canceled:
		notify('Sync cancelled - {} uploaded'.format(total_uploaded))
	else:
		notify('Sync complete - {} uploaded'.format(total_uploaded))
		download(session_key, console_id, manifest, hdd_key_hex = hdd_key_hex)


def get_session_and_manifest():
	create_dir(OUTPUT_DIR)
	dialog_prepare = ProgressDialog('XBL Cloud - Preparing')
	dialog_prepare.update(10, 'Checking session...')
	session_key, username, console_id = load_session()
	if not session_key:
		dialog_prepare.update(100, 'Not signed in')
		dialog_prepare.close()
		notify('Not signed in')
		return None, None, None

	dialog_prepare.update(30, 'Verifying session...')
	session_valid, verified_username = verify_session(session_key)
	if not session_valid:
		dialog_prepare.update(100, 'Session invalid')
		dialog_prepare.close()
		notify('Sign in required')
		return None, None, None

	dialog_prepare.update(60, 'Fetching manifest...')
	manifest = fetch_manifest(session_key)
	if not manifest:
		dialog_prepare.update(100, 'No manifest')
		dialog_prepare.close()
		notify('No manifest available')
		return None, None, None

	dialog_prepare.update(80, 'Reading hardware info...')
	backup_and_read_sysinfo()
	if console_id:
		save_sysinfo(console_id)

	dialog_prepare.update(100, 'Ready')
	dialog_prepare.close()
	return session_key, console_id, manifest


def run_download_loop(title, session_key, console_id, manifest, skip_same_console, skip_existing, skip_nosync = True, hdd_key_hex = ''):
	has_cross_console = any(
		line.split('=')[0].split(':')[0] != console_id
		for line in manifest.splitlines()
		if '=' in line and '|nosync' not in line
	)

	if LOCAL_RESIGN_SAVES and not skip_same_console and has_cross_console:
		sysinfo = parse_sysinfo(console_id)
		missing = []
		if not hdd_key_hex:
			missing.append('HDD key')
		if not sysinfo.get('xboxmac', '').replace(':', '').replace('-', ''):
			missing.append('MAC address')
		if missing:
			Dialog().ok(title, 'Cannot resign saves - missing: {}'.format(', '.join(missing)))
			return

	local_title_ids = set()
	try:
		for entry in listdir(UDATA_PATH):
			if isdir(join(UDATA_PATH, entry)):
				local_title_ids.add(entry)
	except Exception:
		pass

	best_entries = {}
	for line in [ln for ln in manifest.splitlines() if '=' in ln]:
		if skip_nosync and '|nosync' in line:
			continue
		manifest_key, manifest_val = line.split('=', 1)
		key_parts = manifest_key.split(':')
		if len(key_parts) == 3:
			src_console, src_profile, tid = key_parts
		elif len(key_parts) == 2:
			src_console, tid = key_parts
			src_profile = ''
		else:
			src_console = src_profile = ''
			tid = manifest_key
		if not tid:
			continue
		if skip_same_console and src_console and console_id and src_console == console_id:
			continue
		parts = manifest_val.split('|')
		try:
			mtime = int(parts[1]) if len(parts) > 1 and parts[1].strip().isdigit() else 0
		except Exception:
			mtime = 0
		if tid not in best_entries or mtime > best_entries[tid][3]:
			best_entries[tid] = (src_console, src_profile, manifest_val, mtime)	

	total_remote = max(len(best_entries), 1)
	lines_processed = total_pulled = 0
	canceled = False

	dialog_download = ProgressDialog(title)
	dialog_download.update(1, 'Checking for downloads...')
	for title_id, (source_console, source_profile, manifest_val, remote_mtime) in best_entries.items():
		if dialog_download.is_canceled():
			canceled = True
			break
		lines_processed += 1
		download_pct = int(100 * lines_processed / total_remote)
		if skip_existing and title_id in local_title_ids:
			if not remote_mtime:
				continue
			local_mtime = 0
			try:
				for root, dirs, files in walk(join(UDATA_PATH, title_id)):
					for fname in files:
						try:
							m = stat(join(root, fname)).st_mtime
							if m > local_mtime:
								local_mtime = m
						except Exception:
							pass
			except Exception:
				pass
			if local_mtime >= remote_mtime:
				continue

		dialog_download.update(download_pct, 'Downloading...', title_id, '{} of {}'.format(lines_processed, total_remote))
		dukex_path = join(OUTPUT_DIR, title_id + '.dukex')
		if download_save(session_key, source_console, console_id, source_profile, title_id, dukex_path):
			if unzip_to_dir(dukex_path, join(UDATA_PATH, title_id)):
				total_pulled += 1
				local_title_ids.add(title_id)
				if LOCAL_RESIGN_SAVES and hdd_key_hex and source_console and source_console != console_id:
					src_eeprom_path = join(OUTPUT_DIR, '{}_eeprom.bin'.format(source_console))
					if fetch_console_eeprom(session_key, source_console, src_eeprom_path):
						src_mac_hex = read_mac_from_eeprom(src_eeprom_path)
						src_hdd_hex = fetch_console_hdd_key(session_key, source_console)
						dst_mac_hex = parse_sysinfo(console_id).get('xboxmac', '').replace(':', '').replace('-', '').upper()
						dialog_download.update(download_pct, 'Signing...', title_id, '{} of {}'.format(lines_processed, total_remote))
						resign_saves(title_id, join(UDATA_PATH, title_id), hdd_key_hex, src_mac_hex = src_mac_hex, dst_mac_hex = dst_mac_hex, src_hdd_hex = src_hdd_hex)
						try:
							remove(src_eeprom_path)
						except Exception:
							pass
				dialog_download.update(download_pct, 'Restored', title_id, '{} of {}'.format(lines_processed, total_remote))
			else:
				dialog_download.update(download_pct, 'WARNING: extract failed', title_id)
			try:
				remove(dukex_path)
			except Exception:
				pass
		else:
			dialog_download.update(download_pct, 'WARNING: download failed', title_id)

	dialog_download.update(100, 'Downloads complete', '{} save(s) restored'.format(total_pulled))
	dialog_download.close()
	if canceled:
		notify('Download cancelled - {} restored'.format(total_pulled))
	else:
		notify('Download complete - {} restored'.format(total_pulled))


def download(session_key = None, console_id = None, manifest = None, hdd_key_hex = ''):
	if not session_key:
		session_key, console_id, manifest = get_session_and_manifest()
		if not session_key:
			return
	run_download_loop('XBL Cloud - Downloads', session_key, console_id, manifest, skip_same_console = True, skip_existing = True, skip_nosync = True, hdd_key_hex = hdd_key_hex)


def restore():
	session_key, console_id, manifest = get_session_and_manifest()
	if not session_key:
		return
	hdd_key_hex = parse_sysinfo(console_id).get('hdd_key', '').replace(':', '')
	run_download_loop('XBL Cloud - Restore', session_key, console_id, manifest, skip_same_console = False, skip_existing = False, skip_nosync = False, hdd_key_hex = hdd_key_hex)


def restore_missing():
	session_key, console_id, manifest = get_session_and_manifest()
	if not session_key:
		return
	hdd_key_hex = parse_sysinfo(console_id).get('hdd_key', '').replace(':', '')
	run_download_loop('XBL Cloud - Restore Missing', session_key, console_id, manifest, skip_same_console = False, skip_existing = True, skip_nosync = False, hdd_key_hex = hdd_key_hex)


# Menu
def show_menu():
	session_key, username, console_id = load_session()
	signed_in = False
	if session_key:
		session_valid, verified_username = verify_session(session_key)
		if session_valid:
			signed_in = True
			username = verified_username

	while True:
		sign_in_label = 'Signed In: {} / CID: {}'.format(username, console_id) if signed_in else 'Sign In'

		executebuiltin('Dialog.Close(1100,true)')
		executebuiltin('Dialog.Close(1112,true)')

		choice = Dialog().select(ADDON_ID, [
			'Smart Sync Saves',
			'Restore Missing Saves',
			'+ Advanced',
			'Settings',
			'View Information',
			sign_in_label,
		])
		if choice < 0:
			break
		elif choice in (0, 1, 2) and not signed_in:
			notify('Please sign in first')
			continue
		elif choice == 0:
			sync(force_mode = False, smart_mode = True)
		elif choice == 1:
			restore_missing()
		elif choice == 2:
			adv_choice = Dialog().select('Advanced', [
				'Reupload Saves To The Cloud',
				'Restore Saves From The Cloud',
			])
			if adv_choice == 0:
				if Dialog().yesno('Reupload Saves To The Cloud', 'This replaces your saves on the server with your current local saves.[CR]Use this only if your server data is wrong.[CR]Other Xboxes are not affected until they sync.[CR]Are you sure?', '', '', getLocalizedString(222), getLocalizedString(107)):
					sync(force_mode = True, smart_mode = False)
			elif adv_choice == 1:
				if Dialog().yesno('Restore Saves From The Cloud', '', 'This will overwrite any matching local saves.[CR]Are you sure?', '', getLocalizedString(222), getLocalizedString(107)):
					restore()
		elif choice == 3:
			try:
				ADDON.openSettings()
			except Exception:
				executebuiltin('Addon.OpenSettings({})'.format(ADDON_ID))
		elif choice == 4:
			executebuiltin('TextViewer({}\\info.txt,Information by Rocky5)'.format(join(ROOT_DIR)))
			sleep(1000)
			while getCondVisibility('Window.IsActive(147)'):
				sleep(500)
		elif choice == 5:
			signin()
			session_key, username, console_id = load_session()
			if session_key:
				session_valid, verified_username = verify_session(session_key)
				if session_valid:
					signed_in = True
					username = verified_username


def main():
	force_mode, smart_mode, signin_mode, restore_mode, restore_missing_mode = parse_args()

	lock_path = join(OUTPUT_DIR, 'xblcloud.lock')
	create_dir(OUTPUT_DIR)
	try:
		remove(lock_path)
	except Exception:
		pass
	try:
		open(lock_path, 'w').close()
	except Exception:
		pass

	try:
		if not any([force_mode, smart_mode, signin_mode, restore_mode, restore_missing_mode]):
			show_menu()
		elif signin_mode:
			signin()
		elif restore_mode:
			restore()
		elif restore_missing_mode:
			restore_missing()
		else:
			sync(force_mode, smart_mode)
	finally:
		try:
			remove(lock_path)
		except Exception:
			pass


if __name__ == '__main__':
	try:
		main()
	except Exception:
		error_message = traceback.format_exc()
		log('FATAL: {}'.format(error_message))
		try:
			Dialog().ok(ADDON_ID + ' Error', error_message[:200])
		except Exception:
			pass
	gc.collect()
