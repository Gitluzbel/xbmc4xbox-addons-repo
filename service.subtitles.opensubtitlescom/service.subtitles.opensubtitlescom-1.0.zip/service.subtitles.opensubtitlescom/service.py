# -*- coding: utf-8 -*-
'''
	Addon de subtitulos para la API REST nueva de OpenSubtitles.com (no la
	vieja opensubtitles.org basada en XML-RPC, que ahora exige cuenta VIP
	de pago para descargar). Esta API funciona con una API key personal
	gratuita (Perfil - API Consumers en opensubtitles.com), sin necesidad
	de usuario/contrasena ni login - confirmado a mano que busqueda y
	descarga funcionan solo con la Api-Key en la cabecera.
'''

import os
import sys
import struct
import urllib
import urllib2
import json
import uuid
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

__addon__      = xbmcaddon.Addon()
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__language__   = __addon__.getLocalizedString

__profile__ = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode('utf-8')
__temp__    = xbmc.translatePath(os.path.join(__profile__, 'temp', '')).decode('utf-8')

API_BASE = "https://api.opensubtitles.com/api/v1"
USER_AGENT = "XboxOgSubs v1.0"
# Las peticiones POST a /download fallan con 503 tanto desde la Xbox como
# desde un Linux normal usando urllib - pero funcionan bien con curl real
# (negocia HTTP/2, cosa que urllib no sabe hacer). Cloudflare debe aplicar
# un filtro mas estricto a POST por HTTP/1.1 en este endpoint. Por eso la
# descarga (no la busqueda, que si funciona bien tal cual) pasa por un
# proxy en el mini PC que hace la llamada real con curl.
#
# BUG REAL ENCONTRADO EN AUDITORIA (12/09/2026): esto estaba hardcodeado
# a la IP fija de siempre, sin ningun intento de descubrimiento por
# NetBIOS como el resto de addons que hablan con el mismo mini PC (ver
# plugin.video.invidious/invidious.py, _default_instance()). Mismo
# patron aplicado aqui: NBNS primero, IP fija solo como ultimo recurso.
_MINIPC_NETBIOS_NAME = "XBOXMINIPC"
_DOWNLOAD_PROXY_FALLBACK_IP = "192.168.1.134"


def _download_proxy_url():
	try:
		from nbnsresolve import resolve_netbios_name
		ip = resolve_netbios_name(_MINIPC_NETBIOS_NAME)
	except Exception as e:
		log("fallo resolviendo %s por NBNS: %s" % (_MINIPC_NETBIOS_NAME, e))
		ip = None
	return "http://%s:8093/download" % (ip or _DOWNLOAD_PROXY_FALLBACK_IP)


def log(msg):
	xbmc.log(("[%s] %s" % (__scriptid__, msg)).encode('utf-8'), level=xbmc.LOGDEBUG)


def api_key():
	return __addon__.getSetting("APIKey").strip()


def _utf8(value):
	if isinstance(value, unicode):
		return value.encode('utf-8')
	return value


def api_request(path, params=None, post_data=None):
	url = "%s%s" % (API_BASE, path)
	if params:
		encoded_params = dict((k, _utf8(v)) for k, v in params.items())
		url += "?" + urllib.urlencode(encoded_params)

	headers = {"Api-Key": api_key(), "User-Agent": USER_AGENT}
	data = None
	if post_data is not None:
		data = json.dumps(post_data)
		headers["Content-Type"] = "application/json"
		# Este stack HTTP tan antiguo (urllib2 sobre el Python embebido de la
		# Xbox) puede no calcular bien Content-Length solo, lo ponemos a
		# mano para evitar que el servidor rechace la peticion POST.
		headers["Content-Length"] = str(len(data))

	req = urllib2.Request(url, data=data, headers=headers)
	response = urllib2.urlopen(req, timeout=15)
	body = response.read()
	return json.loads(body)


def opensubtitles_hash(file_path):
	'''
		Algoritmo de hash estandar de OpenSubtitles (mismo que usan todos
		los sitios de subtitulos), calculado a partir del tamano del
		archivo y los primeros/ultimos 64KB. Usado como parametro opcional
		"moviehash" para mejorar la precision de la busqueda. Si falla por
		cualquier motivo (archivo en red lento, formato raro), se ignora y
		la busqueda sigue solo por titulo.
	'''
	try:
		longlongformat = 'q'
		bytesize = struct.calcsize(longlongformat)

		f = xbmcvfs.File(file_path)
		filesize = f.size()
		if filesize < 65536 * 2:
			f.close()
			return None

		file_hash = filesize
		buffer_data = f.read(65536)
		f.seek(max(0, filesize - 65536), 0)
		buffer_data += f.read(65536)
		f.close()

		for x in range((65536 / bytesize) * 2):
			offset = x * bytesize
			(value,) = struct.unpack(longlongformat, buffer_data[offset:offset + bytesize])
			file_hash += value
			file_hash = file_hash & 0xFFFFFFFFFFFFFFFF

		return "%016x" % file_hash
	except Exception:
		return None


def notify(message):
	xbmc.executebuiltin((u'Notification(%s,%s,4000,%s)' % (__scriptname__, message, os.path.join(
		xbmc.translatePath(__addon__.getAddonInfo('path')).decode('utf-8'), "icon.png"))).encode('utf-8'))


def Search(item):
	if not api_key():
		notify(__language__(32006))
		return

	params = {"languages": ",".join(item['languages'])}

	if item['moviehash']:
		params['moviehash'] = item['moviehash']

	if item['season'] and item['episode']:
		params['query'] = item['title']
		params['season_number'] = item['season']
		params['episode_number'] = item['episode']
	else:
		params['query'] = item['title']
		if item['year']:
			params['year'] = item['year']

	try:
		result = api_request("/subtitles", params=params)
	except Exception as e:
		log("Search failed: %s" % e)
		xbmcgui.Dialog().ok(__scriptname__, __language__(32001))
		return

	subtitles = result.get('data', [])
	if not subtitles:
		return

	for sub in subtitles:
		attrs = sub.get('attributes', {})
		files = attrs.get('files', [])
		if not files:
			continue

		file_id = files[0].get('file_id')
		release = attrs.get('release') or files[0].get('file_name') or ""
		lang_2letter = attrs.get('language', 'en')
		rating = attrs.get('ratings', 0.0)
		hearing_imp = attrs.get('hearing_impaired', False)

		listitem = xbmcgui.ListItem(label=lang_2letter, label2=release)
		listitem.setArt({'icon': str(int(round(float(rating) / 2))), 'thumb': lang_2letter})
		# La API no devuelve un campo fiable para saber si ESTE resultado en
		# concreto coincidio por moviehash o por texto, asi que no se marca
		# "sync" (mejor no mostrar el icono de sincronizado que mostrarlo
		# mal). El parametro moviehash de la busqueda ya prioriza resultados
		# mas relevantes igualmente.
		listitem.setProperty("hearing_imp", "true" if hearing_imp else "false")

		url = "plugin://%s/?action=download&file_id=%s&filename=%s" % (
			__scriptid__,
			file_id,
			urllib.quote(release.encode('utf-8'))
		)
		xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)


def Download(params):
	if xbmcvfs.exists(__temp__):
		for f in xbmcvfs.listdir(__temp__)[1]:
			xbmcvfs.delete(os.path.join(__temp__, f))
	xbmcvfs.mkdirs(__temp__)

	proxy_url = "%s?file_id=%s&api_key=%s" % (_download_proxy_url(), urllib.quote(params["file_id"]), urllib.quote(api_key()))
	try:
		response = urllib2.urlopen(proxy_url, timeout=30)
		content = response.read()
	except urllib2.HTTPError as e:
		if e.code == 406:
			xbmcgui.Dialog().ok(__scriptname__, __language__(32004))
		else:
			try:
				body = e.read()
			except Exception:
				body = "<no se pudo leer el cuerpo>"
			log("Download via proxy failed: %s - body: %s" % (e, body))
		return []
	except Exception as e:
		log("Download via proxy failed: %s" % e)
		return []

	dest = os.path.join(__temp__, "%s.srt" % str(uuid.uuid4()))
	log("CHECKPOINT guardando subtitulo en: %s" % dest)
	f = open(dest, 'wb')
	f.write(content)
	f.close()

	return [dest]


def get_params(string=""):
	param = {}
	paramstring = string if string else sys.argv[2]
	if len(paramstring) >= 2:
		cleaned = paramstring.replace('?', '')
		for pair in cleaned.split('&'):
			split = pair.split('=')
			if len(split) == 2:
				param[split[0]] = split[1]
	return param


params = get_params()

log("CHECKPOINT llamado con params: %s" % params)

if params.get('action') in ('search', 'manualsearch'):
	item = {}
	item['title'] = xbmc.getInfoLabel("VideoPlayer.OriginalTitle") or xbmc.getInfoLabel("VideoPlayer.Title")
	item['year'] = xbmc.getInfoLabel("VideoPlayer.Year")
	item['season'] = str(xbmc.getInfoLabel("VideoPlayer.Season") or "")
	item['episode'] = str(xbmc.getInfoLabel("VideoPlayer.Episode") or "")

	if item['season'] and item['episode']:
		tvshow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
		if tvshow:
			item['title'] = tvshow

	played_file = xbmc.Player().getPlayingFile()
	item['moviehash'] = None
	if played_file and 'http' not in played_file and 'plugin://' not in played_file:
		item['moviehash'] = opensubtitles_hash(urllib.unquote(played_file))

	item['languages'] = []
	for lang in urllib.unquote(params.get('languages', '')).split(","):
		if not lang:
			continue
		code = xbmc.convertLanguage(lang, xbmc.ISO_639_1)
		if code:
			item['languages'].append(code)
	if not item['languages']:
		item['languages'] = ['en']

	if item['title']:
		Search(item)

elif params.get('action') == 'download':
	subs = Download(params)
	for sub in subs:
		listitem = xbmcgui.ListItem(label=sub)
		xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sub, listitem=listitem, isFolder=False)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
