# -*- coding: utf-8 -*-
'''
	Mide la velocidad de disco en local (sin red) de dos formas para poder
	separar "techo real de UDMA/hardware" de "contencion de leer+escribir
	el mismo disco a la vez":
	  1) Solo lectura: lee el archivo de prueba entero, sin escribir nada.
	  2) Copia: lee y escribe a la vez (como en la v1.0.2), para comparar.
'''
import os
import time
import xbmc
import xbmcgui

SRC = "F:\\XBMC4Xbox\\testdisk\\test_200mb.bin"
DST = "F:\\XBMC4Xbox\\testdisk\\test_200mb_copy.bin"
# 256KB con fsync() por cada trozo (800 llamadas para 200MB) daba SIEMPRE
# ~49s pase lo que pase con el UDMA - fsync() en este build tiene un coste
# fijo por llamada que domina el tiempo total (49s / 800 = ~61ms/llamada,
# sospechosamente constante), tapando por completo la velocidad real del
# disco. Con trozos de 8MB solo hacen falta ~25 llamadas, y el fsync final
# fuerza que lo que quede en buffer también se escriba de verdad antes de
# parar el cronometro.
CHUNK = 1024 * 1024 * 8


def read_timed(src):
	size = os.path.getsize(src)
	start = time.time()
	with open(src, 'rb') as fsrc:
		while True:
			buf = fsrc.read(CHUNK)
			if not buf:
				break
	elapsed = time.time() - start
	return size, elapsed


def copy_timed(src, dst):
	size = os.path.getsize(src)
	start = time.time()
	with open(src, 'rb') as fsrc:
		with open(dst, 'wb') as fdst:
			while True:
				buf = fsrc.read(CHUNK)
				if not buf:
					break
				fdst.write(buf)
			fdst.flush()
			os.fsync(fdst.fileno())
	elapsed = time.time() - start
	return size, elapsed


def fmt(size, elapsed):
	mb = size / (1024.0 * 1024.0)
	speed = mb / elapsed if elapsed > 0 else 0.0
	return mb, elapsed, speed


if __name__ == '__main__':
	xbmc.executebuiltin('Dialog.Close(1100,false)')
	dialog = xbmcgui.Dialog()

	if not os.path.isfile(SRC):
		dialog.ok('Test de disco', '', 'No se encuentra el archivo de origen:', SRC)
	else:
		try:
			if os.path.isfile(DST):
				os.remove(DST)

			r_size, r_elapsed = read_timed(SRC)
			r_mb, r_elapsed, r_speed = fmt(r_size, r_elapsed)
			msg_read = 'Solo lectura: {0:.2f} MB en {1:.3f} s -> {2:.2f} MB/s'.format(r_mb, r_elapsed, r_speed)
			xbmc.log('[DiskSpeedTest] ' + msg_read, xbmc.LOGNOTICE)

			c_size, c_elapsed = copy_timed(SRC, DST)
			c_mb, c_elapsed, c_speed = fmt(c_size, c_elapsed)
			msg_copy = 'Copia (lectura+escritura): {0:.2f} MB en {1:.3f} s -> {2:.2f} MB/s'.format(c_mb, c_elapsed, c_speed)
			xbmc.log('[DiskSpeedTest] ' + msg_copy, xbmc.LOGNOTICE)

			dialog.ok('Test de disco', '', msg_read, msg_copy)
		except Exception as e:
			xbmc.log('[DiskSpeedTest] Error: {0}'.format(e), xbmc.LOGERROR)
			dialog.ok('Test de disco', '', 'Error: {0}'.format(e))
