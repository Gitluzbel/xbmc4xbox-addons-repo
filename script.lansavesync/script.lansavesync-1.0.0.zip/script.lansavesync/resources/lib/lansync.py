# -*- coding: utf-8 -*-
''' 
	LAN Save Sync
	Script by Rocky5

	Original concept:
		https://github.com/OGXBL/XBLLANSync

	Requires latest XBMC4Gamers or my XBMC4Xbox 3.6 version.
	The script uses stuff not in older version of XBMC4Xbox or XBMC4Gamers.
'''
from os import makedirs, listdir, remove, rename, stat, utime, walk
from os.path import basename, dirname, isdir, isfile, join, relpath
from xbmc import sleep, executebuiltin, getCondVisibility, getInfoLabel, getLocalizedString, Keyboard
from xbmcaddon import Addon
from xbmcgui import DialogProgress, Dialog, Window
import gc, savesigner, shutil, sys, traceback, zipfile

WINDOW = Window(10020)
GETPROPERTY = WINDOW.getProperty

ADDON_ID = 'LAN Save Sync'
ADDON = Addon(ADDON_ID)
ROOT_DIR = ADDON.getAddonInfo('path')

ZIP_CHUNK_SIZE = 32 * 1024
OUTPUT_DIR = 'E:\\CACHE\\LAN Save Sync'
REPORT_PATH = join(OUTPUT_DIR, '{} Report.txt'.format(ADDON_ID))
SYSINFO_PATH = 'Q:\\system\\SystemInfo\\EEPROMBackup.cfg'
CERBIOS_INI = 'E:\\Cerbios\\cerbios.ini'
UDATA_PART_MAP = {1: 'E', 6: 'F', 7: 'G'}
EXTRA_LOGGING = False
SIGNERS_CACHE = None


# Utilities / helpers
## UDATA / Cerbios
def get_udata_path():
	if isfile(CERBIOS_INI) and Window(12999).getProperty('Cerbios.Detected'):
		try:
			ini_data = {}
			section = ''
			for line in open(CERBIOS_INI).readlines():
				line = line.strip()
				if line.startswith('[') and line.endswith(']'):
					section = line[1:-1].strip()
					continue
				if '=' in line and not line.startswith(';'):
					key, value = line.split('=', 1)
					ini_data[(section, key.strip().lower())] = value.strip()
			redir = ini_data.get(('', 'tudataredir')) or ini_data.get(('CERBIOS CONFIG EDITOR', 'tudataredir'), 'false')
			if redir.strip().lower() == 'true':
				part_str = ini_data.get(('', 'tudataredirpart')) or ini_data.get(('CERBIOS CONFIG EDITOR', 'tudataredirpart'), '1')
				drive = UDATA_PART_MAP.get(int(part_str.strip()), 'E')
				log('Cerbios UDATA redirect -> {}:\\UDATA'.format(drive))
				return '{}:\\UDATA'.format(drive)
		except Exception as error:
			log('get_udata_path failed: {}'.format(error))
	return 'E:\\UDATA'


UDATA_PATH = get_udata_path()


## Logging / formatting
def log(message):
	try:
		if isinstance(message, unicode):
			message = message.encode('ascii', errors = 'replace').decode('ascii')
		print '[{}] {}'.format(ADDON_ID, message)
	except Exception:
		pass


def safe(text):
	try:
		if isinstance(text, unicode):
			return text.encode('ascii', 'replace')
		return str(text)
	except Exception:
		return ''


## Progress / notifications
class SilentProgress(object):
	instance = None

	def __init__(self, title, reuse = False):
		SilentProgress.instance = self
		self._title = safe(title)
		if not reuse:
			executebuiltin('shownotification({}, Starting, 0, {}\\icon.png)'.format(self._title, ROOT_DIR))
			sleep(1000)

	def update(self, percent = 0, line1 = '', line2 = '', line3 = ''):
		parts = [safe(x) for x in (line1, line2, line3) if x]
		text = ' '.join(parts)
		log('{}% {}'.format(percent, text))
		executebuiltin('updatenotification({}, {})'.format(self._title, text))

	def is_canceled(self):
		return False

	def close(self):
		SilentProgress.instance = None
		sleep(1000)
		executebuiltin('closenotification()')


class ProgressDialog(object):
	def __init__(self, title):
		self.dialog = DialogProgress()
		self.dialog.create(title, '', 'Initializing', '')

	def update(self, percent = 0, line1 = '', line2 = '', line3 = ''):
		log('{}% {} {} {}'.format(percent, safe(line1), safe(line2), safe(line3)))
		try:
			self.dialog.update(int(percent), safe(line1), safe(line2), safe(line3))
		except Exception:
			pass

	def is_canceled(self):
		try:
			return self.dialog.iscanceled()
		except Exception:
			return False

	def close(self):
		try:
			self.dialog.close()
		except Exception:
			pass


def close_notification_dialog(dialog = None):
	if SilentProgress.instance:
		SilentProgress.instance.close()
	elif dialog:
		dialog.close()


def notify(message):
	try:
		executebuiltin('Notification({}, {}, 4000, {}\\icon.png)'.format(ADDON_ID, safe(message), ROOT_DIR))
	except Exception:
		pass


## File / path
def create_dir(path):
	try:
		if not isdir(path):
			makedirs(path)
	except Exception as error:
		log('create_dir failed: {}'.format(error))


def truncate_fatx(name):
	return name[:32]


def sanitize_profile_name(name):
	result = ''
	for char in (name or ''):
		if char.isalnum() or char in ('_', '-'):
			result += char
		if len(result) >= 32:
			break
	return result


def zip_directory(src_path, dest_path):
	try:
		with zipfile.ZipFile(dest_path, 'w', zipfile.ZIP_STORED) as zip_file:
			for root, dirs, files in walk(src_path):
				for filename in files:
					full_path = join(root, filename)
					archive_name = relpath(full_path, src_path)
					try:
						with open(full_path, 'rb') as fh:
							file_data = bytearray()
							while True:
								chunk = fh.read(ZIP_CHUNK_SIZE)
								if not chunk:
									break
								file_data.extend(chunk)
						zip_file.writestr(archive_name, bytes(file_data))
						del file_data
					except Exception as error:
						log('zip skip {}: {}'.format(archive_name, error))
		return True
	except Exception as error:
		log('zip: {}'.format(error))
		return False


def unzip_to_dir(src_path, dest_path):
	try:
		create_dir(dest_path)
		with zipfile.ZipFile(src_path, 'r') as zip_file:
			for entry_name in zip_file.namelist():
				out_path = join(dest_path, entry_name)
				if entry_name.endswith('/'):
					create_dir(out_path)
					continue
				create_dir(dirname(out_path))
				with zip_file.open(entry_name) as zip_entry:
					with open(out_path, 'wb') as fh:
						while True:
							chunk = zip_entry.read(ZIP_CHUNK_SIZE)
							if not chunk:
								break
							fh.write(chunk)
		return True
	except Exception as error:
		log('unzip: {}'.format(error))
		return False


## Scanning / fingerprinting
def scan_udata(profile_path):
	titles = []
	try:
		for title_id in listdir(profile_path):
			title_path = join(profile_path, title_id)
			if not isdir(title_path):
				continue
			title_name = title_id
			meta_path = join(title_path, 'TitleMeta.xbx')
			if isfile(meta_path):
				try:
					raw = open(meta_path, 'rb').read()
					text = raw.decode('utf-16-le', errors = 'replace')[1:] if raw[:2] == b'\xff\xfe' else raw.decode('utf-8', errors = 'replace')
					for meta_line in text.splitlines():
						meta_line = meta_line.strip()
						if meta_line.startswith('TitleName='):
							title_name = meta_line[10:].strip()
							break
				except Exception:
					pass
			saves = []
			for save_folder in listdir(title_path):
				save_path = join(title_path, save_folder)
				if not isdir(save_path):
					continue
				total_size = file_count = latest_mtime = 0
				for root, dirs, files in walk(save_path):
					for filename in files:
						try:
							file_stat = stat(join(root, filename))
							total_size += file_stat.st_size
							file_count += 1
							if file_stat.st_mtime > latest_mtime:
								latest_mtime = file_stat.st_mtime
						except Exception:
							pass
				saves.append({'folder': save_folder, 'size': total_size, 'count': file_count, 'mtime': latest_mtime})
			titles.append({'titleId': title_id, 'titleName': title_name, 'path': title_path, 'saves': saves})
	except Exception as error:
		log('scan_udata error after {} titles: {}'.format(len(titles), error))
	return titles


def title_mtime(title):
	return max(save['mtime'] for save in title['saves']) if title['saves'] else 0


def fingerprint_title(title):
	hash_value = 14695981039346656037
	hash_mask = (1 << 64) - 1
	total_size = sum(save['size'] for save in title['saves'])
	total_count = sum(save['count'] for save in title['saves'])
	latest_mtime = title_mtime(title)
	for byte in '{}|{}|{}|{}'.format(title['titleId'], total_size, total_count, int(latest_mtime)).encode('utf-8'):
		hash_value ^= (byte if isinstance(byte, int) else ord(byte))
		hash_value = (hash_value * 1099511628211) & hash_mask
	return '{:016x}'.format(hash_value)


## Reporting & convert bytes to readable values
def format_size(size):
	if size >= 1048576:
		return '{:.1f} MB'.format(size / 1048576.0)
	if size >= 1024:
		return '{:.1f} KB'.format(size / 1024.0)
	return '{} B'.format(size)


def write_report(all_scans):
	try:
		create_dir(OUTPUT_DIR)
		all_titles = []
		for profile_key, profile_label, titles in all_scans:
			for title in titles:
				all_titles.append(title)
		all_titles.sort(key = lambda title: safe(title['titleName']).lower())
		with open(REPORT_PATH, 'wb') as fh:
			total_size = sum(sum(save['size'] for save in title['saves']) for title in all_titles)
			total_saves = sum(len(title['saves']) for title in all_titles)
			fh.write('{} - Save Report\n'.format(ADDON_ID).encode('utf-8'))
			fh.write('{}\n'.format('=' * 60).encode('utf-8'))
			fh.write('{} titles  |  {} save slots  |  {}\n\n'.format(
				len(all_titles), total_saves, format_size(total_size)).encode('utf-8'))
			for title in all_titles:
				name = safe(title['titleName'])
				size = sum(save['size'] for save in title['saves'])
				slots = len(title['saves'])
				line = '{:<12}  {}\n'.format(title['titleId'], name)
				detail = '{:<12}  {} slot{}  {}\n\n'.format(
					'', slots, 's' if slots != 1 else ' ', format_size(size))
				fh.write(line.encode('utf-8', errors = 'replace'))
				fh.write(detail.encode('utf-8', errors = 'replace'))
	except Exception as error:
		log('write_report: {}'.format(error))


## Save resigning
def get_signers():
	global SIGNERS_CACHE
	if SIGNERS_CACHE is None:
		try:
			SIGNERS_CACHE = savesigner.load_signers()
			log('get_signers: loaded {} signer(s)'.format(len(SIGNERS_CACHE)))
		except Exception as error:
			log('get_signers: failed to load savesigner: {}'.format(error))
			SIGNERS_CACHE = {}
	return SIGNERS_CACHE


def save_resinger(title_id_str, title_path, hdd_key_hex, src_mac_hex = None, dst_mac_hex = None, src_hdd_hex = None):
	ok, msg = savesigner.resign_title(title_id_str, title_path, hdd_key_hex, get_signers(), src_mac_hex = src_mac_hex, dst_mac_hex = dst_mac_hex, src_hdd_hex = src_hdd_hex)
	if not ok:
		log('save_resinger: {}'.format(msg))## Args
def parse_args():
	force_mode = smart_mode = silent_mode = download_mode = restore_mode = settings_mode = False
	for arg in sys.argv[1:]:
		arg_lower = arg.lower()
		if arg_lower == 'smart':
			smart_mode = True
		elif arg_lower == 'silent':
			silent_mode = True
		elif arg_lower == 'force':
			force_mode = True
		elif arg_lower == 'download':
			download_mode = True
		elif arg_lower == 'restore':
			restore_mode = True
		elif arg_lower == 'settings':
			settings_mode = True
	return force_mode, smart_mode, silent_mode, download_mode, restore_mode, settings_mode


# Settings
def get_setting(key):
	try:
		return ADDON.getSetting(key)
	except Exception:
		return ''


def open_settings():
	try:
		ADDON.openSettings()
	except Exception:
		executebuiltin('Addon.OpenSettings({})'.format(ADDON_ID))


def use_local():
	return True


def backend_label():
	return 'Local Backup'


def get_local_base():
	folder = get_setting('local_folder').strip()
	if not folder:
		folder = join(OUTPUT_DIR, ADDON_ID)
	return folder.rstrip('/\\') + '\\'


def is_configured():
	return True


# Backend (local folder only - the NAS/SMB backend from the original script
# depended on executehttpapi, which this fork's core does not implement)
def backend_mkdir(path):
	create_dir(path.replace('/', '\\'))
	return isdir(path.replace('/', '\\'))


def backend_listdir(path):
	try:
		return listdir(path.rstrip('/\\'))
	except Exception:
		return []


def backend_copy_up(local_path, dest):
	try:
		dest_local = dest.replace('/', '\\')
		create_dir(dirname(dest_local))
		shutil.copy2(local_path, dest_local)
		log('backend_copy_up ok dest = {}'.format(dest_local))
		return True
	except Exception as error:
		log('backend_copy_up error: {}'.format(error))
		return False


def backend_copy_down(src, local_dest):
	try:
		src_local = src.replace('/', '\\')
		shutil.copy2(src_local, local_dest)
		log('backend_copy_down ok src = {}'.format(src_local))
		return True
	except Exception as error:
		log('backend_copy_down error: {}'.format(error))
		return False




# Console info
def parse_sysinfo():
	info = {'serial': '', 'hdd_key': '', 'online_key': '', 'xboxmac': ''}
	try:
		for line in open(SYSINFO_PATH).readlines():
			line = line.strip()
			if line.startswith('#') or '=' not in line:
				continue
			key, value = line.split('=', 1)
			key = key.strip()
			value = value.strip().strip('"')
			if key == 'XBOXSerial':
				info['serial'] = value
			elif key == 'HDDKey':
				info['hdd_key'] = value
			elif key == 'OnlineKey':
				info['online_key'] = value
			elif key == 'XBOXMAC':
				info['xboxmac'] = value
	except Exception:
		pass
	return info


def parse_sysinfo_mac(sysinfo):
	return sysinfo.get('xboxmac', '').replace(':', '').replace('-', '').upper()


def read_eeprom_mac(eeprom_ini_path):
	return savesigner.read_eeprom_ini(eeprom_ini_path).get('mac', '')


def read_eeprom_hdd_key(eeprom_ini_path):
	return savesigner.read_eeprom_ini(eeprom_ini_path).get('hdd_key', '')


def read_console_id(dialog_prepare = None):
	if dialog_prepare:
		dialog_prepare.update(25, 'Reading hardware info...')
	if isfile(SYSINFO_PATH):
		remove(SYSINFO_PATH)
	executebuiltin('BackupSystemInfo')
	while True:
		if isfile(SYSINFO_PATH):
			try:
				if stat(SYSINFO_PATH).st_size > 0:
					break
			except Exception:
				pass
		sleep(100)
	info = parse_sysinfo()
	clean = ''.join(ch for ch in info['serial'].upper() if ch.isalnum()) if info['serial'] else ''
	console_id = 'XBX{}'.format(clean[:12]) if clean else 'XBXUNKNOWN'
	log('console_id: {}'.format(console_id))
	return console_id


# Profiles
def individual_saves_enabled():
	path = join('Q:\\system\\UserData', 'udata_settings.xml')
	try:
		if not getCondVisibility('System.HasLoginScreen'):
			return False
		content = open(path).read()
		if 'individual_saves' not in content:
			return False
		return '"true"' in content or "'true'" in content
	except Exception:
		return False


def active_profile():
	profile = truncate_fatx(getInfoLabel('System.ProfileName').strip())
	active_key = sanitize_profile_name(profile)
	return [(active_key, profile, UDATA_PATH)]


def get_nas_root(nas_base, console_id):
	return '{}{}/'.format(nas_base, ADDON_ID)


def get_saves_dir(nas_base, console_id, profile_key):
	root = get_nas_root(nas_base, console_id)
	if profile_key and individual_saves_enabled():
		return '{}{}/'.format(root, profile_key)
	return '{}saves/'.format(root)


# Manifest
def manifest_filename(profile_key):
	if profile_key and individual_saves_enabled():
		if len(profile_key) >= 29:
			return 'mfst_{}.txt'.format(truncate_fatx(profile_key))
		return 'manifest_{}.txt'.format(profile_key)
	return 'manifest.txt'


def parse_manifest_file(path):
	try:
		manifest = {}
		for line in open(path, 'rb').readlines():
			line = line.decode('utf-8', errors = 'replace').strip()
			if '=' in line:
				key, value = line.split('=', 1)
				manifest[key.strip()] = value.strip()
		return manifest
	except Exception:
		return {}


def load_manifest(nas_root, profile_key):
	filename = manifest_filename(profile_key)
	local_path = join(OUTPUT_DIR, filename)
	nas_path = '{}{}'.format(nas_root, filename)
	ok = backend_copy_down(nas_path, local_path)
	if ok:
		log('load_manifest: loaded from {} ({})'.format(backend_label(), filename))
	else:
		log('load_manifest: download failed, using local ({})'.format(filename))
	manifest = parse_manifest_file(local_path)
	log('load_manifest: {} entries'.format(len(manifest)))
	return manifest


def save_manifest_local(manifest, profile_key = ''):
	create_dir(OUTPUT_DIR)
	local_path = join(OUTPUT_DIR, manifest_filename(profile_key))
	try:
		fp_keys = sorted(mkey for mkey in manifest if not mkey.startswith('name:'))
		with open(local_path, 'wb') as fh:
			for key in fp_keys:
				for mkey in (key, 'name:' + key):
					if mkey in manifest:
						value = manifest[mkey]
						line = u'{}={}\n'.format(
							mkey if isinstance(mkey, unicode) else mkey.decode('utf-8', errors = 'replace'),
							value if isinstance(value, unicode) else value.decode('utf-8', errors = 'replace')
						)
						fh.write(line.encode('utf-8'))
	except Exception as error:
		log('save_manifest_local: {}'.format(error))


def save_manifest(manifest, nas_root, profile_key = ''):
	save_manifest_local(manifest, profile_key)
	filename = manifest_filename(profile_key)
	local_path = join(OUTPUT_DIR, filename)
	try:
		backend_copy_up(local_path, '{}{}'.format(nas_root, filename))
	except Exception as error:
		log('save_manifest nas upload: {}'.format(error))


def manifest_profile_key(profile_key):
	return profile_key if individual_saves_enabled() else ''


def manifest_key(console_id, profile, title_id):
	mk = manifest_profile_key(profile)
	return '{}:{}:{}'.format(console_id, mk, title_id)


def manifest_get_entry(manifest, console_id, profile, title_id):
	value = manifest.get(manifest_key(console_id, profile, title_id), '')
	if '|' in value:
		parts = value.split('|', 1)
		return parts[0], int(parts[1]) if parts[1].isdigit() else 0
	return value, 0


def manifest_matches(manifest, console_id, profile, title_id, fingerprint):
	stored_fp, stored_mtime = manifest_get_entry(manifest, console_id, profile, title_id)
	return stored_fp == fingerprint


def manifest_get_mtime(manifest, console_id, profile, title_id):
	stored_fp, stored_mtime = manifest_get_entry(manifest, console_id, profile, title_id)
	return stored_mtime


def manifest_get_name(manifest, console_id, profile, title_id):
	mk = manifest_profile_key(profile)
	return manifest.get('name:{}:{}:{}'.format(console_id, mk, title_id), title_id)


def manifest_get_any_mtime(manifest, profile, title_id):
	mk = manifest_profile_key(profile)
	suffix = ':{}:{}'.format(mk, title_id)
	best = 0
	for key, value in manifest.items():
		if key.startswith('name:') or not key.endswith(suffix):
			continue
		if '|' in value:
			parts = value.split('|', 1)
			mtime = int(parts[1]) if parts[1].isdigit() else 0
			if mtime > best:
				best = mtime
	return best


# Functions
def prepare_nas(dialog_prepare = None):
	if dialog_prepare:
		dialog_prepare.update(5, 'Checking local folder...')
	if not is_configured():
		if dialog_prepare:
			dialog_prepare.update(0, 'Local folder not set', 'Open Settings first')
			sleep(1000)
			dialog_prepare.update(0, 'Local folder not set', 'check settings')
			close_notification_dialog(dialog_prepare)
		else:
			notify('Local folder not configured')
		return None, None, None, None, None, None, None
	share_root = get_local_base()
	nas_base = share_root
	create_dir(share_root.rstrip('\\/'))
	log('local_base: {}'.format(share_root))

	if dialog_prepare:
		dialog_prepare.update(15, 'Reading console ID...')
	console_id = read_console_id(dialog_prepare)
	if not console_id:
		if dialog_prepare:
			dialog_prepare.update(0, 'Could not read console ID')
			close_notification_dialog(dialog_prepare)
		notify('Could not read console ID')
		return None, None, None, None, None, None, None

	nas_root = get_nas_root(nas_base, console_id)
	profile_key = active_profile()[0][0]
	sysinfo = parse_sysinfo()
	hdd_key_hex = sysinfo['hdd_key'].replace(':', '').replace(' ', '').upper()
	mac_hex = parse_sysinfo_mac(sysinfo)
	log('mac_hex: {}'.format(mac_hex))
	return share_root, nas_base, console_id, nas_root, load_manifest(nas_root, profile_key), hdd_key_hex, mac_hex


def sync(force_mode, silent = False):
	create_dir(OUTPUT_DIR)
	get_signers()
	canceled = False

	dialog_prepare = SilentProgress(ADDON_ID) if silent else ProgressDialog('{} - Preparing'.format(ADDON_ID))
	share_root, nas_base, console_id, nas_root, manifest, hdd_key_hex, mac_hex = prepare_nas(dialog_prepare)
	if not nas_base:
		return

	profiles = active_profile()
	grand_total = 0
	all_scans = []
	for profile_key, profile_label, profile_path in profiles:
		if dialog_prepare.is_canceled():
			close_notification_dialog(dialog_prepare)
			return
		dialog_prepare.update(40, 'Scanning saves', profile_label or profile_path)
		titles = scan_udata(profile_path)
		grand_total += len(titles)
		all_scans.append((profile_key, profile_label, titles))

	dialog_prepare.update(45, 'Scanning done', profile_label or profile_path, '{} titles, {} saves'.format(grand_total, sum(len(title['saves']) for title in titles)))
	write_report(all_scans)

	dialog_prepare.update(55, 'Setting up folders...')
	if not backend_mkdir(nas_root):
		dialog_prepare.update(100, 'Cannot create root folder', nas_root)
		close_notification_dialog(dialog_prepare)
		notify('Cannot create root folder')
		return

	for profile_key, profile_label, profile_path in profiles:
		saves_dir = get_saves_dir(nas_base, console_id, profile_key)
		if not backend_mkdir(saves_dir):
			dialog_prepare.update(100, 'Cannot create saves folder', saves_dir)
			close_notification_dialog(dialog_prepare)
			notify('Cannot create saves folder')
			return

	dialog_prepare.update(58, 'Backing up EEPROM...')
	backend_copy_up(SYSINFO_PATH, '{}{}_eeprom.ini'.format(nas_root, console_id))

	dialog_prepare.update(100, 'Ready', '{} titles'.format(grand_total))
	if not silent:
		dialog_prepare.close()

	smart_sync = not force_mode
	total_created = total_copied = total_skipped = titles_done = 0

	dialog_sync = SilentProgress(ADDON_ID, reuse = True) if silent else ProgressDialog('{} - {}'.format(ADDON_ID, 'Force Sync' if force_mode else 'Smart Sync'))
	try:
		dialog_sync.update(1, 'Force all...' if force_mode else 'Smart sync...')

		active_profile_key = active_profile()[0][0]
		manifests = {active_profile_key: manifest}
		for profile_key, profile_label, titles in all_scans:
			saves_dir = get_saves_dir(nas_base, console_id, profile_key)
			if profile_key not in manifests:
				manifests[profile_key] = load_manifest(nas_root, profile_key)
			for title in titles:
				if dialog_sync.is_canceled():
					canceled = True
					break

				title_id = title['titleId']
				title_name = title['titleName'] or title_id
				title_fp = fingerprint_title(title)
				titles_done += 1
				pct = int(100 * titles_done / max(grand_total, 1))

				manifest = manifests[profile_key]
				local_mtime = int(title_mtime(title))

				if smart_sync:
					if manifest_matches(manifest, console_id, profile_key, title_id, title_fp):
						total_skipped += 1
						dialog_sync.update(pct, 'Skipping', title_name, '{} of {}'.format(titles_done, grand_total))
						continue
					any_mtime = manifest_get_any_mtime(manifest, profile_key, title_id)
					if any_mtime and local_mtime < any_mtime:
						total_skipped += 1
						dialog_sync.update(pct, 'NAS newer - will download', title_name, '{} of {}'.format(titles_done, grand_total))
						continue

				dialog_sync.update(pct, 'Compressing...', title_name, '{} of {}'.format(titles_done, grand_total))

				zip_path = join(OUTPUT_DIR, title_id + '.zip')
				dukex_path = join(OUTPUT_DIR, title_id + '.dukex')

				if not zip_directory(title['path'], zip_path):
					dialog_sync.update(pct, 'WARNING: zip failed', title_name)
					continue

				try:
					if isfile(dukex_path):
						remove(dukex_path)
					rename(zip_path, dukex_path)
				except Exception:
					dialog_sync.update(pct, 'WARNING: rename failed', title_name)
					continue

				total_created += 1
				nas_dest = '{}{}.dukex'.format(saves_dir, title_id)
				dialog_sync.update(pct, 'Copying to {}...'.format(backend_label()), title_name, '{} of {}'.format(titles_done, grand_total))

				if backend_copy_up(dukex_path, nas_dest):
					total_copied += 1
					mk = manifest_profile_key(profile_key)
					manifests[profile_key]['{}:{}:{}'.format(console_id, mk, title_id)] = '{}|{}'.format(title_fp, int(title_mtime(title)))
					manifests[profile_key]['name:{}:{}:{}'.format(console_id, mk, title_id)] = title_name
					save_manifest_local(manifests[profile_key], profile_key)
				else:
					dialog_sync.update(pct, 'WARNING: copy failed', title_name)

				try:
					remove(dukex_path)
				except Exception:
					pass
				gc.collect()

			if canceled:
				break

		result_line = '{} copied {} skipped {} compressed'.format(total_copied, total_skipped, total_created)
		if total_copied > 0:
			for profile_key in manifests:
				save_manifest(manifests[profile_key], nas_root, profile_key)

		if silent:
			done_msg = '{} - {} copied'.format('Cancelled' if canceled else 'Done', total_copied)
			dialog_sync.update(100, safe(done_msg))
			if use_local():
				close_notification_dialog(dialog_sync)
				return
			sleep(1000)
			run_download_loop('{} - Syncing'.format(ADDON_ID), nas_base, console_id, nas_root, skip_existing = False, missing_only = True, silent = True, reuse_notification = True, manifests = manifests, hdd_key_hex = hdd_key_hex, dst_mac_hex = mac_hex)
		else:
			dialog_sync.update(100, 'Cancelled' if canceled else 'Complete', result_line)
			close_notification_dialog(dialog_sync)
			notify('{} - {} copied'.format('Cancelled' if canceled else 'Done', total_copied))
			if not canceled and not use_local():
				run_download_loop('{} - Syncing'.format(ADDON_ID), nas_base, console_id, nas_root, skip_existing = False, missing_only = True, silent = False, manifests = manifests, hdd_key_hex = hdd_key_hex, dst_mac_hex = mac_hex)
	except Exception as error:
		log('sync: error - {}'.format(error))
		close_notification_dialog(dialog_sync)


def prepare_download(silent = False):
	create_dir(OUTPUT_DIR)
	dialog_prepare = SilentProgress(ADDON_ID) if silent else ProgressDialog('{} - Preparing'.format(ADDON_ID))
	share_root, nas_base, console_id, nas_root, manifest, hdd_key_hex, mac_hex = prepare_nas(dialog_prepare)
	if not nas_base:
		return None, None, None, None, None, None
	if not silent:
		dialog_prepare.close()
	return nas_base, console_id, nas_root, hdd_key_hex, manifest, mac_hex


def get_src_console_id(manifest, profile_key, title_id):
	mk = manifest_profile_key(profile_key)
	suffix = ':{0}:{1}'.format(mk, title_id)
	for key in manifest:
		if key.startswith('name:') or not key.endswith(suffix):
			continue
		parts = key.split(':')
		if parts:
			return parts[0]
	return None


def run_download_loop(title, nas_base, console_id, nas_root, skip_existing, missing_only = False, silent = False, reuse_notification = False, manifests = None, hdd_key_hex = None, dst_mac_hex = None):
	get_signers()
	local_title_ids = set()
	try:
		for entry in listdir(UDATA_PATH):
			if isdir(join(UDATA_PATH, entry)):
				local_title_ids.add(entry)
	except Exception:
		pass

	profiles = active_profile()
	active_profile_key = profiles[0][0]
	if manifests is not None and active_profile_key in manifests:
		manifest = manifests[active_profile_key]
	else:
		manifest = load_manifest(nas_root, active_profile_key)
	all_remote = []
	for profile_key, profile_label, profile_path in profiles:
		saves_dir = get_saves_dir(nas_base, console_id, profile_key)
		for entry in backend_listdir(saves_dir):
			if not entry or entry == 'init':
				continue
			title_id = entry[:-6] if entry.endswith('.dukex') else entry
			if title_id:
				all_remote.append((profile_key, profile_path, saves_dir, title_id))

	total_remote = max(len(all_remote), 1)
	files_processed = total_pulled = 0
	canceled = False

	dialog_dl = SilentProgress(ADDON_ID, reuse = reuse_notification) if silent else ProgressDialog(title)
	dialog_dl.update(1, 'Checking for downloads...')

	for profile_key, profile_path, saves_dir, title_id in all_remote:
		if dialog_dl.is_canceled():
			canceled = True
			break

		files_processed += 1
		pct = int(100 * files_processed / total_remote)

		if title_id in local_title_ids:
			if missing_only:
				continue
			if skip_existing:
				continue
			nas_mtime = manifest_get_any_mtime(manifest, profile_key, title_id)
			if not nas_mtime:
				continue
			local_mtime = 0
			try:
				local_save_path = join(UDATA_PATH, title_id)
				for root, dirs, files in walk(local_save_path):
					for fname in files:
						try:
							mtime = stat(join(root, fname)).st_mtime
							if mtime > local_mtime:
								local_mtime = mtime
						except Exception:
							pass
			except Exception:
				pass
			if local_mtime >= nas_mtime:
				continue

		title_name = manifest_get_name(manifest, console_id, profile_key, title_id)
		dialog_dl.update(pct, 'Downloading', title_name, '{} of {}'.format(files_processed, total_remote))
		dukex_path = join(OUTPUT_DIR, title_id + '.dukex')

		if backend_copy_down('{}{}.dukex'.format(saves_dir, title_id), dukex_path):
			if unzip_to_dir(dukex_path, join(profile_path, title_id)):
				total_pulled += 1
				local_title_ids.add(title_id)
				src_console_id = get_src_console_id(manifest, profile_key, title_id)
				if src_console_id and src_console_id != console_id:
					src_eeprom = '{}{}_eeprom.ini'.format(nas_root, src_console_id)
					local_eeprom = join(OUTPUT_DIR, '{}_eeprom.ini'.format(src_console_id))
					backend_copy_down(src_eeprom, local_eeprom)
					src_mac_hex = read_eeprom_mac(local_eeprom)
					src_hdd_hex = read_eeprom_hdd_key(local_eeprom)
					try:
						if isfile(local_eeprom):
							remove(local_eeprom)
					except Exception as error:
						log('run_download_loop: eeprom cleanup - {}'.format(error))
					dialog_dl.update(pct, 'Signing...', title_name, '{} of {}'.format(files_processed, total_remote))
					save_resinger(title_id, join(profile_path, title_id), hdd_key_hex, src_mac_hex = src_mac_hex, dst_mac_hex = dst_mac_hex, src_hdd_hex = src_hdd_hex)
				dialog_dl.update(pct, 'Synced', title_name, '{} of {}'.format(files_processed, total_remote))
			else:
				dialog_dl.update(pct, 'WARNING: extract failed', title_name)
			try:
				remove(dukex_path)
			except Exception:
				pass
		else:
			dialog_dl.update(pct, 'WARNING: download failed', title_name)

	if silent:
		done_msg = '{} - {} synced'.format('Cancelled' if canceled else 'Done', total_pulled)
		dialog_dl.update(100, safe(done_msg))
		close_notification_dialog()
	else:
		dialog_dl.update(100, 'Cancelled' if canceled else 'Complete', '{} save(s) synced'.format(total_pulled))
		close_notification_dialog(dialog_dl)
		notify('{} - {} synced'.format('Cancelled' if canceled else 'Done', total_pulled))


def download(silent = False):
	nas_base, console_id, nas_root, hdd_key_hex, manifest, mac_hex = prepare_download(silent = silent)
	if not nas_base:
		return
	profile_key = active_profile()[0][0]
	run_download_loop('{} - Restore Missing'.format(ADDON_ID), nas_base, console_id, nas_root, skip_existing = False, missing_only = True, silent = silent, hdd_key_hex = hdd_key_hex, manifests = {profile_key: manifest}, dst_mac_hex = mac_hex)


def restore(silent = False):
	nas_base, console_id, nas_root, hdd_key_hex, manifest, mac_hex = prepare_download(silent = silent)
	if not nas_base:
		return
	profile_key = active_profile()[0][0]
	run_download_loop('{} - Restore All'.format(ADDON_ID), nas_base, console_id, nas_root, skip_existing = False, silent = silent, hdd_key_hex = hdd_key_hex, manifests = {profile_key: manifest}, dst_mac_hex = mac_hex)


# Menu

def show_menu():
	while True:
		executebuiltin('Dialog.Close(1100,true)')
		executebuiltin('Dialog.Close(1112,true)')
		choice = Dialog().select(ADDON_ID, [
			'Smart Sync Saves',
			'Restore Missing Saves',
			'+ Advanced',
			'Settings',
			'View Information',
		])
		if choice < 0:
			break
		elif choice == 0:
			sync(force_mode = False)
		elif choice == 1:
			download()
		elif choice == 2:
			adv_options = [
				'Replace Saves - {}'.format(backend_label()),
				'Restore Saves From {}'.format(backend_label()),
			]
			adv_choice = Dialog().select('{} - Advanced'.format(ADDON_ID), adv_options)
			if adv_choice == 0:
				if Dialog().yesno(
					'Replace Saves - {}'.format(backend_label()), '',
					'Logged in as: {}[CR]This will replace any matching {} saves.[CR]Are you sure?'.format(getInfoLabel('System.ProfileName'), backend_label()),
					'', getLocalizedString(222), getLocalizedString(107)
				):
					sync(force_mode = True)
			elif adv_choice == 1:
				if Dialog().yesno(
					'Restore Saves From {}'.format(backend_label()), '',
					'This will overwrite any matching local saves.[CR]Are you sure?',
					'', getLocalizedString(222), getLocalizedString(107)
				):
					restore()
		elif choice == 3:
			open_settings()
		elif choice == 4:
			executebuiltin('TextViewer({}\\info.txt,{} Information by Rocky5)'.format(ROOT_DIR, ADDON_ID))
			sleep(1000)
			while getCondVisibility('Window.IsActive(147)'):
				sleep(500)


def main():
	force_mode, smart_mode, silent_mode, download_mode, restore_mode, settings_mode = parse_args()
	create_dir(OUTPUT_DIR)

	try:
		if settings_mode:
			open_settings()
		elif force_mode:
			sync(force_mode = True, silent = silent_mode)
		elif smart_mode or silent_mode:
			sync(force_mode = False, silent = silent_mode)
		elif download_mode:
			download(silent = silent_mode)
		elif restore_mode:
			restore(silent = silent_mode)
		else:
			show_menu()
	except Exception:
		error_message = traceback.format_exc()
		log('FATAL: {}'.format(error_message))
		try:
			Dialog().ok('{} Error'.format(ADDON_ID), error_message[:200])
		except Exception:
			pass


if __name__ == '__main__':
	main()
	gc.collect()
