# -*- coding: utf-8 -*-
"""
service.alfaxbox.netclient
===========================

Ver addon.xml para el motivo completo (bisecado en produccion el 26/09/2026, NOTAS-PENDIENTE-2026-09-21.md #36):
combinar una llamada de red bloqueante con xbmcaddon.Addon()/xbmcgui en el MISMO interprete de Python de esta
build de XBMC4Xbox corrompe algo que revienta minutos despues en el cierre de OTRO interprete cualquiera. La
salida elegida no es perseguir esa corrupcion en el motor (ya se intento varias rondas sin exito, ver las notas)
sino partir la combinacion en dos procesos: este servicio SOLO hace red (nunca importa xbmcgui ni xbmcaddon) y
plugin.video.alfaxbox SOLO hace GUI (ya no abre un socket el mismo, ni siquiera para resolver el nombre NBNS del
mini PC). Ninguno de los dos vuelve a combinar las dos cosas que, juntas, provocan el crash.

Protocolo (fichero por peticion, sin memoria compartida entre procesos distintos):
    special://profile/addon_data/service.alfaxbox.netclient/requests/<id>.json
        {"backend": "core"|"downloads"|"invidious", "path": "/alfa/list", "params": {...}, "timeout": 170}
        {"backend": "direct", "host": "api.open-meteo.com", "port": 80, "path": "/v1/forecast", "params": {...}}
    special://profile/addon_data/service.alfaxbox.netclient/responses/<id>.json
        {"code": 200, "json": {...}}    (code=0 si no se pudo contactar con el destino en absoluto)

plugin.video.alfaxbox (ver resources/lib/bridge.py) escribe la peticion, espera a que aparezca la respuesta
sondeando el fichero (sin red, sin socket - solo os.path.exists) y la borra al leerla. Este servicio sondea la
carpeta de peticiones y hace el GET crudo por socket, exactamente igual que antes lo hacia cada addon por su
cuenta - solo que ahora en un proceso que nunca toca xbmcgui/xbmcaddon. Los backends "core"/"downloads"/
"invidious" resuelven el nombre NBNS del mini PC (con la misma cache de 60s que antes tenia bridge.py); el
backend "direct" (usado por weather.openmeteo, ver #42 en NOTAS-PENDIENTE-2026-09-21.md) habla directamente con
el host/puerto que venga en la peticion, sin NBNS - para addons que hablan con internet, no con el mini PC. A
pesar del nombre ("alfaxbox"), este servicio ya es un rele de red generico para cualquier addon de la consola
que necesite evitar la misma combinacion peligrosa (red + xbmcgui/xbmcaddon en el mismo interprete) - no vale la
pena renombrarlo (reinstalar el addon bajo otro id) solo por el nombre.
"""
from __future__ import unicode_literals

import json
import os
import socket
import time

import xbmc

from nbnsresolve import resolve_netbios_name

_MINIPC_NETBIOS_NAME = "XBOXMINIPC"
_FALLBACK_IP = "192.168.1.134"
CORE_PORT = 3004
DOWNLOADS_PORT = 3006
# Puerto de invidious-download (mismo mini PC, ver plugin.video.invidious/resources/lib/invidious.py) - AlfaXbox lo
# consulta tambien para fusionar sus trabajos en el panel "Descargas" del boton de Inicio (ver bridge.invidious_jobs()).
INVIDIOUS_PORT = 3002
BACKEND_PORTS = {"core": CORE_PORT, "downloads": DOWNLOADS_PORT, "invidious": INVIDIOUS_PORT}

_BASE_DIR = xbmc.translatePath("special://profile/addon_data/service.alfaxbox.netclient/")
REQUESTS_DIR = os.path.join(_BASE_DIR, "requests")
RESPONSES_DIR = os.path.join(_BASE_DIR, "responses")
# bridge.py lo lee directamente (sin pasar por peticion/respuesta) para construir las URL de video/caratulas que
# se le dan a XBMC (stream_url()/image_url()) - esas URL las pide luego el propio reproductor/skin de Kodi por su
# cuenta, nunca nuestro Python, asi que no hace falta el protocolo de arriba para ellas - solo saber la IP.
HOST_FILE = os.path.join(_BASE_DIR, "host.txt")

_HOST_CACHE_SECONDS = 60
_host_cache = {"ip": None, "at": 0.0}

# Cuanto se sondea la carpeta de peticiones entre una vuelta y otra - pequeno a proposito: la latencia que anade
# este sondeo se suma a cada llamada de bridge.py, y el usuario la nota al navegar.
POLL_INTERVAL_SECONDS = 0.1


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log("service.alfaxbox.netclient: " + msg, level)


def _host():
    if _host_cache["ip"] and (time.time() - _host_cache["at"]) < _HOST_CACHE_SECONDS:
        return _host_cache["ip"]
    try:
        ip = resolve_netbios_name(_MINIPC_NETBIOS_NAME)
    except Exception as e:
        _log("fallo resolviendo {}: {}".format(_MINIPC_NETBIOS_NAME, e))
        ip = None
    ip = ip or _FALLBACK_IP
    _host_cache["ip"], _host_cache["at"] = ip, time.time()
    if ip != _host_cache.get("written"):
        try:
            _atomic_write(HOST_FILE, ip.encode("ascii"))
            _host_cache["written"] = ip
        except OSError as e:
            _log("no se pudo escribir {}: {}".format(HOST_FILE, e), xbmc.LOGWARNING)
    return ip


def _http_get(host, port, path, timeout):
    """GET crudo por socket, sin urllib2/httplib (mismo motivo de siempre: httplib carga "ssl" incondicionalmente,
    y ese modulo no se lleva bien con el cierre de varios sub-interpretes de Python a la vez en este fork)."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect((host, port))
        request = "GET {} HTTP/1.0\r\nHost: {}\r\nConnection: close\r\n\r\n".format(path, host)
        sock.sendall(request.encode("ascii"))
        chunks = []
        while True:
            chunk = sock.recv(4096)
            if not chunk:
                break
            chunks.append(chunk)
    finally:
        sock.close()
    response = b"".join(chunks)
    header_end = response.find(b"\r\n\r\n")
    if header_end == -1:
        raise IOError("respuesta HTTP de {}:{}{} sin cabeceras completas".format(host, port, path))
    status_line = response[:header_end].split(b"\r\n", 1)[0]
    parts = status_line.split(b" ", 2)
    code = int(parts[1]) if len(parts) >= 2 else 0
    return code, response[header_end + 4:]


def _atomic_write(path, data):
    """os.rename() en esta build (Xbox/CRT al estilo Windows) NO sobreescribe si el destino ya existe -
    a diferencia de Unix, donde rename() es atomico incluso sobre un fichero existente. Confirmado en
    produccion (26/09/2026): "[Errno 17] File exists" al reescribir host.txt en su segunda vuelta. Se borra
    el destino antes (si existe) y luego se renombra - dos pasos en vez de uno solo, ya no es atomico del
    todo, pero es el mismo patron que ya usa _process_request() unas lineas mas abajo."""
    tmp = path + ".tmp-{}".format(os.getpid())
    with open(tmp, "wb") as f:
        f.write(data)
    try:
        os.remove(path)
    except OSError:
        pass
    os.rename(tmp, path)


def _write_response(request_id, code, body_json):
    _atomic_write(os.path.join(RESPONSES_DIR, request_id + ".json"),
                  json.dumps({"code": code, "json": body_json}, ensure_ascii=False).encode("utf-8"))


def _process_request(name):
    request_id = name[:-len(".json")]
    req_path = os.path.join(REQUESTS_DIR, name)
    try:
        with open(req_path, "rb") as f:
            req = json.loads(f.read().decode("utf-8"))
    except (OSError, ValueError) as e:
        _log("peticion illegible {}: {}".format(name, e), xbmc.LOGWARNING)
        try:
            os.remove(req_path)
        except OSError:
            pass
        return
    try:
        os.remove(req_path)      # se borra ANTES de contestar: si el plugin ya se fue, no hace falta reintentar nada
    except OSError:
        pass

    backend = req.get("backend", "core")
    path = req.get("path", "/")
    params = req.get("params") or {}
    timeout = req.get("timeout", 15)
    if params:
        try:
            from urllib import urlencode         # Python 2
        except ImportError:
            from urllib.parse import urlencode    # noqa: F401 (por si algun dia corre en Python 3)
        path = "{}?{}".format(path, urlencode(params))

    if backend == "direct":
        # Para addons que hablan con internet, no con el mini PC (ver weather.openmeteo) - host/puerto vienen
        # en la propia peticion, sin NBNS.
        host = req.get("host", "")
        port = req.get("port", 80)
        target_desc = "{}:{}".format(host, port)
        fail_msg = "No se pudo contactar con {} ({{}}).".format(host)
    else:
        port = BACKEND_PORTS.get(backend, CORE_PORT)
        host = _host()
        target_desc = "{}:{} ({})".format(host, port, backend)
        fail_msg = "No se pudo contactar con el mini PC ({}). Comprueba que esta encendido y que el servicio esta activo."

    try:
        code, body = _http_get(host, port, path, timeout)
    except Exception as e:  # noqa: BLE001 - una peticion mala nunca debe tirar el servicio
        _log("error de red hablando con {}: {}".format(target_desc, e), xbmc.LOGWARNING)
        _write_response(request_id, 0, {"error": fail_msg.format(e)})
        return
    try:
        parsed = json.loads(body.decode("utf-8"))
    except ValueError:
        parsed = {"error": "Respuesta no valida del mini PC (HTTP {})".format(code)}
    _write_response(request_id, code, parsed)


def main():
    for d in (REQUESTS_DIR, RESPONSES_DIR):
        if not os.path.isdir(d):
            os.makedirs(d)
    # Peticiones huerfanas de una sesion anterior (la consola se apago con alguna a medias) - nadie las va a leer.
    for name in os.listdir(REQUESTS_DIR):
        try:
            os.remove(os.path.join(REQUESTS_DIR, name))
        except OSError:
            pass

    _host()      # deja host.txt listo desde el arranque, sin esperar a la primera peticion de bridge.py
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        try:
            names = [n for n in os.listdir(REQUESTS_DIR) if n.endswith(".json")]
        except OSError:
            names = []
        for name in names:
            try:
                _process_request(name)
            except Exception as e:  # noqa: BLE001
                _log("fallo procesando {}: {}".format(name, e), xbmc.LOGERROR)
        if not names:
            _host()      # sin peticiones que lo disparen, refresca la cache/host.txt igualmente cada 60s
        if monitor.waitForAbort(POLL_INTERVAL_SECONDS):
            break


if __name__ == "__main__":
    main()
