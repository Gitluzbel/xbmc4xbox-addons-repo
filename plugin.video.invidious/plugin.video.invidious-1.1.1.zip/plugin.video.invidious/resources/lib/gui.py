import os
import sys
import urllib
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

ADDON_HANDLE = int(sys.argv[1])
ADDON_VFS_PATH = sys.argv[0]

addon = xbmcaddon.Addon()


def add_item(
    title,
    icon=None,
    thumb=None,
    url=None,
    url_params=None,
    video_infotag=None,
    video_duration=None,
    is_folder=True,
    total_items=0,
):
    item = xbmcgui.ListItem(title)

    art = {}
    if icon:
        art["icon"] = os.path.join(
            addon.getAddonInfo("path"), "resources", "media", icon
        )
    if thumb:
        art["thumb"] = thumb
    item.setArt(art)

    if not url:
        url = "{}?{}".format(ADDON_VFS_PATH, urllib.urlencode(url_params))

    if video_infotag is not None:
        is_folder = False
        item.setInfo("video", video_infotag)
        item.setProperty("IsPlayable", "True")

    if video_duration:
        item.addStreamInfo("video", {"duration": video_duration})

    return xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, item, is_folder, total_items)


def end_listing():
    return xbmcplugin.endOfDirectory(ADDON_HANDLE)


def cancel_resolve():
    """Cuando un clic en un video dispara el flujo OnPlayMedia de Kodi,
    la consola muestra un dialogo de "cargando" (circulo girando) hasta
    que el addon resuelve una URL reproducible con setResolvedUrl() -
    si play() decide no reproducir nada (el usuario eligio "Descargar",
    o cancelo el dialogo Ver/Descargar, o no hay stream disponible),
    ese circulo se queda girando para siempre si nunca se llama a nada.
    Esto le dice a Kodi "no hay nada que reproducir, deja de esperar",
    sin item real, para que el dialogo se cierre al momento."""
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())


def play(url, title=None, video_infotag=None, video_duration=None, thumb=None):
    item = xbmcgui.ListItem(title, path=url)

    # Without this, the resolved item has no metadata at all, so the
    # player (and anything reading it, like the LCD template's
    # VideoPlayer.Title/Artist) has nothing to show but the raw video
    # ID from the URL. Note this does NOT help with remaining-time or
    # the progress bar for invidious-remux streams - those come from
    # g_application.GetTotalTime() in the C++ core, which only knows
    # what the demuxer detects from the file itself, and empty_moov
    # streams never carry a duration there no matter what the
    # ListItem says. See service.invidious.lcd for how that's handled
    # instead (set_known_duration below is its counterpart).
    if video_infotag is not None:
        item.setInfo("video", video_infotag)

    if video_duration:
        item.addStreamInfo("video", {"duration": video_duration})

    # add_item() ya hace esto para los items del listado, pero play()
    # nunca lo hizo para el item resuelto - confirmado (control remoto,
    # /coverdebug) que Player.Art(thumb) sale vacio de todas formas
    # cuando el video se reproduce con una URL directa de googlevideo.com
    # (sin pasar por invidious-remux), asi que ademas se manda por
    # set_known_thumbnail() como propiedad de ventana, igual que ya se
    # hace con la duracion.
    if thumb:
        item.setArt({"thumb": thumb})

    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, item)


def set_known_duration(seconds):
    """
    Hands the real duration (from Invidious' own metadata, not the
    file) to service.invidious.lcd via a global window property, since
    invidious-remux streams never carry it in the container itself.
    See that addon's default.py for the full explanation and the
    reading side of this.
    """
    if seconds:
        xbmcgui.Window(10000).setProperty("InvidiousLength", str(seconds))


def set_known_thumbnail(url):
    """
    Misma idea que set_known_duration(): manda la miniatura del video
    (de los propios metadatos de Invidious) via una propiedad de
    ventana compartida, para que service.xbox.remotecontrol la pueda
    leer aunque Player.Art(thumb)/VideoPlayer.Cover salgan vacios -
    confirmado que eso pasa siempre que el video se reproduce con una
    URL directa de googlevideo.com en vez de via invidious-remux.
    """
    if url:
        xbmcgui.Window(10000).setProperty("InvidiousThumbnail", url)


def notification(heading, message, time=5000):
    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_INFO, time)


def get_search_input(heading, default_text=""):
    keyboard = xbmc.Keyboard(default_text, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    return None
