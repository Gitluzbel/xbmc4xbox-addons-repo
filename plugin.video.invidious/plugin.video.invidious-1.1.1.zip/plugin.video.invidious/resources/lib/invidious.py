# -*- coding: utf-8 -*-
import time
import urllib

import xbmc
import gui

import requests

from .storage import load_storage, sync_storage


PUBLIC_INSTANCES_URL = "https://api.invidious.io/instances.json?sort_by=type,users"
PUBLIC_INSTANCES_CACHE_SECONDS = 30 * 60
REQUEST_TIMEOUT = 5

# Own instance (and any manually configured fallback_instances) get a
# much more generous timeout than public ones: the upstream addon
# (github.com/antonic901/plugin.video.invidious) sets NO timeout at
# all on its requests.get() calls, so it simply waits however long a
# self-hosted server needs to answer. A self-hosted instance can
# legitimately take a while under load (or right after waking up from
# whatever caused it to need a restart) without being actually down -
# confirmed on real hardware: the original addon (no timeout) reaches
# a local server fine over the same cable/network where this fork's
# flat 5s REQUEST_TIMEOUT gives up and reports "timed out". Public
# instances don't get this treatment: we don't control them, a slow
# one is as good as a down one from our side, and it would only delay
# falling back to a working candidate.
LOCAL_REQUEST_TIMEOUT = 20

# Port of the invidious-remux helper (see the separate invidious_remux.py
# service) - a small companion service that lives on the SAME machine as
# the self-hosted instance, muxing adaptiveFormats' separate video+audio
# into one playable MP4 for videos that have no formatStreams. Only a
# self-hosted instance can have this helper running next to it; public
# instances never do, so it is always built from the configured own
# instance (see InvidiousAPI.build_remux_url), never from whichever
# instance last happened to answer a request.
REMUX_PORT = 3001

# Puerto de invidious-download, el hermano de invidious-remux para la
# opcion "Descargar" del addon: en vez de servir el remux en directo a
# la Xbox (como hace REMUX_PORT), descarga video+audio en paralelo en
# el propio mini PC y sube el MP4 terminado a F:\Videos\ de la Xbox por
# FTP - ver ese proyecto para el porque de la descarga en paralelo.
DOWNLOAD_JOB_PORT = 3002

# Same default as settings.xml (that one stays a fixed IP - it's static
# XML, can't run code). Some old XBMC-style addon systems return "" from
# getSetting() instead of the XML-declared default until the user has
# opened this addon's settings screen at least once - without this
# fallback, a fresh install with untouched settings ends up with no
# instance at all (own server empty, and if the same applies to
# use_public_fallback, no public fallback either), so every request
# fails and nothing ever shows up in any category or in search.
#
# 11/09/2026: resuelve el mini PC por nombre NetBIOS (NBNS, ver
# script.module.nbnsresolve) en vez de una IP fija - si la resolucion
# falla (mini PC apagado, timing raro justo al arrancar...) cae al mismo
# valor fijo de siempre como ultimo recurso.
_DEFAULT_INSTANCE_FALLBACK_IP = "192.168.1.134"
_MINIPC_NETBIOS_NAME = "XBOXMINIPC"


def _default_instance():
    try:
        from nbnsresolve import resolve_netbios_name
        ip = resolve_netbios_name(_MINIPC_NETBIOS_NAME)
    except Exception as e:
        xbmc.log("plugin.video.invidious: fallo resolviendo {} por NBNS: {}".format(_MINIPC_NETBIOS_NAME, e), xbmc.LOGDEBUG)
        ip = None
    if ip:
        xbmc.log("plugin.video.invidious: {} resuelto por NBNS a {}".format(_MINIPC_NETBIOS_NAME, ip), xbmc.LOGDEBUG)
    else:
        xbmc.log("plugin.video.invidious: NBNS no respondio, usando IP de respaldo {}".format(_DEFAULT_INSTANCE_FALLBACK_IP), xbmc.LOGDEBUG)
    return "http://{}:3000".format(ip or _DEFAULT_INSTANCE_FALLBACK_IP)

# instances.json's "type": "https" only means "served over HTTPS", not
# "reachable from a normal internet connection" - some listed instances
# are only reachable over an alternative/overlay network (Yggdrasil,
# I2P, Tor), and a plain DNS lookup for those from a regular connection
# just fails outright ("getaddrinfo failed" in the log). Reject hosts
# ending in these suffixes so we don't waste a request attempt (and the
# 5s timeout that goes with it) on something that can never resolve.
UNREACHABLE_HOST_SUFFIXES = (".ygg", ".onion", ".i2p")

# Module-level cache so we don't hit api.invidious.io on every failed
# request. Persists for the life of the script host process (the addon
# is registered with reuselanguageinvoker="true").
_public_instances_cache = {"fetched_at": 0, "instances": []}

# Remembers instances that failed recently so _make_request() can skip
# them outright on the next call instead of re-attempting (and
# re-timing-out on) a host that is known to be down right now. This is
# deliberately generic rather than trying to guess more hostname
# patterns like UNREACHABLE_HOST_SUFFIXES below - that list only
# catches instances that follow a naming convention (real .onion/.i2p
# domains do, but e.g. a Yggdrasil-only instance named
# "inv-ygg.example.com" does not: "ygg" appears in a sub-label, not as
# the actual suffix, so it slips through and gets retried - complete
# with its own DNS timeout - on every single search/video load).
# Any instance can go down for any reason, so remembering actual
# failures covers all of them, not just the ones whose name happens to
# hint at it.
#
# Persisted to disk via storage.py (addon_data/.../bad_instances.json)
# rather than kept in a plain module-level dict: despite
# reuselanguageinvoker="true" in addon.xml (which is supposed to reuse
# one Python interpreter, keeping module state alive between calls),
# real-world logs from this Xbox show the SAME instance timing out
# twice in a row well inside the cooldown window - i.e. a fresh
# navigation was not seeing the previous call's in-memory cache entry
# at all. Whatever the exact cause on this particular build, a plain
# dict clearly isn't surviving between invocations here, so this needs
# to live on disk to actually do its job.
BAD_INSTANCES_STORAGE = "bad_instances"
BAD_INSTANCE_COOLDOWN_SECONDS = 5 * 60


def _load_bad_instances():
    storage = load_storage(BAD_INSTANCES_STORAGE)
    return storage if storage else {}


def _filter_known_bad(candidates):
    bad = _load_bad_instances()
    now = time.time()
    return [
        u for u in candidates
        if now - bad.get(u, 0) >= BAD_INSTANCE_COOLDOWN_SECONDS
    ]


def _mark_bad(base_url):
    bad = _load_bad_instances()
    bad[base_url] = time.time()
    sync_storage(BAD_INSTANCES_STORAGE, bad)


def _is_reachable_uri(uri):
    host = uri.split("://", 1)[-1].split("/", 1)[0].split(":", 1)[0].lower()
    return not host.endswith(UNREACHABLE_HOST_SUFFIXES)


def _fetch_public_instances():
    now = time.time()
    cached = _public_instances_cache["instances"]
    if cached and now - _public_instances_cache["fetched_at"] < PUBLIC_INSTANCES_CACHE_SECONDS:
        return cached

    try:
        response = requests.get(PUBLIC_INSTANCES_URL, timeout=REQUEST_TIMEOUT)
        data = response.json()
    except Exception as e:
        xbmc.log(
            "Invidious: could not fetch public instance list: {}".format(str(e)),
            level=xbmc.LOGERROR,
        )
        return cached

    candidates = []
    for _, info in data:
        if info.get("type") != "https":
            continue
        # instances that explicitly advertise api=false have been seen to
        # reject third-party API use (this addon), so skip them
        if info.get("api") is False:
            continue
        stats = info.get("stats") or {}
        playback = stats.get("playback") or {}
        ratio = playback.get("ratio")
        # skip instances whose own reported playback success ratio is bad;
        # None means "unknown", which we still allow as a candidate
        if ratio is not None and ratio < 0.5:
            continue
        uri = info.get("uri")
        if uri and _is_reachable_uri(uri):
            candidates.append(uri.rstrip("/"))

    _public_instances_cache["instances"] = candidates[:3]
    _public_instances_cache["fetched_at"] = now
    return _public_instances_cache["instances"]


class InvidiousAPI:
    def __init__(self, addon):
        self.addon = addon
        self.region = addon.getSetting("region")
        # Anything other than the literal "false" is treated as enabled,
        # so an empty/unset value (see DEFAULT_INSTANCE comment above)
        # still gets the intended default of "on".
        self.use_public_fallback = addon.getSetting("use_public_fallback") != "false"

        primary = addon.getSetting("instance")
        # Vacio (el quirk de Kodi de la nota de arriba) O exactamente el
        # valor estatico que trae settings.xml de fabrica (que el usuario
        # nunca ha tocado, no algo que el mismo haya escrito a mano) -> se
        # resuelve por NetBIOS en vez de confiar en la IP fija de esa
        # plantilla estatica.
        if not primary or primary == "http://{}:3000".format(_DEFAULT_INSTANCE_FALLBACK_IP):
            primary = _default_instance()

        fallback_raw = addon.getSetting("fallback_instances") or ""
        fallback_list = [u.strip() for u in fallback_raw.split(",") if u.strip()]

        self.instances = []
        seen = set()
        for u in [primary] + fallback_list:
            u = (u or "").rstrip("/")
            if u and u not in seen:
                seen.add(u)
                self.instances.append(u)

        # base URL used for e.g. relative thumbnail paths; kept in sync
        # with whichever instance last actually answered a request
        self.url = self.instances[0] if self.instances else ""

    def _try_instance(self, base_url, path, params, headers, timeout):
        try:
            response = requests.get(
                base_url + path, headers=headers, params=params, timeout=timeout
            )
            if response.status_code != 200:
                # A response was received at all, which already proves
                # the instance is up and reachable - a non-200 here
                # (e.g. "This video is not available") is about THIS
                # request/content, not the server's health, so it must
                # NOT mark the whole instance bad. Confirmed on real
                # hardware: one video-specific 500 poisoned the cache
                # for the configured own instance for the full 5-minute
                # cooldown, breaking search and every other video too
                # even though the server was perfectly healthy the
                # whole time. Only genuine connectivity failures
                # (below, in the except branch) should do that.
                xbmc.log(
                    "Invidious: instance '{}' answered '{}' with HTTP {}".format(
                        base_url, path, response.status_code
                    ),
                    level=xbmc.LOGNOTICE,
                )
                return None
            return response.json()
        except Exception as e:
            xbmc.log(
                "Invidious: instance '{}' failed: {}".format(base_url, str(e)),
                level=xbmc.LOGWARNING,
            )
            _mark_bad(base_url)
            if base_url in self.instances:
                # Only for the configured own/fallback instance(s), not
                # for public ones - a public instance failing is normal
                # background noise, but the user's own server going
                # into the 5-minute cooldown is worth a heads-up, since
                # otherwise every subsequent video/search just silently
                # fails with no clue why until the cooldown clears.
                gui.notification(
                    "Invidious",
                    "Tu servidor propio no respondió, bloqueado 5 minutos antes de reintentar",
                )
            return None

    def _make_request(self, path, params=None, headers=None, is_valid=None):
        if not headers:
            headers = {"accept": "application/json", "user-agent": "xbox-youtube"}

        # Own instance(s) tried first (local network, no internet
        # round-trip, and under our own control); public instances are
        # only used as a fallback if none of ours answer this request -
        # e.g. the local server's machine is off or the addon isn't
        # reachable from wherever the Xbox is right now.
        candidates = list(self.instances)
        if self.use_public_fallback:
            candidates += [u for u in _fetch_public_instances() if u not in candidates]

        # Skip candidates that failed recently (see BAD_INSTANCES_STORAGE
        # above) instead of re-attempting - and re-timing-out on - a
        # host that's known to be down right now.
        #
        # NOTE: an earlier version of this fell back to the unfiltered
        # list whenever filtering left nothing to try, meant to guard
        # against a one-off blip marking everything bad by mistake.
        # In practice that fallback fired on EVERY call whenever the
        # only couple of candidates (own instance + the one public
        # instance that survived UNREACHABLE_HOST_SUFFIXES filtering)
        # were both genuinely down for a while - defeating the whole
        # point of remembering failures, since it retried - and
        # re-timed-out on - the exact same dead hosts on every single
        # video/search regardless (confirmed in an actual xbmc.log: the
        # same two hosts failing again 59s after the first failure,
        # still well inside the cooldown). Failing fast here instead:
        # if everything we know of is bad, don't retry any of it until
        # the cooldown clears.
        candidates = _filter_known_bad(candidates)
        if not candidates:
            xbmc.log(
                "Invidious: all known instances failed recently for '{}', "
                "not retrying until the cooldown clears".format(path),
                level=xbmc.LOGWARNING,
            )
            return None

        # best_effort_* remembers the first technically-successful reply
        # (200 + parseable JSON) even if it fails is_valid, so a caller
        # that cares about more than "did the request succeed" (e.g.
        # get_video_information() below, which wants formatStreams
        # specifically) can still get SOMETHING back to work with (its
        # own fallback logic - see play() in router.py, which falls
        # back to dashUrl) if literally no candidate has a fully valid
        # answer, instead of losing the reply entirely.
        best_effort_result = None
        best_effort_url = None

        for base_url in candidates:
            timeout = LOCAL_REQUEST_TIMEOUT if base_url in self.instances else REQUEST_TIMEOUT
            result = self._try_instance(base_url, path, params, headers, timeout)
            if result is None:
                continue

            if is_valid is not None and not is_valid(result):
                # Technically a successful reply, but not good enough to
                # stop here - e.g. video info with no formatStreams.
                # Keep trying other candidates in case one of them has a
                # better answer (this is exactly the case that broke
                # when own-instance-first started accepting its own
                # incomplete reply as final instead of falling through
                # to a public instance that might have had the stream).
                if best_effort_result is None:
                    best_effort_result = result
                    best_effort_url = base_url
                xbmc.log(
                    "Invidious: instance '{}' answered but result wasn't "
                    "good enough for '{}', trying next candidate".format(base_url, path),
                    level=xbmc.LOGNOTICE,
                )
                continue

            if base_url != self.url:
                xbmc.log(
                    "Invidious: using instance '{}'".format(base_url),
                    level=xbmc.LOGNOTICE,
                )
            self.url = base_url
            return result

        if best_effort_result is not None:
            xbmc.log(
                "Invidious: no instance had a fully valid answer for '{}', "
                "using the best-effort reply from '{}'".format(path, best_effort_url),
                level=xbmc.LOGWARNING,
            )
            self.url = best_effort_url
            return best_effort_result

        xbmc.log(
            "Invidious: all instances (public and own) failed for '{}'".format(path),
            level=xbmc.LOGERROR,
        )
        return None

    def format_thumbnail(self, thumb):
        if "http" in thumb:
            return thumb
        return "{}{}".format(self.url, thumb)

    def build_remux_url(self, video_id, resolution):
        """
        URL of the invidious-remux helper for a video with no
        formatStreams - see the REMUX_PORT comment above for why this
        always comes from the configured own instance, never self.url.
        Returns None if no own instance is configured at all.
        """
        if not self.instances:
            return None

        own = self.instances[0]
        scheme, rest = own.split("://", 1)
        host = rest.split("/", 1)[0].split(":", 1)[0]

        return "{}://{}:{}/remux/{}?resolution={}".format(
            scheme, host, REMUX_PORT, video_id, resolution
        )

    def build_download_job_url(self, video_id, resolution, filename):
        """
        URL para lanzar un trabajo de descarga en segundo plano en
        invidious-download (mismo mini PC que el propio servidor). El
        propio servicio se encarga de todo: descargar, remezclar y
        copiar el resultado a F:\\Videos\\ de la Xbox por FTP - esta
        llamada solo lo arranca, no espera a que termine.

        resolution="audio" (valor especial, ver
        router.py:_download_quality_options) le dice a
        invidious-download que se salte el video del todo, descargue
        solo el mejor audio, lo recodifique a MP3 y lo suba a
        F:\\Musica\\ en vez de F:\\Videos\\.

        Devuelve None si no hay instancia propia configurada.
        """
        if not self.instances:
            return None

        own = self.instances[0]
        scheme, rest = own.split("://", 1)
        host = rest.split("/", 1)[0].split(":", 1)[0]

        # 11/09/2026: se manda la IP actual de la Xbox como parametro -
        # invidious-download la guarda y la usa para las subidas FTP en
        # vez de una IP fija hardcodeada en su lado (ver
        # mini-pc/invidious-download/invidious_download.py, xbox_ip). La
        # Xbox SI puede resolver al mini PC por NetBIOS (nbnsresolve),
        # pero el mini PC no puede resolver a la Xbox (confirmado que la
        # Xbox no tiene ningun respondedor NetBIOS propio) - por eso es
        # la Xbox la que avisa de su propia IP en cada trabajo que lanza,
        # en vez de intentar una resolucion en ese sentido.
        xbox_ip = xbmc.getIPAddress()

        return "{}://{}:{}/download?video_id={}&resolution={}&filename={}&xbox_ip={}".format(
            scheme, host, DOWNLOAD_JOB_PORT, video_id, resolution,
            urllib.quote(filename.encode('utf-8')), xbox_ip
        )

    def own_instance_unreachable(self):
        """
        True if the configured own instance is currently in the
        bad-instances cache - i.e. build_remux_url() would hand back a
        URL that is certain to fail, since invidious-remux only runs on
        that same machine. No extra network round-trip needed: if the
        own instance just failed during this same play() request's
        get_video_information() call, _try_instance() already called
        _mark_bad() on it moments ago, so this is a plain cache read.
        Also true when there's no own instance configured at all.
        """
        if not self.instances:
            return True
        return not _filter_known_bad([self.instances[0]])

    def search(self, q, page=1, type=None):
        params = {}
        params["q"] = q
        if page:
            params["page"] = str(page)
        if type:
            params["type"] = type

        return self._make_request("/api/v1/search", params)

    def search_channel(self, channel_id, q, page=1):
        params = {"q": q}
        if page:
            params["page"] = str(page)

        return self._make_request(
            "/api/v1/channels/" + channel_id + "/search", params
        )

    def get_trending(self, type):
        params = {"region": self.region}
        if type:
            params["type"] = type

        return self._make_request("/api/v1/trending", params)

    def get_popular(self):
        return self._make_request("/api/v1/popular")

    def get_video_information(self, video_id):
        # Prefer an instance that actually has formatStreams (the
        # legacy progressive format this addon plays directly) over
        # one that merely answers - see the is_valid comment in
        # _make_request(). If NO instance has it, we still get back
        # whatever the first instance answered (for router.py's DASH
        # fallback) instead of nothing.
        return self._make_request(
            "/api/v1/videos/" + video_id,
            is_valid=lambda data: bool(data.get("formatStreams")),
        )

    def get_channel_videos(self, channel_id):
        channel = self._make_request("/api/v1/channels/" + channel_id + "/latest")
        if not channel:
            return None

        return channel.get("videos", None)

    def get_channel_playlists(self, channel_id):
        channel = self._make_request(
            "/api/v1/channels/" + channel_id + "/playlists"
        )
        if not channel:
            return None

        return channel.get("playlists", None)

    def get_playlist_videos(self, playlistId):
        playlist = self._make_request("/api/v1/playlists/" + playlistId)
        if not playlist:
            return None

        return playlist.get("videos", None)
