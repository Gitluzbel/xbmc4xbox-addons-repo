# -*- coding: utf-8 -*-
"""
netclient
=========

Cliente de service.alfaxbox.netclient (mismo patron ya probado en plugin.video.alfaxbox/resources/lib/bridge.py
y weather.openmeteo/resources/libs/openmeteo.py) - le pide a ese servicio que haga la llamada de red por
nosotros y espera la respuesta sondeando un fichero, en vez de abrir la conexion aqui mismo.

Xbox-Luzbel (27/09/2026, NOTAS-PENDIENTE-2026-09-21.md #55): invidious.py usaba "requests" para TODO (su propia
instancia HTTP en el mini PC Y las instancias publicas HTTPS de respaldo) y router.py usaba "urllib2" para
arrancar el trabajo de descarga - ambos cargan "ssl" de forma incondicional solo con importarlos, el mismo
patron que ya crasheo weather.openmeteo/AlfaXbox/Insignia (#28-53): una llamada de red bloqueante en el mismo
interprete de Python que tambien toca xbmcgui/xbmcaddon corrompe algo que revienta cuando ese interprete se
cierra (Py_EndInterpreter()), sea o no que coincida con otro interprete arrancando a la vez. Se sustituyen los
dos por este modulo - ni invidious.py ni router.py vuelven a importar requests/urllib2/ssl/httplib para nada.

service.alfaxbox.netclient (#55) ya soporta HTTPS de verdad en su backend "direct" (via httplib.HTTPSConnection,
dentro de SU proceso - seguro ahi porque nunca se desaloja a mitad de sesion, es un xbmc.service) para las
instancias publicas de Invidious; la propia instancia (HTTP plano, el mini PC) usa el mismo backend sin ese
campo.
"""
from __future__ import unicode_literals

import json
import os
import time

import xbmc

_NETCLIENT_ADDON_ID = "service.alfaxbox.netclient"
_BASE_DIR = xbmc.translatePath("special://profile/addon_data/{}/".format(_NETCLIENT_ADDON_ID))
_REQUESTS_DIR = os.path.join(_BASE_DIR, "requests")
_RESPONSES_DIR = os.path.join(_BASE_DIR, "responses")

_POLL_MARGIN_SECONDS = 5
_POLL_INTERVAL_MS = 60


class NetClientError(Exception):
    pass


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log("plugin.video.invidious (netclient): " + msg, level)


def _ensure_dirs():
    for d in (_REQUESTS_DIR, _RESPONSES_DIR):
        if not os.path.isdir(d):
            os.makedirs(d)


def parse_url(url):
    """"http://host[:puerto]/ruta[?query]" -> (es_https, host, puerto, ruta_con_query). El puerto por defecto
    depende del esquema (443/80), igual que haria cualquier cliente HTTP normal."""
    scheme, _, rest = url.partition("://")
    host_port, _, path = rest.partition("/")
    path = "/" + path
    is_https = scheme == "https"
    if ":" in host_port:
        host, port_str = host_port.split(":", 1)
        port = int(port_str)
    else:
        host, port = host_port, (443 if is_https else 80)
    return is_https, host, port, path


def call(url, params=None, headers=None, timeout=15):
    """Pide a service.alfaxbox.netclient (backend "direct") que haga este GET por nosotros - devuelve
    (codigo_http, json_o_None). code=0 si no se pudo contactar con el destino en absoluto (equivalente a la
    excepcion que antes lanzaba requests.get()/urllib2.urlopen() en ese caso); con codigo real (200, 404...) el
    destino SI respondio, aunque el cuerpo no fuera JSON valido (json sale None en ese caso)."""
    is_https, host, port, path = parse_url(url)
    if params:
        try:
            from urllib import urlencode         # Python 2
        except ImportError:
            from urllib.parse import urlencode    # noqa: F401
        sep = "&" if "?" in path else "?"
        path = "{}{}{}".format(path, sep, urlencode(params))

    _ensure_dirs()
    request_id = "%d-%s" % (int(time.time() * 1000) % 10 ** 8, os.urandom(4).encode("hex"))
    request_path = os.path.join(_REQUESTS_DIR, request_id + ".json")
    response_path = os.path.join(_RESPONSES_DIR, request_id + ".json")
    body = {"backend": "direct", "host": host, "port": port, "path": path, "timeout": timeout}
    if is_https:
        body["https"] = True
    if headers:
        body["headers"] = headers
    payload = json.dumps(body)
    tmp = request_path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(payload.encode("utf-8") if isinstance(payload, unicode) else payload)
    # os.rename() en esta build (CRT al estilo Windows) NO sobreescribe si el destino ya existe - request_id es
    # unico por llamada asi que no deberia pasar nunca, pero por si acaso (mismo motivo que en netclient/default.py).
    try:
        os.remove(request_path)
    except OSError:
        pass
    os.rename(tmp, request_path)

    deadline = time.time() + timeout + _POLL_MARGIN_SECONDS
    while time.time() < deadline:
        if os.path.exists(response_path):
            break
        xbmc.sleep(_POLL_INTERVAL_MS)
    else:
        try:
            os.remove(request_path)
        except OSError:
            pass
        raise NetClientError("service.alfaxbox.netclient no contesto a tiempo ({})".format(url))

    try:
        with open(response_path, "rb") as f:
            data = json.loads(f.read().decode("utf-8"))
    except (IOError, OSError, ValueError) as e:
        # Mismo arreglo del #49 (bridge.py): en Python 2, IOError y OSError son clases distintas.
        _log("respuesta ilegible de service.alfaxbox.netclient: {}".format(e), xbmc.LOGWARNING)
        return 0, None
    finally:
        try:
            os.remove(response_path)
        except OSError:
            pass

    code = data.get("code", 0)
    return code, data.get("json")
