# -*- coding: utf-8 -*-
import urllib
import xbmc
import xbmcgui
import gui
import netclient

from datetime import datetime

from .invidious import InvidiousAPI
from .storage import load_storage, sync_storage

invidious = InvidiousAPI(gui.addon)

# Mismo orden que usa find_stream() para formatStreams, pero aqui se
# aplica a adaptiveFormats (video/mp4 + audio/mp4 por separado) para
# construir la lista de calidades de descarga con su tamano estimado.
# Solo se ofrecen estas dos calidades de descarga: 720p (se recodifica a
# Xvid en el mini PC para que se vea fluida en la Xbox - no siempre
# perfecta con contenido muy dinamico como conciertos, ver
# TRANSCODE_RESOLUTIONS en invidious_download.py) y 480p (remux rapido de
# siempre, calidad minima aceptable, siempre fluida). 1080p por encima y
# 360p/240p/144p por debajo se han quitado a proposito - ni 1080p tiene
# sentido en esta consola (mas pesado que 720p, que ya iba justo), ni
# compensa mostrar nada por debajo de 480p (decision del usuario,
# 08/09/2026).
DOWNLOAD_RESOLUTION_ORDER = ["720p", "480p"]


def add_channel(channel):
    channel_id = channel.get("authorId")
    channel_author = channel.get("author")
    channel_thumb = invidious.format_thumbnail(
        channel.get("authorThumbnails")[1]["url"]
    )

    gui.add_item(
        channel_author,
        "logo.png",
        channel_thumb,
        url_params={"route": "channel", "id": channel_id},
    )


def add_video(video):
    video_id = video.get("videoId")
    video_title = video["title"]
    video_thumb = invidious.format_thumbnail(video["videoThumbnails"][3]["url"])

    # parse video information
    video_infotag = {}
    video_infotag["title"] = video_title

    value = video.get("description")
    if value:
        video_infotag["plot"] = value
    value = video.get("published")
    if value:
        published = datetime.fromtimestamp(value)
        video_infotag["date"] = published.strftime("%Y-%m-%d")

    # Xbox-Luzbel (27/09/2026, #64): "Descargar" es una accion de menu contextual propia (RunPlugin, nunca
    # PlayMedia) - ver el comentario de play()/download() sobre por que un setResolvedUrl(False) desde
    # dentro del flujo de reproduccion ensena el dialogo generico de error de Kodi aunque la descarga en si
    # funcione bien.
    download_url = "{}?{}".format(
        gui.ADDON_VFS_PATH, urllib.urlencode({"route": "download", "id": video_id})
    )
    gui.add_item(
        video_title,
        "logo.png",
        video_thumb,
        url_params={"route": "play", "id": video_id},
        video_infotag=video_infotag,
        video_duration=video.get("lengthSeconds", 0),
        context_menu=[("Descargar", "RunPlugin({})".format(download_url))],
    )


def add_playlist(playlist):
    playlist_id = playlist.get("playlistId")
    playlist_title = playlist.get("title")
    playlist_thumb = invidious.format_thumbnail(playlist.get("playlistThumbnail"))
    gui.add_item(
        playlist_title,
        "logo.png",
        playlist_thumb,
        url_params={"route": "playlist", "id": playlist_id},
    )


def add_items(items):
    for item in items:
        item_type = item.get("type")
        if item_type == "channel":
            add_channel(item)
        elif item_type == "video":
            add_video(item)
        elif item_type == "playlist":
            add_playlist(item)
        else:
            xbmc.log("unsupported type: '{}'".format(item_type), xbmc.LOGNOTICE)


def _download_quality_options(video_information):
    '''
    Calidades de descarga disponibles con su tamano estimado, a partir
    de adaptiveFormats: mismo criterio (mejor audio/mp4 fijo + un
    video/mp4 por resolucion) que ya usa invidious-remux del lado del
    mini PC para elegir stream, asi la estimacion de tamano aqui
    coincide con el fichero que de verdad se va a descargar (el remux
    es "-c copy", sin recodificar, asi que el tamano real es el de los
    streams originales sumados, sin sorpresas).

    Se usa el campo "clen" (tamano exacto en bytes que da el propio
    CDN), NO "bitrate" x duracion - confirmado en produccion
    (07/09/2026) que "bitrate" puede venir muy por encima del promedio
    real (video codificado a tasa variable), dando una estimacion
    absurdamente alta (1.2GB estimados contra 470MB reales en una
    prueba real) mientras que clen es exacto porque es literalmente el
    tamano del archivo que YouTube va a servir.
    '''
    formats = video_information.get("adaptiveFormats") or []
    if not formats:
        return []

    audio_candidates = [f for f in formats if f.get("type", "").startswith("audio/mp4")]
    if not audio_candidates:
        return []
    audio_candidates.sort(key=lambda f: int(f.get("bitrate") or 0), reverse=True)
    audio_size = int(audio_candidates[0].get("clen") or 0)

    video_candidates = [f for f in formats if f.get("type", "").startswith("video/mp4")]

    options = []
    for resolution in DOWNLOAD_RESOLUTION_ORDER:
        for f in video_candidates:
            if f.get("resolution") == resolution:
                video_size = int(f.get("clen") or 0)
                if video_size and audio_size:
                    options.append((resolution, video_size + audio_size))
                break

    # Opcion de solo audio ("audio" como resolucion especial, reconocida
    # por invidious-download para saltarse el video del todo y subir a
    # F:\Musica\ en vez de F:\Videos\) - mismo audio_candidates[0]
    # (mejor bitrate) que ya elige el mini PC, asi que esta estimacion
    # de tamano coincide con el AAC original que se descarga (el mini
    # PC lo recodifica a MP3 despues, que normalmente pesa MENOS, asi
    # que esto es un techo, no una infravaloracion).
    if audio_size:
        options.append(("audio", audio_size))

    return options


def download_video(video_id, video_information):
    # invidious-download (quien hace el trabajo de verdad) solo corre en
    # la maquina del servidor propio - igual que ya comprueba play()
    # antes de intentar un remux para reproducir en directo.
    if invidious.own_instance_unreachable():
        gui.notification(
            "Invidious",
            "Descargar necesita tu servidor propio, que no responde ahora mismo",
        )
        return

    options = _download_quality_options(video_information)
    if not options:
        xbmc.log(
            "download_video: no downloadable adaptiveFormats for ID '{}'".format(video_id),
            xbmc.LOGWARNING,
        )
        gui.notification("Invidious", "Este vídeo no tiene formatos descargables")
        return

    labels = []
    for resolution, size in options:
        if resolution == "audio":
            labels.append("Solo audio, MP3 (~{:.0f} MB)".format(size / (1024.0 ** 2)))
        else:
            labels.append("{} (~{:.1f} GB)".format(resolution, size / (1024.0 ** 3)))
    # Xbox-Luzbel (27/09/2026, #64): esta llamada viene ahora de download() (RunPlugin, menu contextual),
    # que no deja abierto el "busydialog" que sí dejaba el flujo antiguo (route=play, OnPlayMedia) - se deja
    # este Dialog.Close igualmente, no hace daño si no hay nada que cerrar, y protege por si algun dia
    # download_video() se vuelve a llamar desde un camino que sí lo deje abierto (mismo bug confirmado y
    # arreglado en AlfaXbox, ver mini-pc/NOTAS-PENDIENTE-2026-09-21.md #14).
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    selected = xbmcgui.Dialog().select("Elige calidad de descarga", labels)
    if selected < 0:
        return

    resolution, estimated_total = options[selected]
    video_title = video_information.get("title") or video_id

    # invidious-download hace todo el trabajo pesado el mismo (descarga
    # en paralelo + remux + copia por FTP a F:\Videos\ de la Xbox) - esta
    # llamada solo lo arranca, la Xbox no escribe nada ni espera aqui.
    # Ver ese proyecto para el porque: la Xbox es demasiado lenta para
    # mantener una descarga de horas con un dialogo modal bloqueado.
    job_url = invidious.build_download_job_url(video_id, resolution, video_title)
    if not job_url:
        gui.notification("Invidious", "No se pudo construir la URL de descarga")
        return

    xbmc.log(
        "download_video: starting background job for '{}' at {} (est. {:.2f} GB)".format(
            video_id, resolution, estimated_total / (1024.0 ** 3)
        ),
        xbmc.LOGNOTICE,
    )

    try:
        netclient.call(job_url, timeout=10)
    except Exception as e:
        xbmc.log(
            "download_video: failed to start job for ID '{}': {}".format(video_id, e),
            xbmc.LOGWARNING,
        )
        gui.notification("Invidious", "No se pudo iniciar la descarga")
        return

    destino = "F:\\Musica\\" if resolution == "audio" else "F:\\Videos\\"
    gui.notification(
        "Invidious",
        "Descarga iniciada en segundo plano. Aparecerá en {} cuando termine.".format(destino),
        time=8000,
    )


def find_stream(streams, resolution):
    for stream in streams:
        if stream["resolution"] == resolution:
            return stream["url"]

    if resolution == "720p":
        return find_stream(streams, "480p")
    if resolution == "480p":
        return find_stream(streams, "360p")
    if resolution == "360p":
        return find_stream(streams, "240p")
    if resolution == "240p":
        return find_stream(streams, "144p")

    return None


def play(url_params):
    """Envoltorio fino: un clic en un video dispara el flujo OnPlayMedia
    de Kodi, que muestra un dialogo de "cargando" hasta que se llama a
    setResolvedUrl() - si _play_impl() decide no reproducir nada (no hay
    stream disponible, o ninguna instancia respondio) sin esto ese
    dialogo se queda girando para siempre, confirmado en produccion
    (07/09/2026).

    Xbox-Luzbel (27/09/2026, #64): "Descargar" YA NO se ofrece aqui (antes
    era una opcion dentro de un dialogo Ver/Descargar que se abria al
    hacer clic, ver download() mas abajo para el motivo real) - elegir
    Descargar terminaba llamando a gui.cancel_resolve() de todas formas, y
    xbmc/Application.cpp (PlayFile) trata CUALQUIER setResolvedUrl(False)
    como un fallo real de reproduccion (PLAYBACK_FAIL), sin distinguir
    "el usuario eligio otra cosa" de "de verdad no se pudo reproducir" -
    PlayListPlayer.cpp entonces enseña su dialogo generico de error
    (CGUIDialogOK::ShowAndGetInput), incluso cuando la descarga arrancaba
    bien. Un clic vuelve a reproducir directamente (como antes de anadir
    esa opcion); Descargar es ahora una accion de menu contextual propia
    (ver add_video() en este mismo fichero) que dispara RunPlugin(), nunca
    PlayMedia - así no entra jamas en este camino ni en ese dialogo."""
    resolved = False
    try:
        resolved = _play_impl(url_params)
    finally:
        if not resolved:
            gui.cancel_resolve()


def download(url_params):
    """Xbox-Luzbel (27/09/2026, #64): ruta propia para el menu contextual "Descargar" de add_video() -
    disparada por RunPlugin() (nunca PlayMedia), asi que nunca entra en el camino de
    setResolvedUrl()/PLAYBACK_FAIL que ensena el dialogo de error generico de Kodi (ver el comentario de
    play() de mas arriba)."""
    video_id = url_params.get("id")
    if not video_id:
        xbmc.log("download: called without a video id", xbmc.LOGWARNING)
        return

    video_information = invidious.get_video_information(video_id)
    if not video_information:
        xbmc.log(
            "download: could not get video information for ID '{}' from any instance".format(video_id),
            xbmc.LOGWARNING,
        )
        if not invidious.own_instance_unreachable():
            gui.notification("Invidious", "No se ha podido obtener información de este vídeo")
        return

    download_video(video_id, video_information)


def _play_impl(url_params):
    video_id = url_params.get("id")
    if not video_id:
        xbmc.log("play: called without a video id", xbmc.LOGWARNING)
        return False

    video_information = invidious.get_video_information(video_id)
    if not video_information:
        # Every instance (own + fallback + public) failed for this
        # request - see the per-instance failures already logged by
        # InvidiousAPI._try_instance() in invidious.py. Common real
        # cause: the video itself is unavailable (deleted, region/age
        # restricted...) rather than any instance being down - own
        # instance being down specifically already gets its own
        # notification from there.
        xbmc.log(
            "play: could not get video information for ID '{}' from any instance".format(
                video_id
            ),
            xbmc.LOGWARNING,
        )
        if not invidious.own_instance_unreachable():
            # If the own instance IS unreachable, _try_instance() in
            # invidious.py already showed a clearer, more specific
            # notification about that - avoid piling a second, vaguer
            # one about the same underlying event on top of it.
            gui.notification("Invidious", "No se ha podido obtener información de este vídeo")
        return False

    stream_link = None

    streams = video_information.get("formatStreams")
    if streams:
        resolution = gui.addon.getSetting("resolution")
        stream_link = find_stream(streams, resolution)
        if not stream_link:
            xbmc.log(
                "play: no stream found for ID '{}' at or below resolution '{}'".format(
                    video_id, resolution
                ),
                xbmc.LOGWARNING,
            )

    if not stream_link:
        # formatStreams is YouTube's old "progressive" (muxed video+audio
        # in one file) format. YouTube has stopped generating it for most
        # videos uploaded in the last several years - only adaptiveFormats
        # (separate video/audio streams) exists for those, even when the
        # Invidious instance itself is extracting everything else (title,
        # thumbnails, adaptiveFormats...) just fine.
        #
        # A first attempt used dashUrl (Invidious' own DASH manifest) as
        # the fallback here, but confirmed on real hardware that this
        # Xbox's DVDPlayer/ffmpeg build has no DASH demuxer at all
        # ("error probing input format" for every dashUrl tried, several
        # different videos, always the same failure). Replaced with
        # invidious-remux (see that project's own script/service on the
        # self-hosted instance's machine): it muxes the best H.264 video
        # + AAC audio from adaptiveFormats into one plain MP4 with
        # "-c copy" (no re-encoding), which is exactly the kind of file
        # this Xbox already plays fine via formatStreams - confirmed
        # working end to end for a video that has no formatStreams.
        # Only works when an own (self-hosted) instance is configured;
        # public instances never run this helper.
        if invidious.own_instance_unreachable():
            # Don't hand XBMC a remux URL we already know will fail -
            # invidious-remux only runs on the own instance's machine,
            # so if that's currently down there's no point trying, and
            # a generic playback failure on the Xbox side would give no
            # clue why. Tell the user directly instead.
            gui.notification(
                "Invidious",
                "Este vídeo necesita tu servidor propio, que no responde ahora mismo",
            )
            xbmc.log(
                "play: skipping remux for ID '{}', own instance is known unreachable".format(
                    video_id
                ),
                xbmc.LOGWARNING,
            )
        else:
            remux_url = invidious.build_remux_url(video_id, gui.addon.getSetting("resolution"))
            if remux_url:
                stream_link = remux_url
                xbmc.log(
                    "play: no usable formatStreams for ID '{}', trying invidious-remux instead".format(
                        video_id
                    ),
                    xbmc.LOGNOTICE,
                )

    if not stream_link:
        xbmc.log(
            "play: no formatStreams or dashUrl available for ID '{}'".format(video_id),
            xbmc.LOGWARNING,
        )
        if not invidious.own_instance_unreachable():
            # Same reasoning as above: if the own instance is down,
            # that already got its own notification - this one is only
            # for when the server answered fine but this particular
            # video has nothing playable (no formatStreams and no own
            # instance configured to remux from).
            gui.notification("Invidious", "Este vídeo no tiene un formato compatible con esta Xbox")
        return False

    xbmc.log("play: playing video from: {}".format(stream_link), xbmc.LOGNOTICE)

    # Without a title/artist on the resolved item, the LCD's
    # VideoPlayer.Title/Artist lines have nothing to go on but the raw
    # video ID from the stream URL.
    video_title = video_information.get("title")
    video_infotag = {}
    if video_title:
        video_infotag["title"] = video_title
    author = video_information.get("author")
    if author:
        video_infotag["artist"] = [author]

    length_seconds = video_information.get("lengthSeconds", 0)

    # invidious-remux streams never carry their duration in the file
    # itself (see service.invidious.lcd for why), so the remaining-time
    # and progress bar on the LCD can't come from the usual
    # Player.Duration/LCD.ProgressBar - hand the real duration to that
    # service via a window property instead, for it to use in their
    # place.
    gui.set_known_duration(length_seconds)

    # Mismo indice que ya usa add_video() para la miniatura del listado -
    # se manda tambien por propiedad de ventana (ver set_known_thumbnail)
    # para service.xbox.remotecontrol, porque Player.Art(thumb) sale
    # vacio cuando se reproduce con una URL directa de googlevideo.com.
    video_thumbnails = video_information.get("videoThumbnails")
    video_thumb = None
    if video_thumbnails and len(video_thumbnails) > 3:
        video_thumb = invidious.format_thumbnail(video_thumbnails[3]["url"])
    gui.set_known_thumbnail(video_thumb)

    gui.play(
        stream_link,
        title=video_title,
        video_infotag=video_infotag,
        video_duration=length_seconds,
        thumb=video_thumb,
    )
    return True


def list_index():
    gui.add_item("Tendencias", "trend.png", url_params={"route": "trending"})
    gui.add_item("Popular", "popular.png", url_params={"route": "popular"})
    gui.add_item("Buscar", "search.png", url_params={"route": "search", "q": "-"})
    gui.end_listing()


def list_trending(url_params):
    is_root = url_params.as_bool("is_root", True)
    if is_root:
        gui.add_item(
            "Todo",
            "all.png",
            url_params={"route": "trending", "is_root": False, "type": "default"},
        )
        gui.add_item(
            "Música",
            "music.png",
            url_params={"route": "trending", "is_root": False, "type": "music"},
        )
        gui.add_item(
            "Videojuegos",
            "game.png",
            url_params={"route": "trending", "is_root": False, "type": "gaming"},
        )
        gui.add_item(
            "Películas",
            "movies.png",
            url_params={"route": "trending", "is_root": False, "type": "movies"},
        )
        return gui.end_listing()

    videos = invidious.get_trending(url_params.as_string("type"))
    if not videos:
        return gui.end_listing()

    add_items(videos)
    return gui.end_listing()


def list_popular():
    videos = invidious.get_popular()
    if not videos:
        return gui.end_listing()

    add_items(videos)
    return gui.end_listing()


def list_search():
    gui.add_item("Nueva búsqueda", "search.png", url_params={"route": "search_result"})

    storage = load_storage("history")
    if storage:
        search_history = storage.get("search_history", [])
        for history in search_history[::-1]:
            gui.add_item(history, url_params={"route": "search_result", "q": history})

    gui.end_listing()


def list_search_result(url_params):
    q = url_params.get("q")
    if not q:
        q = gui.get_search_input("Nueva búsqueda")
        if not q:
            return gui.end_listing()

    storage = load_storage("history")
    if storage is not None:
        search_history = storage.get("search_history", [])
        if len(search_history) > 40:
            search_history = search_history[1:] + search_history[:1]
            search_history[40] = q
        else:
            search_history.append(q)
        storage["search_history"] = search_history
        sync_storage("history", storage)

    page = url_params.as_int("page", 1)
    if page == 1:
        gui.add_item("Canales", url_params={"route": "channels", "q": q})
        gui.add_item("Listas de reproducción", url_params={"route": "playlists", "q": q})

    videos = invidious.search(q, page, "video")
    if not videos:
        return gui.end_listing()

    add_items(videos)

    gui.add_item(
        "Página siguiente ({})".format(page + 1),
        url_params={"route": "search_result", "q": q, "page": page + 1},
    )
    return gui.end_listing()


def list_playlist(url_params):
    playlistId = url_params.get("id")
    if not playlistId:
        return gui.end_listing()

    videos = invidious.get_playlist_videos(playlistId)
    if not videos:
        return gui.end_listing()

    add_items(videos)
    return gui.end_listing()


def list_playlists(url_params):
    q = url_params.get("q")
    channel_id = url_params.get("id")

    if not (q or channel_id):
        return gui.end_listing()

    page = url_params.as_int("page", 1)

    playlists = None
    if q:
        playlists = invidious.search(q, page, "playlist")
    elif channel_id:
        playlists = invidious.get_channel_playlists(channel_id)

    if not playlists:
        return gui.end_listing()

    add_items(playlists)

    if q:
        gui.add_item(
            "Página siguiente ({})".format(page + 1),
            url_params={"route": "playlists", "q": q, "page": page + 1},
        )

    return gui.end_listing()


def list_channel(url_params):
    channel_id = url_params.get("id", None)
    if not channel_id:
        return gui.end_listing()

    gui.add_item(
        "Listas de reproducción",
        "playlist.png",
        url_params={"route": "playlists", "id": channel_id},
    )
    gui.add_item(
        "Buscar", "search.png", url_params={"route": "channel_result", "id": channel_id}
    )

    videos = invidious.get_channel_videos(channel_id)
    if not videos:
        return gui.end_listing()

    add_items(videos)
    return gui.end_listing()


def list_channel_result(url_params):
    channel_id = url_params.get("id")
    if not channel_id:
        return gui.end_listing()

    q = url_params.get("q")
    if not q:
        q = gui.get_search_input("Buscar en el canal")
        if not q:
            return gui.end_listing()

    page = url_params.as_int("page", 1)

    items = invidious.search_channel(channel_id, q, page)
    if not items:
        return gui.end_listing()

    add_items(items)

    gui.add_item(
        "Página siguiente ({})".format(page + 1),
        url_params={
            "route": "channel_result",
            "id": channel_id,
            "q": q,
            "page": page + 1,
        },
    )
    return gui.end_listing()


def list_channels(url_params):
    q = url_params.get("q")
    if not q:
        return gui.end_listing()

    page = url_params.as_int("page", 1)

    channels = invidious.search(q, page, "channel")
    if not channels:
        return gui.end_listing()

    add_items(channels)

    gui.add_item(
        "Página siguiente ({})".format(page + 1),
        url_params={"route": "channels", "q": q, "page": page + 1},
    )
    return gui.end_listing()
