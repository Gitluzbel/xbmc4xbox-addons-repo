# -*- coding: utf-8 -*-
"""
nbnsresolve
===========

Resuelve nombres NetBIOS (tipo "XBOXMINIPC") a una IP en la red local,
usando NBNS (NetBIOS Name Service, RFC 1002) por UDP broadcast al puerto
137 - sin depender de ningun servidor DNS ni de mDNS (la Xbox no tiene
soporte de mDNS/Bonjour en absoluto, confirmado revisando el codigo del
motor: cero referencias en xbmc/network/, xbmc/linux/).

Por que NBNS y no reutilizar el cliente SMB que ya trae la Xbox
(xbmc/filesystem/SmbFile.cpp, que SI usa "name resolve order = bcast wins
host" via libsmbclient): esa resolucion vive enterrada dentro de la
logica interna de conexion SMB de Samba, no esta expuesta como una
funcion generica reutilizable desde Python sin tocar y recompilar el
motor en C++. Implementar el propio NBNS aqui, en Python puro, evita
tocar el motor por completo.

Confirmado que la Xbox NO tiene ningun respondedor NetBIOS propio
(probado con una consulta NBSTAT directa desde el mini PC: sin
respuesta) - por eso este modulo solo sirve para que la Xbox pregunte
por el mini PC, nunca al reves. El mini PC corre nmbd (parte de samba)
para responder a estas consultas, anunciandose con el nombre
configurado en netbios name= dentro de /etc/samba/smb.conf.

Uso:
    from nbnsresolve import resolve_netbios_name
    ip = resolve_netbios_name('XBOXMINIPC')  # o None si no responde
"""

import socket
import struct
import time

# Log opcional via xbmc.log si estamos corriendo dentro de la Xbox - este
# modulo tambien se puede probar fuera (en un Mac/Linux cualquiera), asi
# que no se hace un import duro de xbmc.
try:
    import xbmc as _xbmc

    def _log(msg):
        _xbmc.log("nbnsresolve: " + msg, _xbmc.LOGDEBUG)
except ImportError:
    def _log(msg):
        pass

# Cache en memoria del proceso - evita reconsultar la red en cada
# llamada. Un addon Python en XBMC4Xbox normalmente vive solo mientras
# dura una invocacion (plugin) o todo el arranque (servicio), asi que
# este cache a nivel de modulo es aceptable sin persistirlo a disco.
_cache = {}
CACHE_TTL_SECONDS = 300  # 5 minutos

NBNS_PORT = 137
QUERY_TIMEOUT_SECONDS = 2


def _encode_netbios_name(name, suffix=0x00):
    """Codificacion NetBIOS 'First Level Encoding' (RFC 1001/1002): cada
    byte del nombre (rellenado a 15 caracteres + 1 byte de sufijo de
    tipo de servicio) se parte en dos nibbles, cada uno mapeado a una
    letra A-P."""
    padded = name.upper()[:15].ljust(15) + chr(suffix)
    encoded = []
    for ch in padded:
        b = ord(ch)
        encoded.append(chr(0x41 + (b >> 4)))
        encoded.append(chr(0x41 + (b & 0x0F)))
    encoded_str = ''.join(encoded)
    return chr(32) + encoded_str + chr(0)


def _build_query_packet(name):
    txn_id = int(time.time()) & 0xFFFF
    flags = 0x0110  # query estandar, recursion desired
    header = struct.pack('>HHHHHH', txn_id, flags, 1, 0, 0, 0)
    qname = _encode_netbios_name(name)
    question = qname + struct.pack('>HH', 0x0020, 0x0001)  # tipo NB, clase IN
    return header + question


def _broadcast_address():
    """Deduce la direccion de broadcast a partir de la IP local de la
    Xbox (asume /24, lo habitual en redes domesticas - no hay forma
    sencilla de leer la mascara real desde Python en este build)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        local_ip = s.getsockname()[0]
        s.close()
        parts = local_ip.split('.')
        addr = '.'.join(parts[:3] + ['255'])
        _log("IP local detectada: {}, broadcast calculado: {}".format(local_ip, addr))
        return addr
    except Exception as e:
        _log("fallo calculando broadcast, usando 255.255.255.255: {}".format(e))
        return '255.255.255.255'


def resolve_netbios_name(name, use_cache=True):
    """Devuelve la IP (str) asociada al nombre NetBIOS dado, o None si
    nadie responde a tiempo. Cachea el resultado en memoria durante
    CACHE_TTL_SECONDS para no repetir la consulta de red en cada
    llamada."""
    key = name.upper()
    now = time.time()

    if use_cache and key in _cache:
        cached_ip, cached_at = _cache[key]
        if now - cached_at < CACHE_TTL_SECONDS:
            return cached_ip

    packet = _build_query_packet(name)
    directed_broadcast = _broadcast_address()

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    s.settimeout(QUERY_TIMEOUT_SECONDS)
    try:
        # 11/09/2026: se prueban las dos formas de broadcast (dirigido a
        # la subred, p.ej. 192.168.1.255, Y el limitado 255.255.255.255)
        # en la misma consulta - confirmado con una captura tcpdump real
        # en el mini PC que el dirigido no llegaba nunca desde la Xbox
        # (aunque el mismo codigo SI funcionaba probado desde Linux hacia
        # si mismo), posiblemente por como el router/la propia Xbox tratan
        # uno u otro tipo de broadcast. Mandar ambos no hace dano y cubre
        # los dos casos sin tener que adivinar cual funciona en cada red.
        for target in (directed_broadcast, '255.255.255.255'):
            _log("enviando consulta por '{}' a {}:{}".format(name, target, NBNS_PORT))
            s.sendto(packet, (target, NBNS_PORT))
        data, addr = s.recvfrom(1024)
        _log("respuesta recibida de {}, {} bytes".format(addr, len(data)))
        # La IP resuelta va en los ultimos 4 bytes de la respuesta
        # (registro NB: 2 bytes de flags + 4 bytes de IP).
        ip_bytes = data[-4:]
        resolved_ip = '.'.join(str(ord(b)) for b in ip_bytes)
        _cache[key] = (resolved_ip, now)
        return resolved_ip
    except socket.timeout:
        _log("timeout esperando respuesta ({}s)".format(QUERY_TIMEOUT_SECONDS))
        return None
    except Exception as e:
        _log("fallo enviando/recibiendo la consulta: {}".format(e))
        return None
    finally:
        s.close()
