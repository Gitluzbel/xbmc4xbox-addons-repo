# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import xbmcgui

__all__ = ['Dialogs']


# Xbox-Luzbel (26/09/2026): este import era "from .webclient import WebClientError" - el mismo bug que ya se
# habia arreglado el 13/09/2026 en simpleweather/__init__.py (ver el comentario de alli), pero quedo sin tocar
# AQUI, y este modulo se importa SIEMPRE (simpleweather.py hace "from .dialogs import Dialogs" en cada arranque
# de Weather) - asi que "ssl" seguia cargandose de todos modos via webclient.py -> requests, pese a que
# WebClient no se usa en ningun sitio real de este addon. Se redefine la clase aqui mismo (identica, no se
# puede importar la de simpleweather/__init__.py sin crear un import circular: ese __init__ ya depende de este
# archivo a traves de simpleweather.py) en vez de importar el modulo entero solo por esta excepcion, que nunca
# llega a lanzarse de verdad.
class WebClientError(Exception):

    def __init__(self, error):
        self.message = error
        super(WebClientError, self).__init__(self.message)


class Dialogs(object):

    def notify_error(self, error, show_dialog=False):
        heading = ''
        message = '{0}'.format(error)
        if isinstance(error, WebClientError):
            _ = self.initialize_gettext()
            heading = _('Connection error')
        else:
            self.log_error(message)

        if show_dialog:
            self.dialog_ok(message)
        else:
            self.dialog_notification_error(heading, message)

    def dialog_notification_error(self, heading, message="", time=0, sound=True):
        self.dialog_notification(heading, message, xbmcgui.NOTIFICATION_ERROR, time, sound)

    def dialog_notification_info(self, heading, message="", time=0, sound=True):
        self.dialog_notification(heading, message, xbmcgui.NOTIFICATION_INFO, time, sound)

    def dialog_notification_warning(self, heading, message="", time=0, sound=True):
        self.dialog_notification(heading, message, xbmcgui.NOTIFICATION_WARNING, time, sound)

    def dialog_notification(self, heading, message="", icon="", time=0, sound=True):

        _message = message if message else heading

        if heading \
                and heading != _message:
            _heading = '{0}: {1}'.format(self.name, heading)
        else:
            _heading = self.name

        xbmcgui.Dialog().notification(_heading, _message, icon, time, sound)

    def dialog_ok(self, line1, line2="", line3=""):

        if self.kodi_major_version() >= '19':
            xbmcgui.Dialog().ok(self.name, self._join_strings(line1, line2, line3))
        else:
            xbmcgui.Dialog().ok(self.name, line1, line2, line3)

    def dialog_progress_create(self, heading, line1="", line2="", line3=""):
        progress = xbmcgui.DialogProgress()

        if self.kodi_major_version() >= '19':
            progress.create(heading, self._join_strings(line1, line2, line3))
        else:
            progress.create(heading, line1, line2, line3)

        return progress

    def dialog_progress_update(self, progress, percent, line1="", line2="", line3=""):

        if self.kodi_major_version() >= '19':
            progress.update(percent, self._join_strings(line1, line2, line3))
        else:
            progress.update(percent, line1, line2, line3)

        return progress

    @staticmethod
    def dialog_select(heading, _list, **kwargs):
        return xbmcgui.Dialog().select(heading, _list, **kwargs)

    @staticmethod
    def _join_strings(line1, line2="", line3=""):

        lines = [line1]
        if line2:
            lines.append(line2)
        if line3:
            lines.append(line3)

        return '[CR]'.join(lines)
