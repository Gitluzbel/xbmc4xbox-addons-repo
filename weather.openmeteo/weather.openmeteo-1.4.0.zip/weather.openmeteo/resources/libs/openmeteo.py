# -*- coding: utf-8 -*-
"""
Cliente de la API de geocodificacion de Open-Meteo (https://open-meteo.com/), sin clave ni registro. Usado
SOLO para la busqueda de ciudad (accion "location" en default.py) - el pronostico en si ya no pasa por aqui,
ver CWeatherJob::FetchOpenMeteoWeather() en xbmc/utils/Weather.cpp (Xbox-Luzbel, 26/09/2026,
NOTAS-PENDIENTE-2026-09-21.md #44), que porto a C++ el resto de este modulo (peticion de pronostico, tabla de
codigos OMM->texto/icono, parseo de fechas ISO) para que el refresco automatico del tiempo ya no dependa de
Python en absoluto.
"""
from __future__ import unicode_literals

import os
import time
import json

__all__ = ['OpenMeteoError', 'OpenMeteoClient']

GEOCODING_URL = "http://geocoding-api.open-meteo.com/v1/search"


class OpenMeteoError(Exception):
    pass


# No se usa el modulo "urllib" de la libreria estandar (solo para su urlencode()): confirmado con traza de
# pila (26/09/2026) que el propio urllib.py, al importarse, hace "import ssl" el solo (linea ~107 de la
# libreria estandar de Python 2.7) - nada que ver con HTTPS, es incondicional. Es el mismo "ssl" (wolfssl en
# este fork) ya sospechoso de crashes reales al cerrar subinterpretes (ver #34/#39,
# NOTAS-PENDIENTE-2026-09-21.md) - así que ni siquiera "import urllib" a secas es seguro aqui. Version propia,
# minima, sin ninguna dependencia de la libreria estandar de red.
_URLENCODE_SAFE = frozenset(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")


def _quote(value):
    if isinstance(value, unicode):
        raw = value.encode("utf-8")
    else:
        raw = str(value)
    out = []
    for byte in raw:
        if byte in _URLENCODE_SAFE:
            out.append(byte)
        else:
            out.append("%%%02X" % ord(byte))
    return "".join(out)


def _urlencode(params):
    return "&".join("{}={}".format(_quote(k), _quote(v)) for k, v in params.items())


# INTENTO REVERTIDO (13/09/2026): se probo sustituir esta llamada por
# xbmcvfs.File() para evitar tocar ssl de Python del todo (ver
# docs/investigaciones/runxbe-shutdown-crash-investigation.md) - no
# funciona para esta API en concreto. Confirmado leyendo
# xbmc/interfaces/legacy/File.cpp (File::readBytes): cuando la respuesta
# llega con "Transfer-Encoding: chunked" (sin Content-Length fijo, como
# hace Open-Meteo), CCurlFile pone GetLength()=0 a proposito por no poder
# saber el tamano de antemano - pero File::readBytes() SIEMPRE sobreescribe
# el tamano pedido con ese 0 ("if (size >= 0) numBytes = size"), asi que
# .read() devuelve un buffer vacio sin leer nada, sea cual sea el tamano
# que se le pida desde Python. Es una limitacion real del motor (no algo
# arreglable desde este addon) - confirmado en consola real que la
# peticion SI llegaba bien al servidor (200 OK, JSON completo por la
# red), pero el binding de Python nunca llegaba a leerlo.
#
# ARREGLO DE VERDAD (26/09/2026, NOTAS-PENDIENTE-2026-09-21.md #42): quitar "ssl" (urllib2, luego hasta el
# propio "import urllib" de la libreria estandar - ver #39/#40) NO bastaba: seguia reventando. El bisecado
# original del #36 ya lo decia: "la combinacion de una llamada de red bloqueante (socket crudo O urllib2, da
# igual cual) + xbmcgui/xbmcaddon en el MISMO interprete" es lo que revienta la consola - cambiar de urllib2 a
# un socket crudo NO rompe esa combinacion, solo cambiaba que mecanismo de red se usaba, dejando intacta la
# causa real. Mismo tratamiento que ya tiene plugin.video.alfaxbox (ver su bridge.py): este modulo ya NO abre
# ningun socket el mismo - se lo pide a service.alfaxbox.netclient (backend "direct": habla con el host/puerto
# de la peticion sin pasar por el mini PC, para addons que hablan con internet) por fichero, y espera la
# respuesta sondeando otro fichero, sin red ni socket en este intérprete.
_NETCLIENT_ADDON_ID = "service.alfaxbox.netclient"


def _netclient_dirs():
    import xbmc
    base = xbmc.translatePath("special://profile/addon_data/{}/".format(_NETCLIENT_ADDON_ID))
    return os.path.join(base, "requests"), os.path.join(base, "responses")


def _call_netclient(host, port, path, timeout):
    import xbmc
    requests_dir, responses_dir = _netclient_dirs()
    for d in (requests_dir, responses_dir):
        if not os.path.isdir(d):
            os.makedirs(d)
    request_id = "%d-%s" % (int(time.time() * 1000) % 10 ** 8, os.urandom(4).encode("hex"))
    request_path = os.path.join(requests_dir, request_id + ".json")
    response_path = os.path.join(responses_dir, request_id + ".json")
    body = json.dumps({"backend": "direct", "host": host, "port": port, "path": path, "timeout": timeout})
    tmp = request_path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(body.encode("utf-8") if isinstance(body, unicode) else body)
    try:
        os.remove(request_path)
    except OSError:
        pass
    os.rename(tmp, request_path)

    deadline = time.time() + timeout + 5
    while time.time() < deadline:
        if os.path.exists(response_path):
            break
        xbmc.sleep(60)
    else:
        try:
            os.remove(request_path)
        except OSError:
            pass
        raise OpenMeteoError("service.alfaxbox.netclient no contesto a tiempo - "
                             "comprueba en Ajustes de la consola que ese servicio esta activado")

    try:
        with open(response_path, "rb") as f:
            data = json.loads(f.read().decode("utf-8"))
    finally:
        try:
            os.remove(response_path)
        except OSError:
            pass
    return data.get("code", 0), data.get("json") or {}


def _get_json(url, params):
    host, _, rest = url.split("://", 1)[1].partition("/")
    path = "/" + rest + "?" + _urlencode(params)
    code, data = _call_netclient(host, 80, path, timeout=15)
    if code != 200:
        raise OpenMeteoError(data.get("error") or "HTTP {} de {}".format(code, host))
    return data


class OpenMeteoClient(object):

    def __init__(self, lang='es'):
        # Idioma elegido en el ajuste "Language" del addon (no depende
        # del idioma de Kodi) - controla tanto el texto de las
        # condiciones (ver describe()) como el idioma de los nombres
        # de ciudad devueltos por el geocodificador.
        self.lang = lang if lang in ('es', 'en') else 'es'

    def cities_search(self, keyword):
        """Busca ciudades por nombre. Devuelve una lista de dicts con
        la misma forma que gismeteo.py: name/id/country/district/lat/lng.
        Como Open-Meteo no tiene "id" de ciudad propio, se usa
        "lat,lng" como id (asi build_forecast_url() no necesita un
        segundo servicio para resolverlo)."""
        data = _get_json(GEOCODING_URL, {
            "name": keyword,
            "count": 10,
            "language": self.lang,
            "format": "json",
        })
        results = []
        for item in data.get("results", []) or []:
            lat = item.get("latitude")
            lng = item.get("longitude")
            results.append({
                'name': item.get("name", ""),
                'id': "{0},{1}".format(lat, lng),
                'country': item.get("country", ""),
                'district': item.get("admin1", "") or "",
                'lat': lat,
                'lng': lng,
                'kind': "",
            })
        return results
