# -*- coding: utf-8 -*-
"""
weather.openmeteo
==================

Addon de clima usando la API gratuita de Open-Meteo (sin clave, sin registro).

Xbox-Luzbel (26/09/2026, NOTAS-PENDIENTE-2026-09-21.md #44): este fichero YA NO hace ninguna peticion de
pronostico ni pinta ninguna propiedad de ventana - todo eso ahora es CWeatherJob::FetchOpenMeteoWeather() en
C++ (xbmc/utils/Weather.cpp), exactamente igual que hace weather.xbmc.builtin (Internal Weather/Gismeteo) con
su FetchInternalWeather(). Motivo: Kodi invoca el addon de clima automaticamente muy a menudo (al entrar en la
pantalla de Clima y periodicamente en segundo plano), y cada una de esas invocaciones creaba y destruia un
interprete de Python nuevo - eso, combinado con el bug bisecado en produccion (ver #28-43: una llamada de red
bloqueante + xbmcgui/xbmcaddon en el mismo interprete de Python de esta build de XBMC4Xbox corrompe algo que
revienta minutos despues en el cierre de OTRO interprete cualquiera), hacia que la consola reventara de forma
intermitente con weather.openmeteo activo. Pasar el refresco a C++ quita a Python de en medio del todo para la
parte que se repite sola - ya no hay ninguna combinacion peligrosa que perseguir ahi.

Lo unico que sigue en Python es la busqueda de ciudad (accion "location", ver el boton "Ciudad" en los
ajustes del addon) - una accion RARA y siempre iniciada a mano por el usuario, nunca automatica, exactamente
el mismo tipo de invocacion que ya usa weather.xbmc.builtin/default.py (network + xbmcgui en el mismo script,
pero solo cuando el usuario pulsa el boton, nunca en segundo plano) - se mantiene la misma arquitectura de
paridad que pidio el usuario. Sigue usando resources/libs/openmeteo.py (OpenMeteoClient.cities_search(), via
service.alfaxbox.netclient) para no reintroducir ningun socket/urllib propio en este interprete.

A diferencia de weather.xbmc.builtin (que guarda hasta 5 ubicaciones, Location1..5/Location1ID..5ID), este
addon solo soporta UNA ciudad guardada (settings.xml: "City"/"CityID") - CityID es "latitud,longitud" (ver
cities_search()), que es lo que espera CWeatherJob::FetchOpenMeteoWeather() en el lado C++.
"""
from __future__ import unicode_literals

import xbmc

from resources.libs import OpenMeteo, OpenMeteoError, Location, Weather, WebClientError

weather = Weather()
_ = weather.initialize_gettext()


def _lang():
    # Ajuste "Language" del addon (0=Espanol, 1=English) - independiente del idioma del propio Kodi, igual
    # que ya hacia la version anterior de este fichero. CWeatherJob::FetchOpenMeteoWeather() lee este mismo
    # ajuste directamente (addon->GetSetting("Language")) para traducir el pronostico con la misma tabla.
    return 'en' if weather.get_setting('Language') == 1 else 'es'


@weather.action()
def location(params):
    labels = []
    locations = []

    keyword = weather.get_keyboard_text('', xbmc.getLocalizedString(14024), False)
    if keyword:
        try:
            search_result = OpenMeteo(_lang()).cities_search(keyword)
        except (OpenMeteoError, WebClientError) as e:
            weather.notify_error(e, True)
        else:
            for s_location in search_result:
                loc = Location(s_location)
                locations.append({'id': loc.id, 'name': loc.name})
                labels.append(loc.label)

            if locations:
                selected = weather.dialog_select(xbmc.getLocalizedString(396), labels)
                if selected != -1:
                    chosen = locations[selected]
                    weather.set_setting('City', chosen['name'])
                    weather.set_setting('CityID', chosen['id'])
            else:
                weather.dialog_ok(weather.name, xbmc.getLocalizedString(284))


if __name__ == '__main__':
    weather.run()
