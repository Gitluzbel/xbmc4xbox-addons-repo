# -*- coding: utf-8 -*-
"""
Cliente de la API de Open-Meteo (https://open-meteo.com/), sin clave ni
registro. A diferencia de Gismeteo, Open-Meteo NO da el texto de la
condicion traducido - da un codigo numerico estandar de la OMM (0-99),
y es este modulo quien lo traduce a texto (ver WMO_CODES) y a un codigo
de icono Yahoo (0-47/na, el mismo esquema que ya usa el paquete de
iconos ya instalado, resource.images.weathericons.default) - por eso
esto SI sale en español de verdad, no depende de que la API externa lo
soporte (que es justo el problema que tenia Gismeteo).

Las funciones publicas devuelven diccionarios con la MISMA forma que ya
usaba weather.gismeteo (resources/libs/gismeteo.py de ese addon) para
poder reutilizar sin cambios el resto del framework de simpleweather.
"""
from __future__ import unicode_literals

import calendar
import time
import urllib
import urllib2
import json

__all__ = ['OpenMeteoError', 'OpenMeteoClient']

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
USER_AGENT = "XboxOgOpenMeteo/1.0"

# Codigo OMM (WMO weather code) -> (texto en espanol, codigo de icono
# Yahoo). Tabla completa segun la especificacion de Open-Meteo:
# https://open-meteo.com/en/docs (tabla "WMO Weather interpretation codes")
WMO_CODES = {
    0:  ("Despejado", "32"),
    1:  ("Mayormente despejado", "34"),
    2:  ("Parcialmente nublado", "30"),
    3:  ("Nublado", "26"),
    45: ("Niebla", "20"),
    48: ("Niebla con escarcha", "20"),
    51: ("Llovizna débil", "9"),
    53: ("Llovizna moderada", "9"),
    55: ("Llovizna intensa", "9"),
    56: ("Llovizna helada débil", "8"),
    57: ("Llovizna helada intensa", "8"),
    61: ("Lluvia débil", "11"),
    63: ("Lluvia moderada", "11"),
    65: ("Lluvia intensa", "12"),
    66: ("Lluvia helada débil", "10"),
    67: ("Lluvia helada intensa", "10"),
    71: ("Nevada débil", "14"),
    73: ("Nevada moderada", "16"),
    75: ("Nevada intensa", "41"),
    77: ("Granos de nieve", "18"),
    80: ("Chubascos débiles", "39"),
    81: ("Chubascos moderados", "39"),
    82: ("Chubascos intensos", "40"),
    85: ("Chubascos de nieve débiles", "46"),
    86: ("Chubascos de nieve intensos", "46"),
    95: ("Tormenta", "4"),
    96: ("Tormenta con granizo débil", "35"),
    99: ("Tormenta con granizo fuerte", "35"),
}

# Misma tabla en ingles, para cuando el ajuste "Language" del addon esta
# puesto a English en vez de Español - mismos codigos de icono Yahoo.
WMO_CODES_EN = {
    0:  ("Clear sky", "32"),
    1:  ("Mainly clear", "34"),
    2:  ("Partly cloudy", "30"),
    3:  ("Overcast", "26"),
    45: ("Fog", "20"),
    48: ("Depositing rime fog", "20"),
    51: ("Light drizzle", "9"),
    53: ("Moderate drizzle", "9"),
    55: ("Dense drizzle", "9"),
    56: ("Light freezing drizzle", "8"),
    57: ("Dense freezing drizzle", "8"),
    61: ("Slight rain", "11"),
    63: ("Moderate rain", "11"),
    65: ("Heavy rain", "12"),
    66: ("Light freezing rain", "10"),
    67: ("Heavy freezing rain", "10"),
    71: ("Slight snow fall", "14"),
    73: ("Moderate snow fall", "16"),
    75: ("Heavy snow fall", "41"),
    77: ("Snow grains", "18"),
    80: ("Slight rain showers", "39"),
    81: ("Moderate rain showers", "39"),
    82: ("Violent rain showers", "40"),
    85: ("Slight snow showers", "46"),
    86: ("Heavy snow showers", "46"),
    95: ("Thunderstorm", "4"),
    96: ("Thunderstorm with slight hail", "35"),
    99: ("Thunderstorm with heavy hail", "35"),
}

WMO_NIGHT_ICON_OVERRIDES = {
    "32": "31",  # despejado -> despejado (noche)
    "34": "33",  # mayormente despejado -> despejado (noche)
    "30": "29",  # parcialmente nublado -> parcialmente nublado (noche)
}


class OpenMeteoError(Exception):
    pass


# INTENTO REVERTIDO (13/09/2026): se probo sustituir esta llamada por
# xbmcvfs.File() para evitar tocar ssl de Python del todo (ver
# docs/investigaciones/runxbe-shutdown-crash-investigation.md) - no
# funciona para esta API en concreto. Confirmado leyendo
# xbmc/interfaces/legacy/File.cpp (File::readBytes): cuando la respuesta
# llega con "Transfer-Encoding: chunked" (sin Content-Length fijo, como
# hace Open-Meteo), CCurlFile pone GetLength()=0 a proposito por no poder
# saber el tamano de antemano - pero File::readBytes() SIEMPRE sobreescribe
# el tamano pedido con ese 0 ("if (size >= 0) numBytes = size"), asi que
# .read() devuelve un buffer vacio sin leer nada, sea cual sea el tamano
# que se le pida desde Python. Es una limitacion real del motor (no algo
# arreglable desde este addon) - confirmado en consola real que la
# peticion SI llegaba bien al servidor (200 OK, JSON completo por la
# red), pero el binding de Python nunca llegaba a leerlo. Se vuelve a
# urllib2, confiando en cambio en el manejo de excepciones ya aplicado
# alrededor de Py_EndInterpreter() (PythonInvoker.cpp) como mitigacion
# real de la corrupcion que esto puede causar.
def _get_json(url, params):
    full_url = "%s?%s" % (url, urllib.urlencode(params))
    req = urllib2.Request(full_url, headers={"User-Agent": USER_AGENT})
    try:
        response = urllib2.urlopen(req, timeout=15)
        body = response.read()
    except urllib2.URLError as e:
        raise OpenMeteoError(e)
    try:
        return json.loads(body)
    except ValueError as e:
        raise OpenMeteoError(e)


def describe(wmo_code, is_day=True, lang='es'):
    """Texto (en espanol o ingles segun lang) + codigo de icono Yahoo
    (0-47/na) para un codigo de tiempo de la OMM. is_day=False usa el
    icono de noche para los casos que lo tienen (despejado/parcialmente
    nublado)."""
    table = WMO_CODES_EN if lang == 'en' else WMO_CODES
    default_text = "No data" if lang == 'en' else "Sin datos"
    text, icon = table.get(int(wmo_code), (default_text, "na"))
    if not is_day:
        icon = WMO_NIGHT_ICON_OVERRIDES.get(icon, icon)
    return text, icon


def _date_dict(unix_ts, utc_offset_seconds):
    """Misma forma que CGismeteoClient._get_date(): local/utc/unix/offset
    (offset en minutos, como esperaba el resto del framework)."""
    return {
        'local': time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime(unix_ts + utc_offset_seconds)),
        'utc': time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime(unix_ts)),
        'unix': unix_ts,
        'offset': utc_offset_seconds // 60,
    }


class OpenMeteoClient(object):

    def __init__(self, lang='es'):
        # Idioma elegido en el ajuste "Language" del addon (no depende
        # del idioma de Kodi) - controla tanto el texto de las
        # condiciones (ver describe()) como el idioma de los nombres
        # de ciudad devueltos por el geocodificador.
        self.lang = lang if lang in ('es', 'en') else 'es'

    def cities_search(self, keyword):
        """Busca ciudades por nombre. Devuelve una lista de dicts con
        la misma forma que gismeteo.py: name/id/country/district/lat/lng.
        Como Open-Meteo no tiene "id" de ciudad propio, se usa
        "lat,lng" como id (asi build_forecast_url() no necesita un
        segundo servicio para resolverlo)."""
        data = _get_json(GEOCODING_URL, {
            "name": keyword,
            "count": 10,
            "language": self.lang,
            "format": "json",
        })
        results = []
        for item in data.get("results", []) or []:
            lat = item.get("latitude")
            lng = item.get("longitude")
            results.append({
                'name': item.get("name", ""),
                'id': "{0},{1}".format(lat, lng),
                'country': item.get("country", ""),
                'district': item.get("admin1", "") or "",
                'lat': lat,
                'lng': lng,
                'kind': "",
            })
        return results

    def forecast(self, city_id):
        """city_id es "lat,lng" (ver cities_search). Devuelve un dict
        con la misma forma que GismeteoClient.forecast(): name/id/
        country/district/lat/lng/cur_time/current/days."""
        try:
            lat, lng = city_id.split(",")
        except (ValueError, AttributeError):
            raise OpenMeteoError("city_id invalido: %r" % (city_id,))

        data = _get_json(FORECAST_URL, {
            "latitude": lat,
            "longitude": lng,
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,"
                       "is_day,weather_code,surface_pressure,wind_speed_10m,wind_direction_10m",
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,"
                     "apparent_temperature_max,apparent_temperature_min,"
                     "sunrise,sunset,precipitation_sum,wind_speed_10m_max,"
                     "wind_direction_10m_dominant,relative_humidity_2m_max,"
                     "relative_humidity_2m_min,surface_pressure_mean",
            "hourly": "temperature_2m,relative_humidity_2m,apparent_temperature,"
                      "is_day,weather_code,surface_pressure,precipitation,"
                      "wind_speed_10m,wind_direction_10m",
            "timezone": "auto",
            "forecast_days": 7,
        })

        utc_offset = data.get("utc_offset_seconds", 0)
        cur = data.get("current", {})
        daily = data.get("daily", {})
        hourly = data.get("hourly", {})

        wmo_cur = cur.get("weather_code", 0)
        is_day_cur = bool(cur.get("is_day", 1))
        text_cur, icon_cur = describe(wmo_cur, is_day_cur, self.lang)

        current = {
            'date': _date_dict(_parse_iso(cur.get("time"), utc_offset), utc_offset),
            'temperature': {
                'air': _round(cur.get("temperature_2m")),
                'comfort': _round(cur.get("apparent_temperature")),
            },
            'description': text_cur,
            'humidity': _round(cur.get("relative_humidity_2m")),
            'pressure': _round(_hpa_to_mmhg(cur.get("surface_pressure"))),
            'cloudiness': '',
            'storm': wmo_cur in (95, 96, 99),
            'precipitation': {'type': '', 'amount': 0.0, 'intensity': ''},
            'icon': icon_cur,
            'gm': '0',
            'wind': {
                'speed': _to_float(cur.get("wind_speed_10m")) / 3.6,  # km/h -> m/s
                'direction': _wind_dir(cur.get("wind_direction_10m")),
            },
        }

        days = []
        times = daily.get("time", []) or []
        for i, day_date in enumerate(times):
            wmo_day = _at(daily.get("weather_code"), i, 0)
            text_day, icon_day = describe(wmo_day, True, self.lang)
            sunrise_ts = _parse_iso(_at(daily.get("sunrise"), i, None), utc_offset)
            sunset_ts = _parse_iso(_at(daily.get("sunset"), i, None), utc_offset)
            day_ts = _parse_iso(day_date + "T12:00", utc_offset)

            days.append({
                'date': _date_dict(day_ts, utc_offset),
                'sunrise': _date_dict(sunrise_ts, utc_offset) if sunrise_ts else None,
                'sunset': _date_dict(sunset_ts, utc_offset) if sunset_ts else None,
                'temperature': {
                    'min': _round(_at(daily.get("temperature_2m_min"), i, None)),
                    'max': _round(_at(daily.get("temperature_2m_max"), i, None)),
                },
                'description': text_day,
                'humidity': {
                    'min': _round(_at(daily.get("relative_humidity_2m_min"), i, None)),
                    'max': _round(_at(daily.get("relative_humidity_2m_max"), i, None)),
                    'avg': _round(_at(daily.get("relative_humidity_2m_min"), i, None)),
                },
                'pressure': {
                    'min': _round(_hpa_to_mmhg(_at(daily.get("surface_pressure_mean"), i, None))),
                    'max': _round(_hpa_to_mmhg(_at(daily.get("surface_pressure_mean"), i, None))),
                    'avg': _round(_hpa_to_mmhg(_at(daily.get("surface_pressure_mean"), i, None))),
                },
                'cloudiness': '',
                'storm': wmo_day in (95, 96, 99),
                'precipitation': {
                    'type': '',
                    'amount': _to_float(_at(daily.get("precipitation_sum"), i, 0)),
                    'intensity': '',
                },
                'icon': icon_day,
                'gm': '0',
                'wind': {
                    'speed': {
                        'min': _to_float(_at(daily.get("wind_speed_10m_max"), i, 0)) / 3.6,
                        'max': _to_float(_at(daily.get("wind_speed_10m_max"), i, 0)) / 3.6,
                        'avg': _to_float(_at(daily.get("wind_speed_10m_max"), i, 0)) / 3.6,
                    },
                    'direction': _wind_dir(_at(daily.get("wind_direction_10m_dominant"), i, None)),
                },
            })

        hourly_list = []
        for i, h_time in enumerate(hourly.get("time", []) or []):
            h_ts = _parse_iso(h_time, utc_offset)
            if h_ts is None:
                continue
            wmo_hour = _at(hourly.get("weather_code"), i, 0)
            is_day_hour = bool(_at(hourly.get("is_day"), i, 1))
            text_hour, icon_hour = describe(wmo_hour, is_day_hour, self.lang)
            hourly_list.append({
                'date': _date_dict(h_ts, utc_offset),
                'temperature': {
                    'air': _round(_at(hourly.get("temperature_2m"), i, None)),
                    'comfort': _round(_at(hourly.get("apparent_temperature"), i, None)),
                },
                'description': text_hour,
                'humidity': _round(_at(hourly.get("relative_humidity_2m"), i, None)),
                'pressure': _round(_hpa_to_mmhg(_at(hourly.get("surface_pressure"), i, None))),
                'cloudiness': '',
                'storm': wmo_hour in (95, 96, 99),
                'precipitation': {
                    'type': '',
                    'amount': _to_float(_at(hourly.get("precipitation"), i, 0)),
                    'intensity': '',
                },
                'icon': icon_hour,
                'gm': '0',
                'wind': {
                    'speed': _to_float(_at(hourly.get("wind_speed_10m"), i, 0)) / 3.6,
                    'direction': _wind_dir(_at(hourly.get("wind_direction_10m"), i, None)),
                },
            })

        return {
            'name': data.get("timezone", "").split("/")[-1].replace("_", " ") or "?",
            'id': city_id,
            'kind': '',
            'country': '',
            'district': '',
            'lat': data.get("latitude"),
            'lng': data.get("longitude"),
            'cur_time': _date_dict(int(time.time()), utc_offset),
            'current': current,
            'days': days,
            'hourly': hourly_list,
        }


def _parse_iso(value, utc_offset_seconds):
    if not value:
        return None
    try:
        struct = time.strptime(value, "%Y-%m-%dT%H:%M")
    except ValueError:
        return None
    # Open-Meteo (con timezone=auto) ya da las horas en la hora LOCAL de
    # la ciudad consultada, no en la del sistema que ejecuta el script -
    # calendar.timegm() trata el struct_time como UTC puro (ignora el
    # huso horario del propio mini PC), asi que restando el offset de la
    # ciudad se obtiene el unix timestamp UTC real. time.mktime() habria
    # sido incorrecto aqui porque usa el huso horario del sistema local.
    naive_unix = calendar.timegm(struct)
    return naive_unix - utc_offset_seconds


def _at(seq, i, default):
    if not seq or i >= len(seq):
        return default
    value = seq[i]
    return default if value is None else value


def _round(value):
    if value is None:
        return 0
    try:
        return int(round(float(value)))
    except (TypeError, ValueError):
        return 0


def _to_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _hpa_to_mmhg(value):
    if value is None:
        return None
    return _to_float(value) * 0.750062


def _wind_dir(degrees):
    if degrees is None:
        return '0'
    dirs = ['n', 'nne', 'ne', 'ene', 'e', 'ese', 'se', 'sse',
            's', 'ssw', 'sw', 'wsw', 'w', 'wnw', 'nw', 'nnw']
    idx = int((_to_float(degrees) + 11.25) / 22.5) % 16
    return dirs[idx]
