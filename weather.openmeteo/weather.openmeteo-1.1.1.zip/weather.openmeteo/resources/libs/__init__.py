# -*- coding: utf-8 -*-
"""
Adaptador entre OpenMeteoClient (openmeteo.py) y el framework generico
de simpleweather (resources/libs/simpleweather/, copiado tal cual del
addon weather.gismeteo, que en si mismo no es especifico de Gismeteo).

Mucho mas simple que el equivalente de Gismeteo (resources/libs/__init__.py
de weather.gismeteo): no hace falta una tabla de 200 idiomas ni traducir
codigos de icono propietarios, porque openmeteo.py ya devuelve el texto
en espanol y el codigo de icono Yahoo (0-47/na) directamente.
"""
from __future__ import unicode_literals

import time

import xbmc

from .openmeteo import OpenMeteoClient, OpenMeteoError
from .simpleweather import Weather as SW_Weather, WeatherProperties, Addon, WebClientError

__all__ = ['OpenMeteoError', 'OpenMeteo', 'WebClientError',
           'Location', 'Weather']


class OpenMeteo(OpenMeteoClient):
    """Igual que OpenMeteoClient - existe solo para que default.py haga
    OpenMeteo(lang) igual que antes hacia Gismeteo(lang)."""
    pass


class Weather(SW_Weather, WeatherProperties):

    def __init__(self, *args, **kwargs):
        super(Weather, self).__init__(*args, **kwargs)

        self.TEMPUNIT = self.tempunit
        self.SPEEDUNIT = self.speedunit
        self.DATEFORMAT = self.date_format
        self.TIMEFORMAT = self.time_format
        self.PRESUNIT = ['mmHg', 'hPa', 'mbar', 'inHg'][self.get_setting('PresUnit')]
        self.PRECIPUNIT = ['mm', 'inch'][self.get_setting('PrecipUnit')]
        self.TIME_ZONE = self.get_setting('TimeZone')
        self.WEEKENDS = self._weekends()

        self.WIND_DIRECTIONS = self.wind_directions()
        self.MONTH_NAME_LONG = self.month_name_long()
        self.MONTH_NAME_SHORT = self.month_name_short()
        self.WEEK_DAY_LONG = self.week_day_long()
        self.WEEK_DAY_SHORT = self.week_day_short()

    def get_weather_code(self, item):
        # openmeteo.py ya deja el codigo de icono Yahoo (0-47/na)
        # directamente en item['icon'] - no hace falta traducir nada
        # aqui, a diferencia de Gismeteo (que usa sus propios codigos
        # de icono internos y necesita una tabla de conversion).
        return item.get('icon', 'na')

    def get_wind_direction(self, value):
        wind_direction_code = self.WIND_DIRECTIONS.get(value)

        if wind_direction_code is not None:
            return xbmc.getLocalizedString(wind_direction_code)
        elif value == '0':
            return self.gettext('calm')
        else:
            return self.gettext('n/a')

    def get_time(self, date):
        date_time = self._get_timestamp(date)
        if self.TIMEFORMAT != '/':
            return time.strftime('%I:%M%p', date_time)
        return time.strftime('%H:%M', date_time)

    def convert_date(self, date):
        date_time = self._get_timestamp(date)
        if self.DATEFORMAT[1] == 'd' or self.DATEFORMAT[0] == 'D':
            localdate = time.strftime('%d-%m-%Y', date_time)
        elif self.DATEFORMAT[1] == 'm' or self.DATEFORMAT[0] == 'M':
            localdate = time.strftime('%m-%d-%Y', date_time)
        else:
            localdate = time.strftime('%Y-%m-%d', date_time)
        if self.TIMEFORMAT != '/':
            localtime = time.strftime('%I:%M%p', date_time)
        else:
            localtime = time.strftime('%H:%M', date_time)
        return localtime + '  ' + localdate

    def is_weekend(self, day):
        return self.get_weekday(day['date'], 'x') in self.WEEKENDS

    def get_weekday(self, date, form):
        date_time = self._get_timestamp(date)
        weekday = time.strftime('%w', date_time)
        if form == 's':
            return xbmc.getLocalizedString(self.WEEK_DAY_SHORT[weekday])
        elif form == 'l':
            return xbmc.getLocalizedString(self.WEEK_DAY_LONG[weekday])
        else:
            return int(weekday)

    def get_month(self, date, form):
        date_time = self._get_timestamp(date)
        month = time.strftime('%m', date_time)
        day = time.strftime('%d', date_time)
        if form == 'ds':
            label = day + ' ' + xbmc.getLocalizedString(self.MONTH_NAME_SHORT[month])
        elif form == 'dl':
            label = day + ' ' + xbmc.getLocalizedString(self.MONTH_NAME_LONG[month])
        elif form == 'ms':
            label = xbmc.getLocalizedString(self.MONTH_NAME_SHORT[month]) + ' ' + day
        elif form == 'ml':
            label = xbmc.getLocalizedString(self.MONTH_NAME_LONG[month]) + ' ' + day
        else:
            label = ''
        return label

    def _weekends(self):
        weekend = self.get_setting('Weekend')
        if weekend == 2:
            return [4, 5]
        elif weekend == 1:
            return [5, 6]
        else:
            return [6, 0]

    def _get_timestamp(self, date):
        if self.TIME_ZONE == 0:
            return time.localtime(date['unix'])
        return time.gmtime(date['unix'] + date['offset'] * 60)


class Location(object):

    def __init__(self, data=None):
        self._data = data or {}

    @property
    def name(self):
        return self._data.get('name', '')

    @property
    def id(self):
        return '{0}'.format(self._data.get('id', ''))

    @property
    def district(self):
        return self._data.get('district', '')

    @property
    def country(self):
        return self._data.get('country', '')

    @property
    def label(self):
        if self.district:
            return '{0} ({1}, {2})'.format(self.name, self.district, self.country)
        return '{0} ({1})'.format(self.name, self.country)
