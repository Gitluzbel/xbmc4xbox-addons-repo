# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

from .simpleweather import (WeatherProperties, Weather,
                            Addon, py2_encode, py2_decode)

__all__ = ['WeatherProperties', 'Weather',
           'Addon', 'py2_encode', 'py2_decode',
           'WebClientError']


# BUG REAL ENCONTRADO EN AUDITORIA (13/09/2026): antes se importaba
# WebClient (y con el, WebClientError) desde webclient.py - pero
# WebClient (basado en requests.Session) no se usa en NINGUN sitio real
# de weather.openmeteo (confirmado con grep: cero instancias
# "WebClient(" fuera de su propia definicion). Importarlo solo para
# obtener la excepcion cargaba requests/urllib3/certifi/ssl sin ninguna
# necesidad real - ssl real es el sospechoso principal de la corrupcion
# de estado global de Python investigada en
# docs/investigaciones/runxbe-shutdown-crash-investigation.md. Se
# redefine WebClientError aqui mismo (identica a la de webclient.py) en
# vez de importar todo ese modulo solo por esta clase.
class WebClientError(Exception):

    def __init__(self, error):
        self.message = error
        super(WebClientError, self).__init__(self.message)
