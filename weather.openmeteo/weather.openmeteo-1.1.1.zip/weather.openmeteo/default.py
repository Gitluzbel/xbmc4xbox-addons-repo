# -*- coding: utf-8 -*-
"""
weather.openmeteo
==================

Addon de clima usando la API gratuita de Open-Meteo (sin clave, sin
registro) en vez de Gismeteo - ver resources/libs/openmeteo.py para el
porque: Gismeteo no da las descripciones del tiempo en espanol (su
propia API no lo soporta), Open-Meteo da un codigo numerico que aqui
mismo se traduce a espanol de verdad.

Reutiliza el framework de resources/libs/simpleweather/ (copiado tal
cual de weather.gismeteo, es generico, no especifico de ese addon).

Simplificado respecto a Gismeteo a proposito: una sola ciudad guardada
(no gestion de varias ubicaciones ni geolocalizacion por IP). El
desglose Hourly usa las proximas horas reales de la API de Open-Meteo;
36Hour toma 3 puntos representativos cada 12h (+12h/+24h/+36h) en vez
de las franjas manana/tarde/noche que usa Gismeteo, ya que Open-Meteo
da resolucion horaria real en vez de 4 franjas fijas por dia.

Actualizacion BAJO DEMANDA solamente (anadido 10/09/2026, ver
video-radio-freeze-investigation.md, "Causa 3"): Kodi invoca el addon de
clima automaticamente muy a menudo (al entrar en la pantalla de Clima, y
periodicamente en segundo plano) - cada una de esas veces era una
peticion de red nueva a Open-Meteo. Se confirmo en consola real que
mientras un addon Python cualquiera esta esperando una respuesta de red,
retiene el GIL (candado global de Python, compartido por TODOS los
scripts/addons del sistema) y bloquea a cualquier OTRO addon Python que
intente arrancar en ese momento - por ejemplo, congelando la radio
(plugin.audio.fmstream) durante 14+ segundos si coincidia con una de
estas peticiones automaticas del tiempo. No podemos arreglar el GIL en
si (haria falta parchear el propio interprete de Python empotrado), asi
que la mitigacion es reducir cuanto usamos la red sin que el usuario lo
pida: la accion 'root' (forecast(), la que Kodi llama solo) ahora SOLO
hace una peticion de red si todavia no hay nada guardado en cache para
esta ciudad/idioma (primer uso, o cambio de ciudad) - el resto de veces
reutiliza sin tocar la red lo ultimo que haya en cache, por antiguo que
sea. La unica forma de forzar una peticion de red nueva es pulsar
"Actualizar ahora" en los ajustes del addon (accion refresh()). La cache
usa MemStorage (ver get_mem_storage() en simpleplugin.py) - persiste
entre invocaciones del script mientras la Xbox siga encendida, no tiene
caducidad propia (a diferencia del @mem_cached(30) que sustituye, que
son 30 MINUTOS, no segundos - ojo al leer versiones antiguas de este
fichero).
"""
from __future__ import unicode_literals

import time
from builtins import range

import xbmc
import xbmcgui

from resources.libs import OpenMeteo, OpenMeteoError, Location, Weather, WebClientError

weather = Weather()
_ = weather.initialize_gettext()

MAX_DAYS = 7
MAX_DAILYS = 7
MAX_HOURLY = 16
MAX_36HOUR = 3
MAX_WEEKENDS = 2

WEATHER_ICON = weather.weather_icon

CURRENT_TIME = {'unix': time.time()}


def set_item_info(props, item, item_type, icon='%s.png', day_temp=None):
    keys = list(props.keys())

    date = item['date']

    if 'Title' in keys:
        props['Title'] = weather.get_weekday(date, 'l')
    if 'Time' in keys:
        props['Time'] = weather.get_time(date)
    if 'LongDay' in keys:
        props['LongDay'] = weather.get_weekday(date, 'l')
    if 'ShortDay' in keys:
        props['ShortDay'] = weather.get_weekday(date, 's')
    if 'LongDate' in keys:
        form = 'dl' if (weather.DATEFORMAT[1] == 'd' or weather.DATEFORMAT[0] == 'D') else 'ml'
        props['LongDate'] = weather.get_month(date, form)
    if 'ShortDate' in keys:
        form = 'ds' if (weather.DATEFORMAT[1] == 'd' or weather.DATEFORMAT[0] == 'D') else 'ms'
        props['ShortDate'] = weather.get_month(date, form)

    weather_code = weather.get_weather_code(item)

    if 'Outlook' in keys:
        props['Outlook'] = item['description']
    if 'Condition' in keys:
        props['Condition'] = item['description']
    if 'OutlookIcon' in keys:
        props['OutlookIcon'] = icon % weather_code
    if 'FanartCode' in keys:
        props['FanartCode'] = weather_code

    wind = item['wind']
    speed = wind['speed']['avg'] if isinstance(wind['speed'], dict) else wind['speed']

    if 'Wind' in keys:
        props['Wind'] = int(round(speed * 3.6))
    if 'WindSpeed' in keys:
        props['WindSpeed'] = '{0} {1}'.format(weather.SPEED(speed), weather.SPEEDUNIT)
    if 'WindDirection' in keys:
        props['WindDirection'] = weather.get_wind_direction(wind['direction'])
    if 'MaxWind' in keys and isinstance(wind['speed'], dict):
        props['MaxWind'] = '{0} {1}'.format(weather.SPEED(wind['speed']['max']), weather.SPEEDUNIT)

    if 'DewPoint' in keys and item_type == 'day':
        props['DewPoint'] = weather.DEW_POINT(item['temperature']['max'], item['humidity']['avg']) + weather.TEMPUNIT
    elif 'DewPoint' in keys and item_type == 'cur':
        props['DewPoint'] = weather.DEW_POINT(item['temperature']['air'], item['humidity'], False)

    if 'HighTemp' in keys:
        props['HighTemp'] = '{0}'.format(item['temperature']['max'])
    if 'LowTemp' in keys:
        props['LowTemp'] = '{0}'.format(item['temperature']['min'])
    if 'HighTemperature' in keys:
        props['HighTemperature'] = weather.TEMP(item['temperature']['max']) + weather.TEMPUNIT
        props['LowTemperature'] = weather.TEMP(item['temperature']['min']) + weather.TEMPUNIT
    if 'Temperature' in keys and item_type == 'cur':
        props['Temperature'] = item['temperature']['air']
    elif 'Temperature' in keys:
        props['Temperature'] = weather.TEMP(item['temperature']['air']) + weather.TEMPUNIT
    if 'FeelsLike' in keys and item_type == 'cur':
        props['FeelsLike'] = item['temperature']['comfort']
    elif 'FeelsLike' in keys:
        props['FeelsLike'] = weather.TEMP(item['temperature']['comfort']) + weather.TEMPUNIT

    if 'Humidity' in keys:
        humidity = item['humidity']['avg'] if item_type == 'day' else item['humidity']
        tpl = '{0}%' if item_type != 'cur' else '{0}'
        props['Humidity'] = tpl.format(humidity) if humidity is not None else 'n/a'
    if 'MinHumidity' in keys and item_type == 'day':
        props['MinHumidity'] = '{0}%'.format(item['humidity']['min'])
    if 'MaxHumidity' in keys and item_type == 'day':
        props['MaxHumidity'] = '{0}%'.format(item['humidity']['max'])

    if 'Pressure' in keys:
        pressure = item['pressure']['avg'] if item_type == 'day' else item['pressure']
        props['Pressure'] = '{0} {1}'.format(weather.PRESSURE(pressure), weather.PRESUNIT) if pressure is not None else 'n/a'

    if 'Precipitation' in keys:
        precip = item['precipitation']['amount']
        props['Precipitation'] = '{0} {1}'.format(weather.PRECIPITATION(precip), weather.PRECIPUNIT) if precip is not None else 'n/a'


def clear():
    weather.set_properties(weather.prop_current(), 'Current')
    weather.set_properties(weather.prop_today(), 'Today')
    weather.set_properties(weather.prop_forecast(), 'Forecast')

    day_props = weather.prop_day()
    for count in range(0, MAX_DAYS + 1):
        weather.set_properties(day_props, 'Day', count, '')

    daily_props = weather.prop_daily()
    for count in range(1, MAX_DAILYS + 1):
        weather.set_properties(daily_props, 'Daily', count)
    for count in range(1, MAX_WEEKENDS + 1):
        weather.set_properties(daily_props, 'Weekend', count)

    hourly_props = weather.prop_hourly()
    for count in range(1, MAX_HOURLY + 1):
        weather.set_properties(hourly_props, 'Hourly', count)

    _36hour_props = weather.prop_36hour()
    for count in range(1, MAX_36HOUR + 1):
        weather.set_properties(_36hour_props, '36Hour', count)


def _pick_hour_near(hourly_list, target_ts):
    for hour in hourly_list:
        if hour['date']['unix'] >= target_ts:
            return hour
    return None


def refresh_locations():
    # Solo una ubicacion guardada - a diferencia de Gismeteo (hasta 5 +
    # geolocalizacion por IP), aqui basta con el ajuste "City".
    city = weather.get_setting('City')
    weather.set_property('Location1', city or '')
    weather.set_property('Locations', 1 if city else 0)


def set_location_props(forecast_info):
    count_days = 0
    count_weekends = 0

    current_props = weather.prop_current()
    set_item_info(current_props, forecast_info['current'], 'cur')
    current_props['Location'] = forecast_info['name']
    weather.set_properties(current_props, 'Current')

    forecast_props = weather.prop_forecast()
    forecast_props['City'] = forecast_info['name']
    forecast_props['Country'] = forecast_info['country']
    forecast_props['State'] = forecast_info['district']
    forecast_props['Latitude'] = '{0}'.format(forecast_info['lat'])
    forecast_props['Longitude'] = '{0}'.format(forecast_info['lng'])
    forecast_props['Updated'] = weather.convert_date(forecast_info['cur_time'])
    weather.set_properties(forecast_props, 'Forecast')

    today_props = weather.prop_today()
    weather.set_properties(today_props, 'Today')

    for day in forecast_info['days']:
        if count_days <= MAX_DAYS:
            day_props = weather.prop_day()
            set_item_info(day_props, day, 'day')
            weather.set_properties(day_props, 'Day', count_days, '')

        if count_days <= MAX_DAILYS:
            daily_props = weather.prop_daily()
            set_item_info(daily_props, day, 'day', WEATHER_ICON)
            weather.set_properties(daily_props, 'Daily', count_days + 1)

        if weather.is_weekend(day) and count_weekends <= MAX_WEEKENDS:
            weekend_props = weather.prop_daily()
            set_item_info(weekend_props, day, 'day', WEATHER_ICON)
            weather.set_properties(weekend_props, 'Weekend', count_weekends + 1)
            count_weekends += 1

        count_days += 1

    day_props = weather.prop_day()
    for count in range(count_days, MAX_DAYS + 1):
        weather.set_properties(day_props, 'Day', count, '')

    daily_props = weather.prop_daily()
    for count in range(count_days + 1, MAX_DAILYS + 1):
        weather.set_properties(daily_props, 'Daily', count)

    for count in range(count_weekends + 1, MAX_WEEKENDS + 1):
        weather.set_properties(daily_props, 'Weekend', count)

    hourly_list = forecast_info.get('hourly') or []

    # Hourly: proximas MAX_HOURLY horas reales desde ahora
    upcoming = [h for h in hourly_list if h['date']['unix'] >= CURRENT_TIME['unix']]
    count_hourly = 0
    for hour in upcoming[:MAX_HOURLY]:
        hourly_props = weather.prop_hourly()
        set_item_info(hourly_props, hour, 'hour', WEATHER_ICON)
        weather.set_properties(hourly_props, 'Hourly', count_hourly + 1)
        count_hourly += 1
    hourly_props = weather.prop_hourly()
    for count in range(count_hourly + 1, MAX_HOURLY + 1):
        weather.set_properties(hourly_props, 'Hourly', count)

    # 36Hour: MAX_36HOUR puntos representativos cada 12h (+12h/+24h/+36h)
    count_36 = 0
    for step in range(1, MAX_36HOUR + 1):
        target_ts = CURRENT_TIME['unix'] + step * 12 * 3600
        hour = _pick_hour_near(hourly_list, target_ts)
        if hour is None:
            continue
        _36hour_props = weather.prop_36hour()
        set_item_info(_36hour_props, hour, 'hour', WEATHER_ICON)
        _36hour_props['Heading'] = '{0} {1}'.format(
            weather.get_weekday(hour['date'], 's'), weather.get_time(hour['date']))
        weather.set_properties(_36hour_props, '36Hour', count_36 + 1)
        count_36 += 1
    _36hour_props = weather.prop_36hour()
    for count in range(count_36 + 1, MAX_36HOUR + 1):
        weather.set_properties(_36hour_props, '36Hour', count)


def _lang():
    # Ajuste "Language" del addon (0=Espanol, 1=English) - independiente
    # del idioma del propio Kodi, a diferencia de Gismeteo.
    return 'en' if weather.get_setting('Language') == 1 else 'es'


@weather.action('root')
def forecast(params):
    # Bajo demanda: solo se toca la red si esta ciudad/idioma no tiene
    # NADA en cache todavia (primer uso o cambio de ciudad). El resto de
    # veces (Kodi llama a esta funcion solo, muy a menudo) se reutiliza
    # lo que ya haya en cache sin tocar la red - ver docstring del
    # modulo para el porque. "Actualizar ahora" (refresh(), mas abajo)
    # es la unica forma de forzar una peticion de red nueva.
    location = get_location()
    if location.id:
        lang = _lang()
        data = _cached_forecast(location.id, lang)
        if data is None:
            try:
                data = _fetch_forecast(location.id, lang)
            except (OpenMeteoError, WebClientError):
                # BUG REAL ENCONTRADO EN PRODUCCION (11/09/2026): la cache
                # esta vacia en TODO primer arranque (MemStorage vive solo
                # en RAM, no sobrevive a un reinicio de la Xbox) - la
                # primera peticion de red tras encender la consola a veces
                # coincide con la red/DNS todavia no lista del todo, o con
                # otro addon reteniendo el GIL en ese instante exacto (ver
                # Causa 3 en video-radio-freeze-investigation.md) - "a
                # veces al iniciar da error y no carga datos", reportado
                # en produccion. Como el fallo no se guarda en cache (solo
                # los exitos, ver _fetch_forecast), en teoria se
                # autocorrige solo la proxima vez que Kodi vuelva a pedir
                # el tiempo - pero eso puede tardar bastante (refresco
                # periodico nativo, fuera de nuestro control) o depender
                # de que el usuario entre a mano en Clima. Un unico
                # reintento tras una pausa corta cubre el caso transitorio
                # de verdad (red aun no lista) sin reintroducir el
                # problema original que motivo el cambio a bajo demanda
                # (peticiones periodicas sin que el usuario las pida) -
                # esto sigue disparandose solo ante un fallo real de
                # cache vacia, una vez, no con ningun temporizador.
                time.sleep(3)
                try:
                    data = _fetch_forecast(location.id, lang)
                except (OpenMeteoError, WebClientError) as e:
                    weather.notify_error(e)
                    clear()
                    refresh_locations()
                    return
        set_location_props(data)
    else:
        clear()

    refresh_locations()


@weather.action()
def refresh(params):
    # Unico punto del addon que fuerza una peticion de red nueva a
    # Open-Meteo, siempre a peticion explicita del usuario (boton
    # "Actualizar ahora" en los ajustes) - ver docstring del modulo.
    location = get_location()
    if not location.id:
        weather.dialog_ok(weather.name, xbmc.getLocalizedString(284))
        return

    try:
        data = _fetch_forecast(location.id, _lang())
    except (OpenMeteoError, WebClientError) as e:
        weather.notify_error(e, True)
        return

    set_location_props(data)
    refresh_locations()
    xbmc.executebuiltin('Notification({0},{1})'.format(
        weather.name, weather.get_localized_string(32151)))


@weather.action()
def location(params):
    labels = []
    locations = []

    keyword = weather.get_keyboard_text('', xbmc.getLocalizedString(14024), False)
    if keyword:
        try:
            search_result = OpenMeteo(_lang()).cities_search(keyword)
        except (OpenMeteoError, WebClientError) as e:
            weather.notify_error(e, True)
        else:
            for s_location in search_result:
                loc = Location(s_location)
                locations.append({'id': loc.id, 'name': loc.name})
                labels.append(loc.label)

            if locations:
                selected = weather.dialog_select(xbmc.getLocalizedString(396), labels)
                if selected != -1:
                    chosen = locations[selected]
                    weather.set_setting('City', chosen['name'])
                    weather.set_setting('CityID', chosen['id'])
            else:
                weather.dialog_ok(weather.name, xbmc.getLocalizedString(284))


def _forecast_cache():
    # MemStorage propio (no el decorador @mem_cached de simpleplugin,
    # que tiene su propia caducidad automatica a los 30 MINUTOS) -
    # aqui queremos control manual total: nunca caduca sola, solo se
    # sobreescribe cuando refresh() hace una peticion de red nueva.
    return weather.get_mem_storage('openmeteo_forecast')


def _cache_key(city_id, lang):
    return '{0}|{1}'.format(city_id, lang)


def _cached_forecast(city_id, lang):
    try:
        return _forecast_cache()[_cache_key(city_id, lang)]
    except KeyError:
        return None


def _fetch_forecast(city_id, lang):
    data = OpenMeteo(lang).forecast(city_id)
    _forecast_cache()[_cache_key(city_id, lang)] = data
    return data


def get_location():
    city_id = weather.get_setting('CityID')
    city_name = weather.get_setting('City')
    return Location({'name': city_name, 'id': city_id})


_LOCK_PROPERTY = 'WeatherOpenMeteo.Running'
_LOCK_MAX_AGE = 30  # segundos


def _acquire_lock():
    # BUG REAL ENCONTRADO EN PRODUCCION (14/09/2026): Kodi puede lanzar
    # este script muchas veces seguidas sin esperar a que la invocacion
    # anterior termine - visto en consola real: 17 invocaciones en unos
    # 90 segundos, cada una creando su propio interprete Python desde
    # cero (varios segundos cada una en este hardware), hasta congelar
    # la consola entera. No depende de la red ni de la cache (ver
    # docstring del modulo) - el coste real es la propia creacion del
    # interprete, que pasa ANTES de que este codigo llegue a
    # ejecutarse, asi que no se puede evitar desde Python. Lo que si
    # podemos evitar es que cada invocacion duplicada haga trabajo real
    # encima (peticiones de red, dialogos, retener el GIL) mientras la
    # anterior sigue en marcha: la primera que consigue este candado
    # (una simple propiedad con marca de tiempo en la ventana Home,
    # persiste entre invocaciones mientras la Xbox siga encendida) hace
    # el trabajo, el resto se cierra al instante. _LOCK_MAX_AGE es la
    # valvula de seguridad por si una invocacion anterior murio sin
    # limpiar el candado (crash, cierre forzado) - pasado ese tiempo se
    # considera abandonado y se ignora.
    win = xbmcgui.Window(10000)
    last = win.getProperty(_LOCK_PROPERTY)
    if last:
        try:
            age = time.time() - float(last)
        except ValueError:
            age = _LOCK_MAX_AGE + 1
        if age < _LOCK_MAX_AGE:
            return False
    win.setProperty(_LOCK_PROPERTY, str(time.time()))
    return True


def _release_lock():
    xbmcgui.Window(10000).clearProperty(_LOCK_PROPERTY)


if __name__ == '__main__':
    if _acquire_lock():
        try:
            description = weather.prop_description()
            description['Forecast.IsFetched'] = 'true'
            description['Current.IsFetched'] = 'true'
            description['Today.IsFetched'] = 'true'
            description['Daily.IsFetched'] = 'true'
            description['Weekend.IsFetched'] = 'true'
            description['36Hour.IsFetched'] = 'true'
            description['Hourly.IsFetched'] = 'true'
            description['WeatherProvider'] = weather.name

            weather.set_properties(description)

            weather.run()
        finally:
            _release_lock()
